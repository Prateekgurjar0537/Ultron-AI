package com.ultron.assistant

import android.app.ActivityManager
import android.content.Context
import android.os.StatFs

/** Enforces the requested RAM-to-model mapping; it never silently downgrades an 8 GB+ phone to E2B. */
data class LocalModelProfile(
    val title: String,
    val targetRam: String,
    val modelFileHint: String,
    val modelPage: String,
    val targetWorkloadBytes: Long,
    val caution: String
)

object LocalModelPolicy {
    private const val GB = 1_000_000_000L

    /** User-requested default profile. This is a profile only: no model is bundled or downloaded. */
    val QWEN_AMadeus_Q4 = LocalModelProfile(
        title = "Qwen3.5-4B-Amadeus · Q4_K",
        targetRam = "6 GB+ recommended",
        modelFileHint = "User-selected download/import only; verify exact GGUF asset, size, license and architecture before use",
        modelPage = "https://huggingface.co/models?search=Qwen3.5-4B-Amadeus-GGUF",
        targetWorkloadBytes = 5L * GB,
        caution = "4B Q4 models can require substantial additional memory for context and runtime buffers. Device compatibility is not guaranteed by total RAM alone."
    )
    val LFM_1_2B = LocalModelProfile(
        title = "LFM2.5-1.2B-Thinking-Abliterated · Q4_K_M",
        targetRam = "4 GB class",
        modelFileHint = "Approx. 0.73 GB download (verify repository assets before downloading)",
        modelPage = "https://huggingface.co/mradermacher/LFM2.5-1.2B-Thinking-Abliterated-GGUF",
        targetWorkloadBytes = 3L * GB,
        caution = "A 4 GB device can still run out of memory if other apps are active."
    )
    val GEMMA_E2B = LocalModelProfile(
        title = "Gemma 4 E2B Uncensored — HauhauCS Aggressive",
        targetRam = "6 GB class",
        modelFileHint = "Download size varies by quantization; verify exact GGUF asset",
        modelPage = "https://huggingface.co/HauhauCS/Gemma-4-E2B-Uncensored-HauhauCS-Aggressive",
        targetWorkloadBytes = 4L * GB,
        caution = "Use a conservative context and close other memory-heavy apps."
    )
    val GEMMA_E4B = LocalModelProfile(
        title = "Gemma 4 E4B Uncensored — HauhauCS Aggressive",
        targetRam = "8 GB+ class",
        modelFileHint = "Download size varies by quantization; verify exact GGUF asset",
        modelPage = "https://huggingface.co/HauhauCS/Gemma-4-E4B-Uncensored-HauhauCS-Aggressive",
        targetWorkloadBytes = 5L * GB,
        caution = "No automatic fallback. If it cannot fit, report failure and let the user choose manually."
    )

    fun choose(totalBytes: Long): LocalModelProfile = QWEN_AMadeus_Q4

    fun describe(context: Context): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val profile = choose(memoryInfo.totalMem)
        val stat = StatFs(context.filesDir.absolutePath)
        val free = stat.availableBytes
        return buildString {
            append("Detected total RAM: ").append(memoryInfo.totalMem / GB.toDouble()).append(" GB\n")
            append("Low-RAM device flag: ").append(am.isLowRamDevice).append("\n")
            append("Available app-storage space: ").append(free / GB.toDouble()).append(" GB\n")
            append("Required profile by ULTRON policy: ").append(profile.title).append("\n")
            append("Target AI workload: up to ").append(profile.targetRam).append(" memory tier, approximately ").append(profile.targetWorkloadBytes / GB).append(" GB working budget\n")
            append(profile.caution).append("\n\n")
            append("Profile URL: ").append(profile.modelPage).append("\n")
            append("Runtime status: native llama.cpp GGUF bridge is included in source. Import a compatible GGUF in Settings. The GitHub Actions native build and real-device model load still need verification; selecting a profile alone does not download or load a model.")
        }
    }
}
