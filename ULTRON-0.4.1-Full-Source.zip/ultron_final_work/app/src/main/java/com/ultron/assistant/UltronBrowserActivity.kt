package com.ultron.assistant

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.graphics.Color
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.content.Intent
import android.net.Uri

/** A user-visible in-app browser. Website credentials remain managed by the website's own login flow. */
class UltronBrowserActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var title: TextView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 9, 13)
        window.navigationBarColor = Color.rgb(8, 9, 13)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 9, 13))
            setPadding(dp(8), dp(8), dp(8), 0)
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        address = EditText(this).apply {
            singleLine = true
            hint = "Search or enter website address"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setBackgroundColor(Color.rgb(28, 30, 37))
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(12), 0, dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO) { loadAddress(text.toString()); true } else false
            }
        }
        val go = Button(this).apply { text = "GO"; setOnClickListener { loadAddress(address.text.toString()) } }
        bar.addView(address); bar.addView(go)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        title = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 11f; setPadding(dp(4), dp(3), dp(4), dp(3)) }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true // Required by many user-selected sites; WebView remains in-app.
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.safeBrowsingEnabled = true
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) { progress.progress = newProgress }
                override fun onReceivedTitle(view: WebView?, pageTitle: String?) { title.text = pageTitle.orEmpty() }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    return if (uri.scheme == "http" || uri.scheme == "https") false else {
                        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }; true
                    }
                }
                override fun onPageFinished(view: WebView?, url: String?) { address.setText(url.orEmpty()) }
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun control(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
        controls.addView(control("BACK") { if (web.canGoBack()) web.goBack() })
        controls.addView(control("FORWARD") { if (web.canGoForward()) web.goForward() })
        controls.addView(control("RELOAD") { web.reload() })
        controls.addView(control("SHARE") { web.url?.let { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, it), "Share page")) } })
        root.addView(bar); root.addView(progress); root.addView(title); root.addView(web); root.addView(controls)
        setContentView(root)
        loadAddress(intent.getStringExtra("url") ?: "https://www.google.com")
    }

    private fun loadAddress(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        val target = when {
            input.startsWith("https://", true) || input.startsWith("http://", true) -> input
            input.contains('.') && !input.contains(' ') -> "https://$input"
            else -> "https://www.google.com/search?q=" + Uri.encode(input)
        }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken, 0)
        web.loadUrl(target)
    }

    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() { if (::web.isInitialized) { web.stopLoading(); web.destroy() }; super.onDestroy() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
