# ULTRON 0.4.0

- Added a visible in-app WebView browser and connected the Browser action to it.
- Updated app version metadata.
- Set Qwen3.5-4B-Amadeus Q4_K as the requested default local model profile (manual download/import only; runtime inference is not yet verified).
- Added the three supplied UI reference images and a detailed honest implementation map.

## Source refresh — 2026-11-22 (Jarvis feature port)

- Added `UltronPersonalityEngine`: local custom reply rules can be trained, listed, deleted, or cleared. This reimplements the useful custom Easter-egg trainer behavior without copying Jarvis's malformed JSON asset or its hard-coded creator/personality override.
- Added an optional on-device app-usage summary command using Android `UsageStatsManager`. It requires the user to grant Usage access in Android Settings; ULTRON does not silently obtain this special access.
- Added the `PACKAGE_USAGE_STATS` manifest declaration (Android still requires the user-controlled special access toggle).
