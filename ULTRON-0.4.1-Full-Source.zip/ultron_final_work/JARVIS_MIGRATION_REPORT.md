# Jarvis → ULTRON migration review

The Jarvis project was inspected rather than copied wholesale. Its `easter_egg.json` fails JSON parsing at line 1286, so importing it would make the feature unreliable. Its `OfflineAIEngine` / `ModelDownloadService` path was excluded because the downloader creates a placeholder file rather than downloading and validating a real model.

## Ported in ULTRON 0.4.1

- **Custom Easter-egg / reply training:** reimplemented as `UltronPersonalityEngine.kt`, persisted locally, and connected to the chat command router. Commands support training, listing, deleting, and clearing custom rules.
- **App usage statistics:** reimplemented with Android `UsageStatsManager`. The user must enable Usage access in Android Settings. It reports Android's foreground-time aggregates; it does not claim to measure battery use or exact screen-on time.

## Existing ULTRON equivalents retained

- Accessibility automation service and notification listener are already present in ULTRON; Jarvis versions were not duplicated.
- App lock is implemented with Android biometric/device credentials. Jarvis's lock-screen activity was not copied because it cannot replace or bypass Android's secure lock screen.
- Voice wake-word support exists as an opt-in prototype in ULTRON. Jarvis's voice service was not copied as a complete hands-free system because it lacks a verified always-on wake-word/command lifecycle.

## Not ported

- Floating overlay: not integrated yet; it requires explicit overlay access, lifecycle handling, and careful foreground-service behavior.
- Jarvis fake model downloader: intentionally excluded.
- Boot receiver, alarm receiver and device-admin code: ULTRON already has its own reminder/device-admin components; duplicating them risks conflicting manifest and lifecycle behavior.
- Hard-coded creator/personality override phrases: excluded. They are not a general assistant capability and would override user intent.

This report describes source review and implementation scope, not a successful Android build or device test.
