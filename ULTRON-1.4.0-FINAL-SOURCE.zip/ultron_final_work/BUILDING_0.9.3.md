# Building ULTRON 0.9.3

1. Upload this complete source folder to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Run **ULTRON Android CI** (or push to the configured branch).
4. Wait for unit tests and `assembleDebug` to finish.
5. Download the debug APK artifact from the successful workflow run.

The repository includes the Android Gradle project and CI workflow. A successful CI build is still required before treating the APK as verified; this source archive has not been compiled or device-tested in this environment.
