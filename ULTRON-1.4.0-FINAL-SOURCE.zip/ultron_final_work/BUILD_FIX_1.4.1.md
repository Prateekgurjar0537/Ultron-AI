# Build failure investigation and fixes — ULTRON 1.4.1

## GitHub evidence

Repository: `gurjarprateek0537/Ultron-AI`

Two consecutive CI attempts were inspected directly:

- [Run #31](https://github.com/gurjarprateek0537/Ultron-AI/actions/runs/45806886197) got through Android resource processing and KSP, then failed at `:app:compileDebugKotlin`. Kotlin reported `UltronIntelligenceStore.kt:102:79: Cannot infer type for this parameter` and `Not enough information to infer type argument for 'T'`.
- [Run #32](https://github.com/gurjarprateek0537/Ultron-AI/actions/runs/45807037124) checked out the repository, installed Java/Android SDK/Gradle and extracted the source ZIP, but failed during root plugin resolution because Gradle could not resolve `com.google.devtools.ksp:com.google.devtools.ksp.gradle.plugin:2.0.21-1.0.28`. Kotlin compilation and APK assembly were not reached in that attempt.

## Changes made

1. Replaced the KSP plugin declaration/application with `org.jetbrains.kotlin.kapt` version 2.0.21.
2. Changed Room 2.6.1 annotation processing from `ksp(...)` to `kapt(...)` and enabled `correctErrorTypes`.
3. Fixed the independent Kotlin compile error by making the generic type explicit in `feedbackSnapshot()`: `readList<UltronActionFeedback>(KEY_FEEDBACK)`.
4. Bumped Android `versionCode` to 29 and `versionName` to 1.4.1.

The generic type fix addresses the exact source diagnostic observed in run #31. The KAPT change removes the KSP plugin-marker resolution path that failed in run #32. These are two targeted repairs based on actual CI logs.

## Verification boundary

The new archive has **not** yet been run in GitHub Actions. This environment has Java and Kotlin/JVM but no Gradle executable, Android SDK or NDK, and outbound package-network access is unavailable. The pure Kotlin tests and static archive checks recorded in `FINAL_DELIVERY_AUDIT_1.4.1.md` passed, but they do not certify the complete Android/Compose/Room/NDK build. Upload this archive to the repository and inspect the next Actions run before calling the APK build verified.
