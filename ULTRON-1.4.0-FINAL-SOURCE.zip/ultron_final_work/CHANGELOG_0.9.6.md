# ULTRON 0.9.6 — reliability fixes

- Preserve a recognized wake-word partial when Android SpeechRecognizer ends with `ERROR_NO_MATCH` or `ERROR_SPEECH_TIMEOUT`, process the recovered phrase, and restart the recognizer.
- Accept the common ASR truncation `ultra` as a wake-word hypothesis in addition to `ultron` and Hindi-script forms.
- Add Instagram, WhatsApp, Telegram, Facebook, Reddit and X to deterministic app-search parsing.
- On Android 8.x, submit an identified search field by inspecting only the system IME window and clicking an exact Search/Go/Enter key label; no arbitrary form submit control is clicked.
- Add deterministic alarm parsing and dispatch to Android `AlarmClock.ACTION_SET_ALARM`, with a truthful handoff result and no claim of independent alarm-database verification.
- Add parser/wake-word regression tests and expose the SET_ALARM intent to package visibility.

## Verification boundary

Pure Kotlin parser/wake-word smoke tests and Android manifest XML parsing passed in this workspace. The full Android Gradle/JUnit/NDK build and tests on OPPO CPH1803 / Android 8.1 were not run because the Android SDK and Gradle executable are unavailable here.
