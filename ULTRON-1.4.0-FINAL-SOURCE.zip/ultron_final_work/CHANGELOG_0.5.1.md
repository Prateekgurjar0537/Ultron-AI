# ULTRON 0.5.1 — Hindi / English voice output

## Implemented in this source update
- Added persistent spoken-output preferences for English (India), English (US), and Hindi (India).
- Added Male / Female voice presentation selection in Settings.
- ULTRON applies the best matching installed Android Text-to-Speech voice for the chosen locale and gender hint.
- Added a test-voice action so the user can hear the selected configuration.
- Voice preferences persist across app restarts and are applied to generated replies.
- Wake-word speech recognition now uses the selected voice language and recognizes common Devanagari renderings of “ULTRON”.

## Voice availability caveat
Android TTS engines do not consistently expose gender metadata. ULTRON selects a voice whose installed name/features identify the requested gender when available. If the engine does not label a matching voice, ULTRON reports that limitation and uses the best installed voice for the selected language. Users can install additional Hindi/English voices in Android Text-to-Speech settings.

## Not a complete ULTRON 1.0 release
This is a focused voice-output and wake-word language update on top of 0.5.0. It does not complete generalized multi-app agent planning, WhatsApp-specific workflows, OAuth integrations, full camera/vision pipeline, unrestricted background automation, or device-wide compatibility validation. Those require separate implementations and device/provider testing.

## Build verification
Not verified by Gradle in this environment. Android SDK/Gradle build and physical-device tests are still required.
