# ULTRON 0.4.7 — Visual redesign

## Implemented in this source revision
- Replaced the narrow icon rail and plain chat-first layout with a full-width ULTRON command dashboard.
- Added a red-eyed metallic ULTRON hero visual derived from the supplied visual reference.
- Added high-contrast crimson/orange neon cards, dark glass-like surfaces, purple accents, and bottom navigation.
- Added dashboard navigation to Chat, Voice, Browser, Vision, Memory, Model Manager, Security/Permissions, and Plugins.
- Preserved the existing InstaBox OpenAI-compatible online configuration, encrypted API-key storage, optional local GGUF import/delete path, chat persistence, document import, app lock, permission center, and foreground wake-word service.
- Bumped Android version to 0.4.7.

## Important implementation limits
- The voice service currently detects the wake word and raises a notification; it does not yet perform a continuous post-wake command capture/execution loop. Android on-device speech recognition availability and OEM background restrictions vary.
- The Qwen action currently opens a model search page; it is not a verified in-app model downloader. GGUF import is available.
- The Plugins and Memory dashboard pages are module overview pages; they do not imply that every listed third-party integration is implemented.
- A source ZIP and static checks do not prove an APK builds or that the InstaBox upstream is available. Run the included GitHub Actions workflow and test against the user's actual gateway URL/model/API key.
