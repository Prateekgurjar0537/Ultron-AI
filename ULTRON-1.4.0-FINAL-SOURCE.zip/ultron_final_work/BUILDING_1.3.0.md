# Building ULTRON 1.3.0

Requirements: JDK 17, Gradle 8.9, Android SDK platform/build-tools 35, NDK 27.2.12479018 and CMake 3.22.1. The repository currently uses a GitHub Actions workflow to install these tools and run tests/build.

From the project root on a configured Android build machine:

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

The debug APK is expected at `app/build/outputs/apk/debug/app-debug.apk`.

For the OPPO CPH1803 / Android 8.1 target, test microphone permission and wake-word restart behavior, Accessibility service stability, notification listener access, scheduled routine timing with battery optimization enabled/disabled, app-to-app navigation, volume readback, and all sensitive-action confirmation paths. WorkManager schedules are intentionally best-effort, not exact alarms.

No APK build or physical-device test is claimed by this source archive.
