# ULTRON 1.4 — Build resilience note

The latest repository Actions run (#36) extracted the submitted source archive successfully but failed during Gradle dependency resolution, before `:app:testDebugUnitTest` started. Maven Central returned HTTP 429 (Too Many Requests) for Android Gradle Plugin transitive dependencies. This is a repository rate-limit/network failure, not a reported Kotlin test assertion failure.

This source package adds the Google-hosted Maven Central mirror ahead of `mavenCentral()` in both plugin and dependency repositories. Maven Central remains configured as a fallback. This reduces reliance on one rate-limited endpoint but does not guarantee the mirror is reachable or that every dependency resolves.

A replacement GitHub Actions workflow is supplied separately as `ULTRON-1.4-build-ultron.yml`. It retries Gradle test/build commands with increasing delays. To use it, replace the repository's `.github/workflows/build-ultron.yml` with that file. The workflow expects the root archive name `ULTRON-1.4.0-FINAL-SOURCE.zip`.

## Verification boundary

The archive and source configuration can be inspected locally, but no Android SDK/NDK is installed in this authoring environment. The mirror change has not yet been exercised by a successful GitHub Actions run. The source is therefore a patched source package, not a certified green build or a tested APK.
