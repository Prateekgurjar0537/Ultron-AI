# Building ULTRON 1.4

## Toolchain

- JDK 17
- Gradle 8.9
- Android SDK Platform 35 and Build Tools 35.0.0
- Android NDK 27.2.12479018
- CMake 3.22.1

## Build and test

Run from the extracted `ultron_final_work` project root, or open that directory in Android Studio:

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

Expected debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

The bundled `.github/workflows/android.yml` installs the pinned Android toolchain, runs JVM unit tests, assembles the debug APK, and uploads the APK, checksum and test reports.

## Device validation

Install the debug APK on OPPO CPH1803 / Android 8.1 and validate Accessibility, MediaProjection/OCR, actual media-volume readback, alarm-intent handling, microphone/wake recognition, ColorOS background restrictions, app navigation, sensitive-action approval, stop/pause/resume, and recovery. Grant only the Android permissions needed for the chosen feature.

## Compatibility boundaries

- `minSdk = 26`; `targetSdk = 35`.
- Android/Gradle CI success does not certify behavior on the physical phone.
- Accessibility may not expose all app controls, and secure windows/system surfaces remain restricted.
- The wake listener uses Android `SpeechRecognizer`; it is not a dedicated acoustic wake-word engine. ColorOS can still terminate background work.
- `ACTION_SET_ALARM` acceptance does not prove that a Clock app saved the alarm.
- No universal-app automation, wake-word accuracy, background reliability or zero-error guarantee is made.
