# Building ULTRON 0.9.7

Requirements: JDK 17, Gradle 8.9, Android SDK platform/build-tools 35, NDK 27.2.12479018 and CMake 3.22.1.

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

The CI workflow is `.github/workflows/android.yml`. It uploads the test report and `ULTRON-0.9.7-debug-apk` artifact.

## Device acceptance tests

1. Enable Microphone and Accessibility permissions, set the preferred Android speech-recognition provider, and disable battery optimization for ULTRON on OEM Android 8.x devices where available.
2. Keep the wake listener active for at least 10 minutes; test wake-only, wake-plus-command, silence/no-match recovery, and recognizer busy recovery.
3. Test the same compound task in Instagram, Chrome, Settings, and at least one app not in ULTRON's predefined app list. Confirm it refreshes the UI tree after every page transition.
4. Test an alarm handoff and verify the alarm actually appears in the installed Clock app.
5. Confirm sending, calls, purchases, destructive deletes and public publishing still require approval.

The source cannot guarantee operation of controls hidden by apps, secure windows, OEM-killed background services, or Android permission boundaries. This release has not yet been built or installed on a physical device in this environment.
