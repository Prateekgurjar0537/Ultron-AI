# ULTRON 0.9.7 — Wake and navigation reliability update

- Removed forced offline speech recognition so Android 8.x devices without a downloaded offline language model can use their configured speech provider.
- Adjusted recognition silence/session parameters and surfaced synchronous listener-start failures.
- Tightened the second-utterance wake command window and reduced the wake retrigger cooldown.
- Accessibility now records window/content/scroll transition metadata without continuously exporting or persisting screen text.
- Executor waits for window transitions and refreshes the foreground package after successful navigation/deep-link actions instead of treating every package change as an immediate fatal error.
- Recovery can enter text only when the refreshed screen exposes an obvious search/find/query field; sensitive fields and external commit actions remain excluded.

## Verification limits

This source change has not been built with Android Gradle/NDK in this environment and has not been installed on a physical OPPO Android 8.1 device. Speech recognition still depends on the installed Android recognition provider, microphone permission, network/offline language assets, and OEM background restrictions. Accessibility cannot operate controls an app does not expose, secure windows, or bypass Android permission boundaries.
- Added bounded adaptive replanning after detected navigation transitions, with completed-step context and a fresh screen snapshot; sensitive actions introduced by a continuation plan are checked for approval again.
- Added local-only live UI context to initial planning; Online/Hybrid modes receive only the foreground package and are instructed to read the screen without uploading UI text.
