# Building ULTRON 1.4.1

## Toolchain

- JDK 17
- Gradle 8.9
- Android SDK Platform 35 and Build Tools 35.0.0
- Android NDK 27.2.12479018
- CMake 3.22.1

## Build and test

Open the extracted `ultron_final_work` project root in Android Studio, or run from that directory:

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

Room's annotation processor now uses Kotlin KAPT rather than KSP to avoid the plugin-resolution failure seen in the previous GitHub run. The project still uses Room 2.6.1 and Kotlin 2.0.21.

The included `.github/workflows/android.yml` installs the pinned Android toolchain, runs JVM unit tests, builds the debug APK and uploads APK/checksum/test reports.

Expected APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Device test checklist

1. Install on OPPO CPH1803 / Android 8.1.
2. Enable Accessibility, microphone permission and (for OCR fallback) Screen Awareness capture.
3. Check live screen snapshots, click/type/scroll, page-transition reinspection, verification and recovery.
4. Check wake activation, microphone callbacks, provider failure recovery, screen off/on, app closure and reboot with ColorOS autostart/battery policy configured.
5. Confirm exact-action approval for sending, calls, payments, purchases, permanent deletion, publishing/sharing and security changes.

## Compatibility boundaries

- minSdk 26; targetSdk 35.
- Accessibility and screen capture remain limited by protected app/system surfaces and user-granted permissions.
- SpeechRecognizer is not a dedicated acoustic wake-word engine; no flawless detection guarantee is made.
- A successful CI build does not certify behavior on the physical OPPO device.
