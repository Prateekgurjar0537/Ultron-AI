# ULTRON 1.4 — Final source update

## Included and fixed

- Retains the previous 1.4.1 source-level build repairs: explicit `UltronActionFeedback` generic type in the feedback store, Kotlin KAPT for Room 2.6.1, and `correctErrorTypes = true`.
- Fixes a safety-policy regression where the word `purchase` inside the read-only `Purchase history` navigation label incorrectly demanded approval.
- The safety classifier now exempts recognized read-only history destinations (`Purchase history`, `View purchase history`, `Order history`, `Payment history`, `Transaction history`, `Call history`, and `Transfer history`) while retaining approval for commit labels such as `Purchase`, `Purchase now`, `Confirm purchase`, `Buy now`, `Pay now`, `Place order`, `Send`, `Delete account`, and `Publish now`.
- The preflight action simulator now calls the same safety classifier as the action executor instead of maintaining a second broad regex. This avoids disagreement between dry-run warnings and execution policy.
- Adds regression coverage for the history-vs-commit distinction in the safety-policy and action-simulation tests.
- Sets Android `versionName` to `1.4` and retains `versionCode = 29`.

## Preserved

The archive retains the previous app source tree, Compose UI, images/media assets, native llama.cpp bridge, online/local model profiles, voice and wake-service code, Accessibility executor, OCR foundations, memory, browser, routines, plugins, file/document workspace, multi-agent coordinator, device actions, and tests. See `IMPLEMENTATION_STATUS.md` for implemented areas and explicit limitations.

## Verification boundary

A direct Kotlin/JVM harness compiled and exercised the exact safety policy source, including sensitive commit labels, history/navigation labels, call, ordinary typing and plugin method checks. The Android JUnit suite, Gradle Android build, APK assembly, GitHub Actions workflow and OPPO CPH1803 runtime behavior were not run in this authoring environment. This archive is a source ZIP, not a prebuilt or device-certified APK.
