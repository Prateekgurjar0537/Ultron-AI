pluginManagement {
    repositories {
        google()
        // Google-hosted mirror of Maven Central helps avoid transient 429 responses.
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2/") }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        // Keep Maven Central as a fallback if the mirror is temporarily unavailable.
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2/") }
        mavenCentral()
    }
}

rootProject.name = "ULTRON"
include(":app")
