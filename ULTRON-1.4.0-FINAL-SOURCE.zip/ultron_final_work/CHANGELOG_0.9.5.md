# ULTRON 0.9.5 — advanced capability foundations

This revision is based on the 0.9.4 source tree and preserves its existing application UI, AI modes, accessibility executor, voice/wake-word service, memory, browser, plugin store, native inference bridge and visual assets.

## Added in source

- Advanced Intelligence dashboard screen with network diagnostics, safe clipboard preview, a persistent routine-definition library, notification-access entry point and user-selected Storage Access Framework folder browser.
- Notification listener now exposes its live service instance to an opt-in reader. Active notification text is read on demand, kept in memory only, bounded, and filtered for common OTP/verification-code and long-number patterns. It is not a complete smart reply/priority engine.
- Clipboard read/copy helpers with conservative credential/OTP filtering.
- Connectivity diagnostics using Android's active network capabilities (transport, validated-internet state, metering and roaming).
- SAF-scoped file listing and SHA-256 helper. ULTRON does not request broad file-system access.
- On-device ML Kit Latin OCR helper for images supplied by an authorized foreground flow.
- Persistent routine definitions with name, command, enabled state, trigger timestamp, repeat interval and condition fields.
- A capability-declared skill interface/registry, specialist-agent collaboration coordinator contract, and app-private project workspace with path-traversal and size checks. Generated project files are never executed by ULTRON.

## Explicitly incomplete / not claimed

- Routine definitions are saved, but a complete visual calendar/trigger editor and reliable routine-to-agent scheduler/executor are not yet wired.
- Notification ranking, conversational summaries, notification replies and notification actions are not a complete production feature.
- Multi-agent orchestration provides a bounded specialist fan-out contract; durable cross-session agent state, provider-backed specialist agents and a full verifier loop still need integration.
- The skill registry is an in-process SDK foundation, not a signed marketplace, remote package installer or sandbox for arbitrary third-party code.
- The app workspace creates safe declarative source files; it is not a complete IDE, compiler, preview runner or APK builder.
- Local vision currently includes OCR support, not a full local multimodal vision-language model. The existing online vision endpoint path remains separate.
- SAF browsing is limited to folders the user explicitly selects. Advanced duplicate-photo cleanup, bulk organization and destructive operations are not included.
- Universal app automation still depends on the existing planner/accessibility executor and each target app's exposed UI. It cannot control every secure/custom screen or bypass Android restrictions.

## Verification

No Android Gradle/NDK build or physical-device test was run in this authoring environment. The Android SDK and Gradle executable are unavailable here. Run the repository GitHub Actions workflow and test on the target OPPO CPH1803 / Android 8.1 before treating this as a working APK release.
