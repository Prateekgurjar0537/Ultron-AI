# ULTRON 1.4.0 — Screen Verification + Voice Reliability Update

This source release continues from the supplied 1.1.0 lineage and the 1.3.0 source tree. Existing Compose UI, native llama.cpp bridge, GIF/hero media, model profiles, browser, memory, skills/plugins, device controls, routines and document retrieval are retained.

## Changes in 1.4.0

### Accessibility automation and screen-state verification
- Screen identity is now fingerprinted from the visible application package, semantic node hierarchy, labels, control flags and current bounds while excluding volatile accessibility event-generation counters and keyboard/IME diagnostic metadata.
- This prevents cursor movement, accessibility focus and many keyboard-only events from being mistaken for a completed page transition.
- Accessibility inspection uses bounded breadth-first traversal, prioritizes interactive/editable/scrollable controls and refreshes node bounds for each observation. The executor resolves new nodes for each action rather than reusing stale references.
- The executor continues to inspect after transitions, waits for accessibility events to settle, adaptively replans against the current screen and stops after bounded recovery/replan limits rather than blindly replaying stale coordinates.
- Added/strengthened `wait_for_text` execution with accessibility text polling and a single bounded on-device OCR fallback when the user has an active Screen Awareness capture session.
- Added a local OCR fallback for `click_text` when an app renders visible text but exposes no clickable Accessibility node. It requires one unambiguous match, checks that the screen fingerprint is still the same immediately before tapping the fresh OCR bounds, and reports when the resulting transition cannot be verified. Accessibility label matching also fails closed on equally ranked duplicate controls rather than choosing an arbitrary match. On Android 8.1 this path requires an active, user-approved Screen Awareness capture session.
- Screen text returned by the accessibility search helper is redacted for common private patterns. Automatic text entry refuses password, passcode, OTP/verification-code, recovery-code and payment-card fields; those must be entered manually by the user.

### Wake-word service reliability
- The notification no longer describes a merely started service as `LISTENING`; it distinguishes startup, provider-ready, speech-detected, recovery, error and stopped states.
- Added durable diagnostics for provider readiness, speech recognition sessions, audio-level callbacks, wake detections, restart counts and the last provider error.
- A watchdog rebuilds recognizers that never report readiness and refreshes long-running sessions. Startup failures use bounded exponential backoff to avoid a tight restart loop.
- Each recognizer instance has a generation ID; late callbacks from discarded instances are ignored to prevent duplicate or stale command dispatch.
- Partial hypotheses are preserved for common Android/OEM no-match and speech-timeout callbacks, but ordinary partial text is not dispatched as a command.
- Wake-word matching now requires a complete token rather than matching substrings such as `ultraviolet`. The exact `ultra` token remains a narrow first-word or greeting-prefixed speech-recognizer truncation fallback for providers that omit the final consonant; it is not accepted as an arbitrary mid-sentence word.
- Voice UI shows live diagnostics and explains that an Android speech-provider callback is not proof that every wake word was heard.

### Preserved intelligence architecture
- The central General AI planner remains the sole authority for task plans. The 28 specialist roles are on-demand logical responsibilities sharing configured General/Vision/Coding profiles, not 28 separate model instances.
- The world model, verified-outcome feedback scoring, persistent task state, preflight simulation, resource-aware specialist budgets, app/screen knowledge links and typed MCP/A2A/function contracts are retained.
- Existing sensitive-action approvals, encrypted pending actions/history, WorkManager task queue, routines, local document retrieval, notification/clipboard helpers, network diagnostics, SAF file browsing and plugin/skill foundations are retained.

## Important limits

- Universal automation is implemented as a general Accessibility/gesture executor, not a guarantee for every app or screen. It depends on the target app exposing usable Accessibility nodes or a user-approved screen-capture/OCR path. Secure windows, DRM, banking/payment screens, password/OTP inputs, inaccessible Compose/WebView/custom-rendered controls and system-protected UI may be unreadable or non-controllable.
- On the OPPO CPH1803 / Android 8.1, wake-word listening still uses the installed Android `SpeechRecognizer` provider. This is not a dedicated low-power acoustic hotword model. Provider/network availability, microphone callbacks, background microphone behavior and ColorOS autostart/battery policy must be tested on the phone. No code can guarantee zero missed detections or zero false triggers using this provider.
- The `ultra` token is retained as a recognizer-truncation fallback, so exact-token matching reduces substring false activations but cannot remove every speech-recognition false positive.
- Android may stop or defer background work. WorkManager routines are best-effort, not exact alarms. Android 14+ requires a user interaction to resume the microphone foreground service after boot under the current boot policy.
- MCP/A2A remain typed integration contracts; external transports/peers are not configured. Feedback scoring is not live reinforcement learning. The local document retriever remains lexical/BM25-style rather than embedding/vector RAG. The app-builder workspace does not compile generated projects into APKs or execute downloaded code.

## Build and test status

- Pure Kotlin core sources for screen fingerprints, world-model scoring, action simulation and wake-word phrase handling compile with `kotlinc` in the authoring environment.
- A standalone core smoke harness passed checks for complete-token wake recognition, substring false-positive rejection, stable fingerprints across generation/IME metadata changes, real hierarchy change detection and action preflight. An offline JUnit-compatible harness ran 22 selected pure-Kotlin test methods: 22 passed, 0 failed.
- Android Gradle/JUnit/Compose/KSP/NDK compilation and APK assembly were not run: this authoring environment does not have Gradle or an Android SDK configured. No emulator or physical OPPO device test was performed.
- Treat this as an upgraded source archive, not a build-verified or device-certified APK. Run the included GitHub Actions workflow and install/test on the target phone before calling it production-ready.
