package com.ultron.assistant

import org.junit.Assert.*
import org.junit.Test

class UltronMultiAgentCoordinatorTest {
    @Test fun registryContainsTwentyEightSpecialistRoles() {
        assertEquals(28, UltronMultiAgentCoordinator.availableRoles.size)
    }

    @Test fun simpleDeviceTaskUsesSmallFocusedTeam() {
        val selected = UltronMultiAgentCoordinator.selectAgents("set volume to 50 percent", false, false)
        assertTrue(selected.contains(UltronAgentRole.DEVICE))
        assertTrue(selected.contains(UltronAgentRole.PLANNER))
        assertFalse(selected.contains(UltronAgentRole.VISION))
        assertFalse(selected.contains(UltronAgentRole.CODER))
    }

    @Test fun screenTaskCanSelectVisionAndTargetFinder() {
        val selected = UltronMultiAgentCoordinator.selectAgents("find Rahul in Instagram chat", true, true)
        assertTrue(selected.contains(UltronAgentRole.SCREEN))
        assertTrue(selected.contains(UltronAgentRole.VISION))
        assertTrue(selected.contains(UltronAgentRole.TARGET))
        assertTrue(selected.contains(UltronAgentRole.COMMUNICATION))
    }

    @Test fun codingTaskSelectsDevelopmentSpecialists() {
        val selected = UltronMultiAgentCoordinator.selectAgents("debug and build my Kotlin APK", false, false)
        assertTrue(selected.contains(UltronAgentRole.CODER))
        assertTrue(selected.contains(UltronAgentRole.DEBUGGER))
        assertTrue(selected.contains(UltronAgentRole.TESTER))
    }

    @Test fun dispatchUsesBatteryAndNetworkStateForItsResourceBudget() {
        val constrained = UltronMultiAgentCoordinator.dispatch(
            "research across multiple pages", "com.example", 4L, true, true,
            batteryConstrained = true, networkAvailable = false
        )
        assertEquals(1, constrained.resourceBudget.maxParallelCalls)
        assertFalse(constrained.resourceBudget.allowVisionCall)
        assertTrue(constrained.resourceBudget.maxOutputTokens <= 256)
    }

    @Test fun naturalLanguageDeviceRequestsAreRouted() {
        assertTrue(UltronMultiAgentCoordinator.shouldRouteToDeviceAgent("Please open Instagram and find Rahul"))
        assertTrue(UltronMultiAgentCoordinator.shouldRouteToDeviceAgent("Could you check my notifications"))
        assertFalse(UltronMultiAgentCoordinator.shouldRouteToDeviceAgent("Explain what an AI agent is"))
    }

    @Test fun dispatchHasOneSharedTaskStateAndPhasedDelegation() {
        val dispatch = UltronMultiAgentCoordinator.dispatch("find Rahul on Instagram", "com.instagram.android", 7L, true, true)
        assertEquals("com.instagram.android", dispatch.state.currentPackage)
        assertEquals(7L, dispatch.state.screenGeneration)
        assertTrue(dispatch.parallelGroups.isNotEmpty())
        assertTrue(dispatch.promptDirective.contains("single authoritative task state"))
    }
}
