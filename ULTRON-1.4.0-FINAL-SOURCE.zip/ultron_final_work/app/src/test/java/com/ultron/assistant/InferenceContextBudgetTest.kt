package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class InferenceContextBudgetTest {
    @Test fun sendsExplicitBoundedContextAndRetainsLatestRequest() {
        val messages = listOf(
            ChatMessage("system", "You are ULTRON."),
            ChatMessage("user", "old question ".repeat(2_000)),
            ChatMessage("assistant", "old answer ".repeat(2_000)),
            ChatMessage("user", "Please open YouTube now.")
        )
        val settings = LlmSettings(InferenceMode.ONLINE, "https://example.invalid/v1", "model", "", 2048, 128)
        val fitted = UltronTokenBudget.fit(messages, settings)
        assertEquals("Please open YouTube now.", fitted.last().content)
        assertTrue(UltronTokenBudget.estimate(fitted) < 2048)
        assertTrue(fitted.first().role == "system")
    }

    @Test fun smallLocalContextBoundsLargeSystemContextAndKeepsLatestUserTurn() {
        val messages = listOf(
            ChatMessage("system", "Core ULTRON instructions. " + "Long imported memory. ".repeat(2_000)),
            ChatMessage("user", "old request ".repeat(800)),
            ChatMessage("assistant", "old answer ".repeat(800)),
            ChatMessage("user", "Open YouTube and search BMW.")
        )
        val fitted = UltronTokenBudget.fit(messages, LlmSettings(InferenceMode.LOCAL, "", "", "", 1024, 256))
        assertTrue(fitted.any { it.role == "system" && it.content.startsWith("Core ULTRON instructions.") })
        assertEquals("Open YouTube and search BMW.", fitted.last().content)
        assertTrue(UltronTokenBudget.estimate(fitted) < 1024)
    }

    @Test fun outputLimitIsClampedToSupportedRange() {
        val messages = listOf(ChatMessage("user", "Hello"))
        val low = UltronTokenBudget.fit(messages, LlmSettings(InferenceMode.ONLINE, "https://example.invalid/v1", "model", "", 4096, 1))
        assertEquals("Hello", low.last().content)
    }
}
