package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UltronSpeechSummaryTest {
    @Test fun speaksOnlyFirstConciseOutcomeAndKeepsMarkdownOut() {
        val source = "Task completed and verified.\n\n**Details**\n1. Opened Instagram\n2. Opened chat\n3. Typed message"
        assertEquals("Task completed and verified.", UltronSpeechSummary.from(source))
    }

    @Test fun truncatesLongSingleSentence() {
        val spoken = UltronSpeechSummary.from("A".repeat(400), 100)
        assertTrue(spoken.length <= 101)
        assertTrue(spoken.endsWith("…"))
    }
}
