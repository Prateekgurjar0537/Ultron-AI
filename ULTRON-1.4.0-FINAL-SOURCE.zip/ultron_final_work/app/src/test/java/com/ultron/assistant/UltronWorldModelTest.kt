package com.ultron.assistant

import org.junit.Assert.*
import org.junit.Test

class UltronWorldModelTest {
    @Test fun screenFingerprintDoesNotRetainCommonPrivateValues() {
        val first = UltronWorldSnapshot.fromScreen("com.example.app", "[screen_generation=7]\nContact: alex@example.com Phone: +91 9876543210 OTP 123456")
        val second = UltronWorldSnapshot.fromScreen("com.example.app", "[screen_generation=7]\nContact: sam@example.com Phone: +91 9999999999 OTP 654321")
        assertEquals(first.fingerprint, second.fingerprint)
        assertTrue(first.visibleTokens.none { it.contains("alex") || it.contains("987654") || it.contains("123456") })
    }


    @Test fun unlabelledSixDigitCodesAreNotKeptInWorldTokens() {
        val snapshot = UltronWorldSnapshot.fromScreen("com.example", "An authentication number is 123456. Home")
        assertTrue(snapshot.visibleTokens.none { it.contains("123456") })
    }

    @Test fun accessibilityEventGenerationAloneIsNotAVisibleTransition() {
        val before = UltronWorldSnapshot.fromScreen("com.example", "SCREEN package=com.example generation=10\nNODE text=Home")
        val after = UltronWorldSnapshot.fromScreen("com.example", "SCREEN package=com.example generation=11\nNODE text=Home")
        val prediction = UltronWorldModel.predict("click_text", "com.example")
        val evaluation = UltronWorldModel.evaluate(prediction, before, after, dispatched = true, verified = false)
        assertEquals(before.fingerprint, after.fingerprint)
        assertFalse(evaluation.transitionObserved)
        assertEquals(false, evaluation.predictionAligned)
    }

    @Test fun inputMethodEventMetadataDoesNotChangeScreenIdentity() {
        val first = "SCREEN package=com.example generation=10 lastEventPackage=com.android.inputmethod\nNODE text=Home"
        val second = "SCREEN package=com.example generation=11 lastEventPackage=com.example\nNODE text=Home"
        assertEquals(UltronScreenFingerprint.digest("com.example", first), UltronScreenFingerprint.digest("com.example", second))
    }

    @Test fun realVisibleHierarchyChangeIsStillDetected() {
        assertTrue(UltronScreenFingerprint.changed(
            "com.example", "SCREEN generation=10\nNODE text=Home",
            "com.example", "SCREEN generation=11\nNODE text=Search results"
        ))
    }

    @Test fun appLaunchPredictsPackageAndScreenTransition() {
        val prediction = UltronWorldModel.predict("open_app", "com.launcher")
        assertEquals(UltronTransitionExpectation.LIKELY, prediction.expectedTransition)
        assertTrue(prediction.expectedPackageChange)
    }

    @Test fun worldModelScoresObservedTransitionAgainstPrediction() {
        val before = UltronWorldSnapshot.fromScreen("com.example", "[screen_generation=1]\nHome page")
        val after = UltronWorldSnapshot.fromScreen("com.example", "[screen_generation=2]\nSearch results")
        val prediction = UltronWorldModel.predict("submit_search", "com.example")
        val evaluation = UltronWorldModel.evaluate(prediction, before, after, dispatched = true, verified = false)
        assertTrue(evaluation.transitionObserved)
        assertEquals(true, evaluation.predictionAligned)
        assertTrue(evaluation.confidenceAfterObservation > prediction.confidence)
    }

    @Test fun feedbackRewardsVerifiedResultsMoreThanUnverifiedDispatches() {
        val memory = UltronFeedbackLearning()
        memory.record(UltronActionFeedback("com.example", "tap", UltronFeedbackOutcome.VERIFIED_SUCCESS, true, 90, "com.example:tap"))
        val verifiedScore = memory.score("com.example:tap").score
        memory.record(UltronActionFeedback("com.example", "tap", UltronFeedbackOutcome.DISPATCHED_UNVERIFIED, false, 50, "com.example:tap"))
        val mixedScore = memory.score("com.example:tap").score
        assertTrue(verifiedScore > 0.5f)
        assertTrue(mixedScore < verifiedScore)
    }

    @Test fun failedStrategiesArePenalized() {
        val memory = UltronFeedbackLearning()
        memory.record(UltronActionFeedback("com.example", "click_text", UltronFeedbackOutcome.FAILED, false, 25, "com.example:click_text"))
        assertEquals(1, memory.score("com.example:click_text").failures)
        assertTrue(memory.score("com.example:click_text").score < 0.5f)
    }

    @Test fun knowledgeGraphRequiresExistingNodesAndLinksThem() {
        val graph = UltronKnowledgeGraph()
        graph.putNode(UltronKnowledgeNode("app:com.example", "app", "Example"))
        graph.putNode(UltronKnowledgeNode("screen:home", "screen_state", "Home"))
        graph.link(UltronKnowledgeEdge("app:com.example", "opened_screen", "screen:home", .8f))
        assertEquals("Home", graph.related("app:com.example").single().second.label)
    }

    @Test fun resourceManagerReducesWorkUnderBatteryPressure() {
        val normal = UltronAgentResourceManager.budget("research across multiple pages", true, true)
        val constrained = UltronAgentResourceManager.budget("research across multiple pages", true, true, batteryConstrained = true)
        assertTrue(constrained.maxSpecialists < normal.maxSpecialists)
        assertTrue(constrained.maxParallelCalls <= 1)
        assertFalse(constrained.allowVisionCall)
    }

    @Test fun functionCatalogOnlyExposesKnownActions() {
        assertNotNull(UltronFunctionCatalog.find("inspect_screen"))
        assertNotNull(UltronFunctionCatalog.find("request_approval"))
        assertNull(UltronFunctionCatalog.find("execute_arbitrary_shell"))
    }
}
