package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

class UltronQuickIntentParserTest {
    @Test fun parsesOpenYoutubeAndThenSearch() {
        assertEquals("bmw", UltronQuickIntentParser.youtubeSearchQuery("open YouTube and then search bmw"))
    }
    @Test fun parsesThenSearchForAndLaunchVariant() {
        assertEquals("BMW M5", UltronQuickIntentParser.youtubeSearchQuery("launch YouTube then search for BMW M5"))
    }
    @Test fun parsesCommaAndAfterThatCompoundPhrases() {
        assertEquals("BMW M5", UltronQuickIntentParser.youtubeSearchQuery("open YouTube, then search for BMW M5"))
        assertEquals("BMW", UltronQuickIntentParser.youtubeSearchQuery("open YouTube after that search BMW"))
    }
    @Test fun parsesSearchOnYoutube() {
        assertEquals("lofi music", UltronQuickIntentParser.youtubeSearchQuery("search lofi music on YouTube"))
    }
    @Test fun parsesQuotedQueryAndLaunchVariant() {
        assertEquals("BMW M5", UltronQuickIntentParser.youtubeSearchQuery("please launch YouTube and search for \"BMW M5\""))
    }
    @Test fun parsesFindPhraseInYoutube() {
        assertEquals("Android automation", UltronQuickIntentParser.youtubeSearchQuery("find Android automation in YouTube"))
    }
    @Test fun stripsWakeWord() {
        assertEquals("BMW", UltronQuickIntentParser.youtubeSearchQuery("Hey ULTRON, open YouTube and then search BMW"))
    }
    @Test fun rejectsNonSearchCommand() {
        assertNull(UltronQuickIntentParser.youtubeSearchQuery("open YouTube"))
    }
    @Test fun parsesCompoundSearchAcrossSupportedApps() {
        assertEquals(UltronAppSearchCommand("Chrome", "BMW M5"), UltronQuickIntentParser.appSearchCommand("open Chrome and then search for BMW M5"))
        assertEquals(UltronAppSearchCommand("Google Maps", "coffee near me"), UltronQuickIntentParser.appSearchCommand("launch Google Maps then search coffee near me"))
        assertEquals(UltronAppSearchCommand("Play Store", "offline maps"), UltronQuickIntentParser.appSearchCommand("search offline maps on Play Store"))
        assertEquals(UltronAppSearchCommand("Spotify", "lofi beats"), UltronQuickIntentParser.appSearchCommand("find lofi beats in Spotify"))
    }

    @Test fun parsesYouTubeMusicAndPlayResultCommands() {
        assertEquals(UltronAppSearchCommand("YouTube Music", "Daft Punk One More Time"), UltronQuickIntentParser.appSearchCommand("open YouTube Music and search Daft Punk One More Time"))
        assertEquals(UltronAppSearchCommand("Spotify", "Blinding Lights", shouldOpenResult = true), UltronQuickIntentParser.appSearchCommand("play Blinding Lights on Spotify"))
        assertEquals(UltronAppSearchCommand("YouTube", "Shape of You", shouldOpenResult = true), UltronQuickIntentParser.appSearchCommand("play song Shape of You"))
    }

    @Test fun parsesInstagramCompoundSearch() {
        assertEquals(UltronAppSearchCommand("Instagram", "BMW M5"), UltronQuickIntentParser.appSearchCommand("open Instagram and then search BMW M5"))
    }

    @Test fun unsupportedAppSearchIsNotGuessed() {
        assertNull(UltronQuickIntentParser.appSearchCommand("open Settings and search wifi"))
    }

    @Test fun parsesHinglishAndHindiSearchCommands() {
        assertEquals(UltronAppSearchCommand("YouTube", "BMW"), UltronQuickIntentParser.appSearchCommand("youtube kholo aur BMW search karo"))
        assertEquals(UltronAppSearchCommand("Chrome", "weather tomorrow"), UltronQuickIntentParser.appSearchCommand("Chrome mein weather tomorrow search karo"))
        assertEquals(UltronAppSearchCommand("YouTube", "BMW"), UltronQuickIntentParser.appSearchCommand("YouTube में BMW खोजो"))
        assertEquals(UltronAppSearchCommand("YouTube", "BMW"), UltronQuickIntentParser.appSearchCommand("YouTube खोलो और BMW खोजो"))
    }

    @Test fun extendedMultiStageRequestsAreLeftForTheLlmPlanner() {
        assertTrue(UltronQuickIntentParser.isExtendedCompound("open Instagram, find Rahul, open his profile, check our latest conversation, and prepare a reply"))
        assertTrue(UltronQuickIntentParser.isExtendedCompound("set volume to 50 percent and open Spotify"))
        assertTrue(UltronQuickIntentParser.isExtendedCompound("open Instagram then find Rahul then check the conversation"))
        assertFalse(UltronQuickIntentParser.isExtendedCompound("open Instagram and then search BMW"))
        assertFalse(UltronQuickIntentParser.isExtendedCompound("set volume to 50 percent"))
    }

}
