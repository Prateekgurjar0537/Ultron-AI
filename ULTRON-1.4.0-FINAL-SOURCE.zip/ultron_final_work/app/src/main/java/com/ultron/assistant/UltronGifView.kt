package com.ultron.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Movie
import android.view.View
import android.os.SystemClock

/** Lightweight animated GIF renderer for the ULTRON voice core. */
class UltronGifView(context: Context) : View(context) {
    private val movie: Movie? = runCatching {
        context.resources.openRawResource(R.raw.ultron_voice_core).use { Movie.decodeStream(it) }
    }.getOrNull()
    private val startedAt = SystemClock.uptimeMillis()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val gif = movie ?: return
        val duration = (gif.duration().takeIf { it > 0 } ?: 1440)
        val elapsed = ((SystemClock.uptimeMillis() - startedAt) % duration).toInt()
        gif.setTime(elapsed)
        val scale = minOf(width.toFloat() / gif.width(), height.toFloat() / gif.height())
        val save = canvas.save()
        canvas.translate((width - gif.width() * scale) / 2f, (height - gif.height() * scale) / 2f)
        canvas.scale(scale, scale)
        gif.draw(canvas, 0f, 0f)
        canvas.restoreToCount(save)
        postInvalidateOnAnimation()
    }
}
