package com.ultron.assistant

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

/** Local-only persistence for feedback, task checkpoints, the compact knowledge graph and diagnostics. */
class UltronIntelligenceStore(context: Context) {
    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences("ultron_agent_intelligence_v1", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val lock = Any()

    data class ResumableTask(val taskId: String, val objective: String, val packageName: String?, val selectedRoles: List<String>, val completedActionTypes: List<String>, val plannedActionCount: Int, val status: String, val updatedAtMillis: Long)

    fun beginTask(taskId: String, objective: String, packageName: String?, roles: List<String>, actionCount: Int) = synchronized(lock) {
        val encrypted = runCatching { PrivateTextVault.encrypt(objective.take(2_000)) }.getOrDefault("")
        val state = UltronPersistentTaskState(taskId, encrypted, packageName, roles.take(12), emptyList(), actionCount.coerceIn(0, 48), "running")
        prefs.edit().putString(KEY_ACTIVE_TASK, gson.toJson(state)).commit()
        event(UltronDiagnosticEvent(UltronDiagnosticCodes.PLAN_CREATED, "orchestrator", success = true))
    }

    fun updateTask(taskId: String, packageName: String?, completedActionTypes: List<String>, actionCount: Int, status: String) = synchronized(lock) {
        val current = readTask() ?: return@synchronized
        if (current.taskId != taskId) return@synchronized
        val next = current.copy(
            packageName = packageName ?: current.packageName,
            completedActionTypes = (current.completedActionTypes + completedActionTypes).takeLast(48).map { it.take(48) },
            plannedActionCount = actionCount.coerceIn(0, 48),
            status = status.take(32),
            updatedAtMillis = System.currentTimeMillis()
        )
        prefs.edit().putString(KEY_ACTIVE_TASK, gson.toJson(next)).commit()
    }

    fun markTaskStatus(taskId: String, status: String) = synchronized(lock) {
        val current = readTask() ?: return@synchronized
        if (current.taskId == taskId) prefs.edit().putString(KEY_ACTIVE_TASK, gson.toJson(current.copy(status = status.take(32), updatedAtMillis = System.currentTimeMillis()))).commit()
        if (status in TERMINAL_TASK_STATES) event(UltronDiagnosticEvent(if (status == "completed") UltronDiagnosticCodes.TASK_COMPLETED else UltronDiagnosticCodes.ACTION_FAILED, "orchestrator", success = status == "completed"))
    }

    fun requestActiveTaskControl(command: String): Boolean = synchronized(lock) {
        val normalized = command.lowercase()
        if (normalized !in setOf("pause", "resume", "cancel")) return@synchronized false
        val current = readTask() ?: return@synchronized false
        if (current.status !in setOf("running", "paused", "interrupted", "recovery_required")) return@synchronized false
        val valid = when (normalized) {
            "pause" -> current.status == "running"
            "resume" -> current.status in setOf("paused", "interrupted", "recovery_required") ||
                current.status == "running" && current.controlRequest == "pause"
            "cancel" -> true
            else -> false
        }
        if (!valid) return@synchronized false
        prefs.edit().putString(KEY_ACTIVE_TASK, gson.toJson(current.copy(controlRequest = normalized, updatedAtMillis = System.currentTimeMillis()))).commit()
    }

    fun updateTaskStatus(taskId: String, status: String) = synchronized(lock) {
        val current = readTask() ?: return@synchronized
        if (current.taskId == taskId) prefs.edit().putString(KEY_ACTIVE_TASK, gson.toJson(current.copy(status = status.take(32), updatedAtMillis = System.currentTimeMillis()))).commit()
    }

    fun taskControl(taskId: String): String = synchronized(lock) {
        readTask()?.takeIf { it.taskId == taskId }?.controlRequest ?: "none"
    }

    fun clearTaskControl(taskId: String, status: String? = null) = synchronized(lock) {
        val current = readTask() ?: return@synchronized
        if (current.taskId != taskId) return@synchronized
        prefs.edit().putString(KEY_ACTIVE_TASK, gson.toJson(current.copy(controlRequest = "none", status = status ?: current.status, updatedAtMillis = System.currentTimeMillis()))).commit()
    }

    fun loadResumableTask(): ResumableTask? = synchronized(lock) {
        val state = readTask() ?: return@synchronized null
        if (state.status !in setOf("running", "paused", "interrupted", "recovery_required")) return@synchronized null
        val objective = runCatching { PrivateTextVault.decrypt(state.objectiveCiphertext) }.getOrDefault("")
        if (objective.isBlank()) return@synchronized null
        ResumableTask(state.taskId, objective, state.packageName, state.selectedRoles, state.completedActionTypes, state.plannedActionCount, state.status, state.updatedAtMillis)
    }

    fun recordFeedback(feedback: UltronActionFeedback) = synchronized(lock) {
        val rows = readList<UltronActionFeedback>(KEY_FEEDBACK).toMutableList()
        rows += feedback.copy(actionType = feedback.actionType.take(48), strategyKey = feedback.strategyKey.take(96))
        val bounded = rows.takeLast(MAX_FEEDBACK)
        prefs.edit().putString(KEY_FEEDBACK, gson.toJson(bounded)).commit()
        val code = when (feedback.outcome) {
            UltronFeedbackOutcome.VERIFIED_SUCCESS -> UltronDiagnosticCodes.ACTION_VERIFIED
            UltronFeedbackOutcome.DISPATCHED_UNVERIFIED -> UltronDiagnosticCodes.ACTION_UNVERIFIED
            UltronFeedbackOutcome.FAILED -> UltronDiagnosticCodes.ACTION_FAILED
            UltronFeedbackOutcome.BLOCKED -> UltronDiagnosticCodes.APPROVAL_BLOCKED
            UltronFeedbackOutcome.CANCELLED -> UltronDiagnosticCodes.ACTION_FAILED
        }
        event(UltronDiagnosticEvent(code, "executor", feedback.durationMillis, feedback.outcome == UltronFeedbackOutcome.VERIFIED_SUCCESS))
    }

    fun feedbackContext(packageName: String?): String = synchronized(lock) {
        val learning = UltronFeedbackLearning(readList(KEY_FEEDBACK))
        learning.summary(packageName, 5)
    }

    fun feedbackSnapshot(): List<UltronActionFeedback> = synchronized(lock) { readList<UltronActionFeedback>(KEY_FEEDBACK).takeLast(100) }

    fun observeScreen(snapshot: UltronWorldSnapshot) = synchronized(lock) {
        val pkg = snapshot.packageName?.takeIf { it.matches(Regex("[A-Za-z0-9_.]{2,180}")) } ?: return@synchronized
        val graph = readGraph()
        val packageNodeId = "app:$pkg"
        val screenNodeId = "screen:${snapshot.fingerprint}"
        graph.putNode(UltronKnowledgeNode(packageNodeId, "app", pkg))
        graph.putNode(UltronKnowledgeNode(screenNodeId, "screen_state", "screen ${snapshot.fingerprint}"))
        graph.link(UltronKnowledgeEdge(packageNodeId, "opened_screen", screenNodeId, 0.6f))
        writeGraph(graph)
    }

    fun knowledgeContext(packageName: String?): String = synchronized(lock) {
        val pkg = packageName?.takeIf { it.isNotBlank() } ?: return@synchronized ""
        val graph = readGraph()
        val nodeId = "app:$pkg"
        graph.related(nodeId, 8).joinToString("\n") { (edge, node) -> "${edge.relation}: ${node.kind} ${node.label}" }.take(500)
    }

    fun event(diagnostic: UltronDiagnosticEvent) = synchronized(lock) {
        val rows = readList<UltronDiagnosticEvent>(KEY_DIAGNOSTICS).toMutableList()
        rows += diagnostic.copy(code = diagnostic.code.take(48), component = diagnostic.component.take(48), durationMillis = diagnostic.durationMillis.coerceAtLeast(0))
        prefs.edit().putString(KEY_DIAGNOSTICS, gson.toJson(rows.takeLast(MAX_DIAGNOSTICS))).commit()
    }

    fun diagnosticsSummary(): String = synchronized(lock) {
        val rows = readList<UltronDiagnosticEvent>(KEY_DIAGNOSTICS).takeLast(30)
        if (rows.isEmpty()) return@synchronized "No agent diagnostics recorded yet."
        val counts = rows.groupBy { it.code }.mapValues { it.value.size }
        "Recent diagnostics: " + counts.entries.joinToString(", ") { "${it.key}=${it.value}" }
    }

    fun clearLearning() = synchronized(lock) {
        prefs.edit().remove(KEY_FEEDBACK).remove(KEY_GRAPH_NODES).remove(KEY_GRAPH_EDGES).remove(KEY_DIAGNOSTICS).apply()
    }

    private fun readTask(): UltronPersistentTaskState? = runCatching { gson.fromJson(prefs.getString(KEY_ACTIVE_TASK, null), UltronPersistentTaskState::class.java) }.getOrNull()

    private inline fun <reified T> readList(key: String): List<T> = runCatching {
        val type = object : TypeToken<List<T>>() {}.type
        gson.fromJson<List<T>>(prefs.getString(key, "[]") ?: "[]", type).orEmpty()
    }.getOrDefault(emptyList())

    private fun readGraph(): UltronKnowledgeGraph = UltronKnowledgeGraph(
        readList(KEY_GRAPH_NODES), readList(KEY_GRAPH_EDGES)
    )

    private fun writeGraph(graph: UltronKnowledgeGraph) {
        prefs.edit().putString(KEY_GRAPH_NODES, gson.toJson(graph.nodes())).putString(KEY_GRAPH_EDGES, gson.toJson(graph.edges())).commit()
    }

    companion object {
        private const val KEY_ACTIVE_TASK = "active_task"
        private const val KEY_FEEDBACK = "feedback"
        private const val KEY_GRAPH_NODES = "knowledge_nodes"
        private const val KEY_GRAPH_EDGES = "knowledge_edges"
        private const val KEY_DIAGNOSTICS = "diagnostics"
        private const val MAX_FEEDBACK = 240
        private const val MAX_DIAGNOSTICS = 160
        private val TERMINAL_TASK_STATES = setOf("completed", "failed", "cancelled", "blocked")
        fun newTaskId(): String = UUID.randomUUID().toString()
    }
}
