package com.ultron.assistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** User opt-in for the persistent wake-word listener. Never enables microphone capture by itself. */
object UltronWakeWordPreferences {
    private const val PREFS = "ultron_wake_word_preferences"
    private const val KEY_ENABLED = "enabled_by_user"
    private const val KEY_BOOT_PENDING = "boot_resume_pending"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ENABLED, enabled)
            .commit()
    }

    fun setBootResumePending(context: Context, pending: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_BOOT_PENDING, pending)
            .apply()
    }

    fun isBootResumePending(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_BOOT_PENDING, false)

    /** Android 14+ blocks microphone FGS startup from BOOT_COMPLETED for ordinary apps. */
    fun requiresUserResumeAfterBoot(sdkInt: Int): Boolean = sdkInt >= 34
}

/**
 * Restores an already user-enabled listener after reboot where Android permits it.
 * On Android 14+ it posts a notification that opens ULTRON in the foreground; the
 * activity then starts the microphone FGS with a visible user interaction.
 */
class UltronBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (!UltronWakeWordPreferences.isEnabled(context)) return

        val microphoneGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (!microphoneGranted || UltronWakeWordPreferences.requiresUserResumeAfterBoot(Build.VERSION.SDK_INT)) {
            UltronWakeWordPreferences.setBootResumePending(context, true)
            showResumeNotification(context, microphoneGranted)
            return
        }

        try {
            val start = Intent(context, UltronWakeWordService::class.java)
                .setAction(UltronWakeWordService.ACTION_RESTORE)
            ContextCompat.startForegroundService(context, start)
        } catch (_: Exception) {
            UltronWakeWordPreferences.setBootResumePending(context, true)
            showResumeNotification(context, microphoneGranted)
        }
    }

    private fun showResumeNotification(context: Context, microphoneGranted: Boolean) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && manager.getNotificationChannel(UltronWakeWordService.BOOT_CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(
                    UltronWakeWordService.BOOT_CHANNEL_ID,
                    "ULTRON wake-word restart",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }
        val open = Intent(context, MainActivity::class.java)
            .setAction(ACTION_RESUME_WAKE)
            .putExtra(EXTRA_RESUME_WAKE, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pending = PendingIntent.getActivity(
            context,
            7312,
            open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val message = if (microphoneGranted) {
            "Tap to resume your previously enabled wake-word listener. Android requires the app to be opened first on this version."
        } else {
            "Microphone permission is missing. Open ULTRON to restore voice activation."
        }
        val notification = NotificationCompat.Builder(context, UltronWakeWordService.BOOT_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ULTRON · Wake word is ready to resume")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .build()
        runCatching { manager.notify(7312, notification) }
    }

    companion object {
        const val ACTION_RESUME_WAKE = "com.ultron.assistant.RESUME_WAKE_AFTER_BOOT"
        const val EXTRA_RESUME_WAKE = "com.ultron.assistant.EXTRA_RESUME_WAKE_AFTER_BOOT"
    }
}
