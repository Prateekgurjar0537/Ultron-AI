package com.ultron.assistant

import android.app.Notification
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.notification.StatusBarNotification
import androidx.documentfile.provider.DocumentFile
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.InputStream
import java.security.MessageDigest
import java.util.UUID
import kotlin.coroutines.resume

/** A deliberately small, auditable interface for skills. Skills receive only the context and grants they need. */
interface UltronSkill {
    val id: String
    val version: Int
    val requiredCapabilities: Set<UltronCapability>
    suspend fun execute(input: Map<String, String>): UltronSkillResult
}

enum class UltronCapability { SCREEN_ACCESSIBILITY, NOTIFICATIONS, CLIPBOARD, FILES, NETWORK_STATE, CAMERA_IMAGES, ROUTINES }
data class UltronSkillResult(val success: Boolean, val summary: String, val data: Map<String, String> = emptyMap())

/** Registry refuses duplicate IDs and exposes metadata only; no downloaded code is loaded dynamically. */
class UltronSkillRegistry {
    private val skills = LinkedHashMap<String, UltronSkill>()
    @Synchronized fun register(skill: UltronSkill) {
        require(skill.id.matches(Regex("[a-z][a-z0-9_.-]{1,63}"))) { "Invalid skill ID" }
        require(skill.version > 0) { "Skill version must be positive" }
        require(!skills.containsKey(skill.id)) { "Skill already registered: ${skill.id}" }
        skills[skill.id] = skill
    }
    @Synchronized fun find(id: String): UltronSkill? = skills[id]
    @Synchronized fun catalog(): List<Triple<String, Int, Set<UltronCapability>>> = skills.values.map { Triple(it.id, it.version, it.requiredCapabilities) }
}

/** Notification intelligence is opt-in and ephemeral. Callers decide whether to summarize content with AI. */
data class UltronNotificationItem(val packageName: String, val title: String, val text: String, val postedAt: Long, val category: Int)
object UltronNotificationIntelligence {
    fun readActive(context: Context): List<UltronNotificationItem> {
        val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty()
        if (!enabled.contains(context.packageName)) return emptyList()
        val service = UltronNotificationListener.current ?: return emptyList()
        return runCatching { service.activeNotifications.orEmpty().mapNotNull(::toItem).sortedByDescending { it.postedAt } }.getOrDefault(emptyList())
    }
    private fun toItem(sbn: StatusBarNotification): UltronNotificationItem? {
        val extras = sbn.notification.extras ?: Bundle.EMPTY
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().take(180)
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty().take(900)
        if (title.isBlank() && text.isBlank()) return null
        // Do not surface OTPs, password-reset codes or card-like numbers to the assistant context.
        val safeText = text.replace(Regex("(?i)\\b(?:otp|one[- ]time password|verification code|passcode)\\b[^\\d]{0,20}\\d{4,8}"), "[verification code hidden]")
            .replace(Regex("\\b(?:\\d[ -]*?){13,19}\\b"), "[number hidden]")
        return UltronNotificationItem(sbn.packageName, title, safeText, sbn.postTime, sbn.notification.category?.hashCode() ?: 0)
    }
}

/** Clipboard helpers intentionally reject likely credentials and one-time codes. */
object UltronClipboardIntelligence {
    private val sensitive = listOf(Regex("(?i)\\b(password|passcode|one[- ]time password|otp|recovery code|secret key)\\b"), Regex("\\b\\d{4,8}\\b"))
    fun read(context: Context): String? {
        val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val value = manager.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString()?.take(20_000) ?: return null
        if (sensitive.any { it.containsMatchIn(value) }) return null
        return value
    }
    fun copy(context: Context, label: String, value: String) {
        require(value.length <= 20_000) { "Clipboard content is too large" }
        val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        manager.setPrimaryClip(ClipData.newPlainText(label.take(80), value))
    }
}

data class UltronNetworkReport(val connected: Boolean, val validatedInternet: Boolean, val transport: String, val metered: Boolean, val roaming: Boolean, val details: String)
object UltronNetworkDiagnostics {
    fun inspect(context: Context): UltronNetworkReport {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val connected = caps != null
        val transport = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile data"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) == true -> "Bluetooth"
            else -> "Offline / unknown"
        }
        val validated = Build.VERSION.SDK_INT >= 23 && caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        return UltronNetworkReport(connected, validated, transport, cm.isActiveNetworkMetered, caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_ROAMING) == false, when { !connected -> "No active network"; validated -> "Network reports validated internet access"; else -> "Connected, but internet validation is unavailable" })
    }
}

/** User-selected Storage Access Framework roots only; no broad storage permission or hidden file traversal. */
object UltronFileIntelligence {
    data class Entry(val name: String, val mimeType: String?, val directory: Boolean, val size: Long, val uri: String)
    fun listChildren(context: Context, treeUri: android.net.Uri): List<Entry> {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
        return root.listFiles().map { Entry(it.name ?: "unnamed", it.type, it.isDirectory, it.length(), it.uri.toString()) }
            .sortedWith(compareByDescending<Entry> { it.directory }.thenBy { it.name.lowercase() })
    }
    fun sha256(context: Context, uri: android.net.Uri): String? = runCatching {
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(16 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
        } ?: return null
        digest.digest().joinToString("") { "%02x".format(it) }
    }.getOrNull()
}

/** Offline on-device OCR helper using the bundled ML Kit Latin recognizer. */
object UltronLocalVision {
    suspend fun readText(context: Context, image: InputImage): String = suspendCancellableCoroutine { continuation ->
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { result -> if (continuation.isActive) continuation.resume(result.text) ; recognizer.close() }
            .addOnFailureListener { error -> if (continuation.isActive) continuation.resume("OCR failed: ${error.message ?: "unknown error"}"); recognizer.close() }
        continuation.invokeOnCancellation { recognizer.close() }
    }
}

/** Explicit, inspectable routine definitions. Schedules are stored as data; execution adapters must be granted separately. */
data class UltronRoutine(val id: String = UUID.randomUUID().toString(), val name: String, val command: String, val enabled: Boolean = true, val triggerAtMillis: Long = 0L, val repeatIntervalMillis: Long = 0L, val conditions: List<String> = emptyList(), val lastRunAtMillis: Long = 0L, val pendingRunSlot: Long = -1L)
class UltronRoutineStore(private val context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("ultron_routines_v1", Context.MODE_PRIVATE)
    @Synchronized fun all(): List<UltronRoutine> = runCatching {
        val json = prefs.getString("items", "[]") ?: "[]"
        com.google.gson.Gson().fromJson(json, Array<UltronRoutine>::class.java)?.toList().orEmpty().map { row ->
            row.copy(
                name = runCatching { PrivateTextVault.decrypt(row.name) }.getOrDefault("Saved routine"),
                command = runCatching { PrivateTextVault.decrypt(row.command) }.getOrDefault("")
            )
        }
    }.getOrDefault(emptyList())
    @Synchronized fun find(id: String): UltronRoutine? = all().firstOrNull { it.id == id }
    @Synchronized fun save(routine: UltronRoutine) {
        require(routine.name.isNotBlank() && routine.name.length <= 80) { "Routine name is required" }
        require(routine.command.isNotBlank() && routine.command.length <= 2_000) { "Routine command is required" }
        require(routine.repeatIntervalMillis >= 0L && routine.triggerAtMillis >= 0L && routine.lastRunAtMillis >= 0L && routine.pendingRunSlot >= -1L) { "Invalid schedule" }
        require(routine.repeatIntervalMillis == 0L || routine.repeatIntervalMillis >= UltronRoutineScheduler.MIN_REPEAT_INTERVAL_MILLIS) { "Repeating routines must be at least 15 minutes apart." }
        val next = all().filterNot { it.id == routine.id } + routine
        val protected = next.map { row -> row.copy(name = PrivateTextVault.encrypt(row.name), command = PrivateTextVault.encrypt(row.command)) }
        check(prefs.edit().putString("items", com.google.gson.Gson().toJson(protected)).commit()) { "Could not save routine" }
    }
    @Synchronized fun delete(id: String) {
        UltronRoutineScheduler.cancel(context, id)
        val protected = all().filterNot { it.id == id }.map { row ->
            row.copy(name = PrivateTextVault.encrypt(row.name), command = PrivateTextVault.encrypt(row.command))
        }
        prefs.edit().putString("items", com.google.gson.Gson().toJson(protected)).apply()
    }
}

/** Sandboxed app-builder foundation: stores declarative project files under app-private storage, never executes generated code. */
class UltronAppProjectWorkspace(context: Context) {
    private val root = java.io.File(context.filesDir, "generated-projects").apply { mkdirs() }
    fun createProject(name: String, files: Map<String, String>): java.io.File {
        require(name.matches(Regex("[A-Za-z0-9_-]{1,48}"))) { "Invalid project name" }
        require(files.isNotEmpty() && files.size <= 100) { "Project must contain 1–100 files" }
        val dir = java.io.File(root, name).canonicalFile
        require(dir.parentFile == root.canonicalFile) { "Invalid project path" }
        files.forEach { (relative, content) ->
            require(relative.length <= 180 && content.length <= 200_000) { "Project file is too large" }
            val target = java.io.File(dir, relative).canonicalFile
            require(target.path.startsWith(dir.path + java.io.File.separator)) { "Path traversal rejected" }
            target.parentFile?.mkdirs()
            target.writeText(content, Charsets.UTF_8)
        }
        return dir
    }
}
