package com.ultron.assistant

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Entity(
    tableName = "chat_messages",
    indices = [Index("createdAt"), Index(value = ["conversationId", "archived", "createdAt"])]
)
data class ChatRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val createdAt: Long = System.currentTimeMillis(),
    /** Old pre-session rows migrate into the archived legacy conversation. */
    @ColumnInfo(defaultValue = "'legacy'") val conversationId: String = "legacy",
    @ColumnInfo(defaultValue = "1") val archived: Boolean = true
)

@Entity(tableName = "chat_archives", indices = [Index("expiresAt")])
data class ChatArchiveRecord(
    @PrimaryKey val conversationId: String,
    /** AES-GCM encrypted compact transcript index used for relevant future retrieval. */
    val summary: String,
    val archivedAt: Long,
    val expiresAt: Long,
    val messageCount: Int
)

@Entity(tableName = "memories", indices = [Index(value = ["key"], unique = true)])
data class MemoryRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val value: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes", indices = [Index("createdAt")])
data class NoteRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "documents", indices = [Index("createdAt")])
data class DocumentRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val mimeType: String,
    val extractedText: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ChatDao {
    @Insert suspend fun insert(record: ChatRecord): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertArchive(record: ChatArchiveRecord)
    @Query("SELECT * FROM chat_messages WHERE conversationId = :conversationId AND archived = 0 ORDER BY createdAt ASC, id ASC LIMIT :limit") suspend fun activeConversation(conversationId: String, limit: Int): List<ChatRecord>
    @Query("SELECT * FROM chat_messages WHERE conversationId = :conversationId ORDER BY createdAt ASC, id ASC") suspend fun conversationMessages(conversationId: String): List<ChatRecord>
    @Query("UPDATE chat_messages SET archived = 1 WHERE conversationId = :conversationId") suspend fun markConversationArchived(conversationId: String): Int
    @Query("SELECT * FROM chat_archives WHERE expiresAt > :now ORDER BY archivedAt DESC LIMIT :limit") suspend fun recentArchives(now: Long, limit: Int): List<ChatArchiveRecord>
    @Query("SELECT * FROM chat_messages WHERE conversationId = :conversationId AND archived = 1 ORDER BY createdAt DESC, id DESC LIMIT :limit") suspend fun archivedMessages(conversationId: String, limit: Int): List<ChatRecord>
    @Query("SELECT conversationId FROM chat_archives WHERE expiresAt <= :now") suspend fun expiredArchiveIds(now: Long): List<String>
    @Query("DELETE FROM chat_messages WHERE conversationId = :conversationId") suspend fun deleteConversation(conversationId: String): Int
    @Query("DELETE FROM chat_archives WHERE conversationId = :conversationId") suspend fun deleteArchive(conversationId: String): Int
    @Query("DELETE FROM chat_messages WHERE archived = 1 AND conversationId = 'legacy' AND createdAt < :cutoff") suspend fun deleteExpiredLegacy(cutoff: Long): Int
    @Query("SELECT * FROM chat_messages ORDER BY createdAt DESC, id DESC LIMIT :limit") suspend fun latest(limit: Int): List<ChatRecord>
    @Query("DELETE FROM chat_messages") suspend fun clear()
    @Query("DELETE FROM chat_archives") suspend fun clearArchives()
}

@Dao
interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(record: MemoryRecord)
    @Query("SELECT * FROM memories ORDER BY createdAt DESC") suspend fun all(): List<MemoryRecord>
    @Query("SELECT * FROM memories WHERE `key` LIKE '%' || :query || '%' OR `value` LIKE '%' || :query || '%' ORDER BY createdAt DESC LIMIT 12") suspend fun search(query: String): List<MemoryRecord>
    @Query("DELETE FROM memories") suspend fun clear()
    @Query("DELETE FROM memories WHERE `key` = :key") suspend fun deleteByKey(key: String): Int
}

@Dao
interface NoteDao {
    @Insert suspend fun insert(record: NoteRecord): Long
    @Query("SELECT * FROM notes ORDER BY createdAt DESC LIMIT :limit") suspend fun latest(limit: Int): List<NoteRecord>
    @Query("DELETE FROM notes WHERE id = :id") suspend fun delete(id: Long): Int
}

@Dao
interface DocumentDao {
    @Insert suspend fun insert(record: DocumentRecord): Long
    @Query("SELECT * FROM documents ORDER BY createdAt DESC LIMIT :limit") suspend fun latest(limit: Int): List<DocumentRecord>
    @Query("DELETE FROM documents WHERE id = :id") suspend fun delete(id: Long): Int
    @Query("DELETE FROM documents") suspend fun clear()
}

@Database(
    entities = [ChatRecord::class, ChatArchiveRecord::class, MemoryRecord::class, NoteRecord::class, DocumentRecord::class],
    version = 2,
    exportSchema = false
)
abstract class UltronDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
    abstract fun noteDao(): NoteDao
    abstract fun documentDao(): DocumentDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN conversationId TEXT NOT NULL DEFAULT 'legacy'")
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN archived INTEGER NOT NULL DEFAULT 1")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_chat_messages_conversationId_archived_createdAt ON chat_messages (conversationId, archived, createdAt)")
                db.execSQL("CREATE TABLE IF NOT EXISTS chat_archives (conversationId TEXT NOT NULL, summary TEXT NOT NULL, archivedAt INTEGER NOT NULL, expiresAt INTEGER NOT NULL, messageCount INTEGER NOT NULL, PRIMARY KEY(conversationId))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_chat_archives_expiresAt ON chat_archives (expiresAt)")
            }
        }

        @Volatile private var INSTANCE: UltronDatabase? = null
        fun get(context: Context): UltronDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, UltronDatabase::class.java, "ultron-private.db")
                .addMigrations(MIGRATION_1_2)
                .fallbackToDestructiveMigration()
                .build().also { INSTANCE = it }
        }
    }
}
