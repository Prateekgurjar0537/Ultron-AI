package com.ultron.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import java.util.Locale

/** User-opt-in microphone foreground service. Android's recognizer is restarted after every result/error. */
class UltronWakeWordService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private val restartRunnable = Runnable { if (!destroyed && recognizer != null) startListening() }
    /** A broken OEM recognizer can stop issuing callbacks without reporting an error. */
    private val sessionWatchdog = object : Runnable {
        override fun run() {
            if (destroyed || recognizer == null) return
            val elapsed = SystemClock.elapsedRealtime() - recognizerSessionStartedAt
            val startupExpired = !recognizerReady && elapsed >= STARTUP_READY_TIMEOUT_MS
            val sessionExpired = elapsed >= MAX_RECOGNIZER_SESSION_MS
            if (startupExpired || sessionExpired) {
                listening = false
                recognizerReady = false
                val reason = if (startupExpired) "Recognizer did not report ready within ${STARTUP_READY_TIMEOUT_MS / 1_000}s" else "Recognition session reached its refresh limit"
                val retryDelay = if (startupExpired) {
                    consecutiveErrors = (consecutiveErrors + 1).coerceAtMost(5)
                    (1_000L * (1L shl (consecutiveErrors - 1))).coerceAtMost(16_000L)
                } else {
                    consecutiveErrors = 0
                    450L
                }
                UltronWakeWordHealth.recovering(this@UltronWakeWordService, reason)
                runCatching { recognizer?.cancel(); recognizer?.destroy() }
                recognizer = null
                recognizerGeneration++ // Ignore late callbacks from the discarded provider instance.
                updateNotification("$reason · retrying in ${retryDelay / 1_000.0}s…", ongoing = true)
                main.postDelayed({ if (!destroyed) startRecognizer() }, retryDelay)
            } else {
                val nextCheck = if (recognizerReady) MAX_RECOGNIZER_SESSION_MS - elapsed else STARTUP_READY_TIMEOUT_MS - elapsed
                main.postDelayed(this, nextCheck.coerceAtLeast(250L))
            }
        }
    }
    private var destroyed = false
    private var recognizerSessionStartedAt = 0L
    /** Incremented whenever the provider instance is replaced; late callbacks from older OEM sessions are ignored. */
    private var recognizerGeneration = 0L
    private var recognizerReady = false
    private var lastDetectedAt = 0L
    private var awaitingCommand = false
    private var awaitingCommandAt = 0L
    private var consecutiveErrors = 0
    private var listening = false
    private var latestPartialPhrase = ""
    private var partialWakeNotified = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                UltronWakeWordPreferences.setEnabled(this, false)
                UltronWakeWordPreferences.setBootResumePending(this, false)
                UltronWakeWordHealth.stopped(this)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> UltronWakeWordPreferences.setEnabled(this, true)
            ACTION_RESTORE -> if (!UltronWakeWordPreferences.isEnabled(this)) {
                UltronWakeWordHealth.stopped(this, "Wake-word opt-in is disabled")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        if (intent == null && !UltronWakeWordPreferences.isEnabled(this)) {
            UltronWakeWordHealth.stopped(this, "Wake-word opt-in is disabled")
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            UltronWakeWordHealth.stopped(this, "Microphone permission missing")
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        val foregroundNotification = buildNotification("Starting the Android speech-recognition provider…", ongoing = true)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, foregroundNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIFICATION_ID, foregroundNotification)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            UltronWakeWordHealth.error(this, SpeechRecognizer.ERROR_CLIENT, "No speech recognition service is installed or enabled")
            updateNotification("NO SPEECH PROVIDER · Open Android voice input settings and enable speech recognition.", ongoing = false)
            stopSelf()
            return START_NOT_STICKY
        }
        UltronWakeWordPreferences.setBootResumePending(this, false)
        if (recognizer == null) startRecognizer()
        return START_STICKY
    }

    private fun startRecognizer() {
        main.removeCallbacks(sessionWatchdog)
        val onDeviceAvailable = Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
        val providerDescription = if (onDeviceAvailable) "On-device speech recognizer" else "Installed Android speech recognizer (network/offline behavior depends on provider)"
        UltronWakeWordHealth.starting(this, providerDescription)
        recognizerReady = false
        val sessionGeneration = ++recognizerGeneration
        val speech = try {
            if (onDeviceAvailable) {
                runCatching { SpeechRecognizer.createOnDeviceSpeechRecognizer(this) }
                    .getOrElse { SpeechRecognizer.createSpeechRecognizer(this) }
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
        } catch (error: Exception) {
            UltronWakeWordHealth.error(this, SpeechRecognizer.ERROR_CLIENT, error.message ?: "Speech recognizer unavailable")
            updateNotification("Speech engine could not start: ${error.message ?: "recognizer unavailable"}", ongoing = false)
            stopSelf()
            return
        }
        recognizer = speech.also {
            val speech = it
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {
                    if (!isCurrentSession(sessionGeneration)) return
                    consecutiveErrors = 0
                    recognizerReady = true
                    listening = true
                    UltronWakeWordHealth.ready(this@UltronWakeWordService)
                    updateNotification("Speech provider ready · waiting for speech. Say ‘ULTRON’ then your command.", ongoing = true)
                }
                override fun onBeginningOfSpeech() {
                    if (!isCurrentSession(sessionGeneration)) return
                    updateNotification("Speech detected · recognizing your words…", ongoing = true)
                }
                override fun onRmsChanged(rmsdB: Float) {
                    if (!isCurrentSession(sessionGeneration)) return
                    if (rmsdB.isFinite()) UltronWakeWordHealth.audioCallback(this@UltronWakeWordService)
                }
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() { if (isCurrentSession(sessionGeneration)) listening = false }
                override fun onError(error: Int) {
                    if (!isCurrentSession(sessionGeneration)) return
                    listening = false
                    recognizerReady = false
                    UltronWakeWordHealth.error(this@UltronWakeWordService, error, speechErrorName(error))
                    main.removeCallbacks(sessionWatchdog)
                    // Several OEM speech services (including older Android builds) emit a
                    // useful partial wake phrase and then ERROR_NO_MATCH instead of onResults.
                    // Preserve and process that hypothesis before clearing it; otherwise the
                    // notification can say LISTENING forever while the wake word is discarded.
                    val partial = latestPartialPhrase.trim()
                    latestPartialPhrase = ""
                    partialWakeNotified = false
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        val normalizedPartial = partial.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9\\u0900-\\u097f ]"), " ").replace(Regex("\\s+"), " ").trim()
                        if (partial.isNotBlank() && UltronWakeWordPhrase.containsWakeWord(normalizedPartial)) {
                            handleRecognizedPhrase(partial)
                        }
                    }
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        updateNotification("MICROPHONE PERMISSION REQUIRED · Open ULTRON to review permissions.", ongoing = false)
                        stopSelf()
                    } else {
                        // A no-match/silence is normal during wake-word standby. Do not let
                        // exponential backoff make ULTRON appear enabled while deaf for minutes.
                        val transientSilence = error == SpeechRecognizer.ERROR_NO_MATCH ||
                            error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                        val busyOrClient = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                            error == SpeechRecognizer.ERROR_CLIENT
                        val delay = when {
                            transientSilence -> 350L
                            busyOrClient -> 900L
                            else -> {
                                consecutiveErrors = (consecutiveErrors + 1).coerceAtMost(5)
                                (1_000L * (1L shl (consecutiveErrors - 1))).coerceAtMost(16_000L)
                            }
                        }
                        updateNotification("Recognizer recovering after speech status $error in ${delay / 1_000}s…", ongoing = true)
                        when {
                            transientSilence -> scheduleRestart(delay)
                            busyOrClient -> scheduleRecognizerRecovery(delay)
                            else -> scheduleRecognizerRecovery(delay)
                        }
                    }
                }
                override fun onResults(results: android.os.Bundle?) {
                    if (!isCurrentSession(sessionGeneration)) return
                    listening = false
                    recognizerReady = false
                    UltronWakeWordHealth.recognized(this@UltronWakeWordService)
                    main.removeCallbacks(sessionWatchdog)
                    val finalPhrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    // Merge shortened OEM final hypotheses with the richest partial without
                    // losing command words or dispatching an incomplete partial on its own.
                    val phrase = UltronWakeWordPhrase.bestPhrase(latestPartialPhrase, finalPhrase)
                    latestPartialPhrase = ""
                    partialWakeNotified = false
                    handleRecognizedPhrase(phrase)
                    scheduleRestart(450)
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {
                    if (!isCurrentSession(sessionGeneration)) return
                    // Partial hypotheses are often incomplete (for example, "ULTRON open")
                    // and must NEVER dispatch a command. Keep the richest hypothesis and wait
                    // for onResults, otherwise the final words can be lost on slower devices.
                    val phrase = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (phrase.isNotBlank() && phrase.length >= latestPartialPhrase.length) latestPartialPhrase = phrase
                    val normalized = phrase.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9\\u0900-\\u097f ]"), " ").replace(Regex("\\s+"), " ").trim()
                    val containsWake = UltronWakeWordPhrase.containsWakeWord(normalized)
                    if (containsWake && !partialWakeNotified) {
                        partialWakeNotified = true
                        updateNotification("Wake word heard · finishing command recognition…", ongoing = true)
                    }
                }
                override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
            })
        }
        startListening()
    }

    private fun handleRecognizedPhrase(raw: String) {
        val phrase = raw.trim()
        val normalized = phrase.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9\\u0900-\\u097f ]"), " ").replace(Regex("\\s+"), " ").trim()
        val commandAfterWake = UltronWakeWordPhrase.commandAfterWakeWord(normalized)
        val containsWake = commandAfterWake != null
        if (awaitingCommand) {
            val withinCommandWindow = System.currentTimeMillis() - awaitingCommandAt <= 12_000L
            if (!withinCommandWindow) {
                awaitingCommand = false
            } else {
                val command = if (containsWake) commandAfterWake.orEmpty() else normalized
                if (command.isBlank()) {
                    // A repeated wake token is not a command; keep the short command window open.
                    updateNotification("Wake word heard · say your command now.", ongoing = true)
                    return
                }
                awaitingCommand = false
                enqueueBackgroundCommand(command)
                updateNotification("Command received · returning to wake-word standby.", ongoing = true)
                return
            }
        }
        if (containsWake && System.currentTimeMillis() - lastDetectedAt > 2_500L) {
            lastDetectedAt = System.currentTimeMillis()
            UltronWakeWordHealth.wakeDetected(this)
            val command = commandAfterWake.orEmpty()
            if (command.isNotBlank()) enqueueBackgroundCommand(command)
            else {
                awaitingCommand = true
                awaitingCommandAt = System.currentTimeMillis()
                updateNotification("Wake word detected. Say your command within 12 seconds…", ongoing = true)
                val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                runCatching { manager.notify(DETECTED_NOTIFICATION_ID, buildNotification("I heard ‘Ultron’. Say your command now.", ongoing = false)) }
            }
        }
    }

    private fun enqueueBackgroundCommand(command: String) {
        val decision = UltronApprovalCommandParser.parse(command)
        if (decision != null) {
            val pendingId = UltronPendingActionStore.latestId(applicationContext)
            if (!pendingId.isNullOrBlank() && UltronPendingActionStore.load(applicationContext, pendingId) != null) {
                val approve = decision == UltronApprovalDecision.APPROVE
                UltronAgentApprovalReceiver.applyDecision(applicationContext, pendingId, approve)
                updateNotification(if (approve) "Voice YES received · executing approved task…" else "Voice NO received · task cancelled.", ongoing = true)
                return
            }
        }
        updateNotification("ULTRON AI agent is planning your command in the background…", ongoing = true)
        try {
            UltronAgentWorker.enqueue(applicationContext, command)
            UltronAgentNotifications.show(applicationContext, "ULTRON · Command received", "Working on: ${command.take(180)}", 7330)
        } catch (e: Exception) {
            updateNotification("Could not queue command: ${e.message ?: "background scheduler error"}", ongoing = true)
        }
    }

    private fun startListening() {
        val speech = recognizer ?: return
        if (listening) return
        listening = false
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            UltronWakeWordHealth.stopped(this, "Microphone permission missing")
            stopSelf(); return
        }
        latestPartialPhrase = ""
        partialWakeNotified = false
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val selectedLanguage = VoiceOutputStore(this@UltronWakeWordService).load().language
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLanguage)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, selectedLanguage)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Do not force offline recognition: Android 8.x OEM builds frequently have no
            // downloaded offline model, which otherwise produces endless NO_MATCH callbacks.
            // Let the installed recognition provider choose its available network/offline path.
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        }
        recognizerSessionStartedAt = SystemClock.elapsedRealtime()
        recognizerReady = false
        main.removeCallbacks(sessionWatchdog)
        main.postDelayed(sessionWatchdog, STARTUP_READY_TIMEOUT_MS)
        val started = runCatching { speech.startListening(intent) }
        if (started.isFailure) {
            listening = false
            main.removeCallbacks(sessionWatchdog)
            updateNotification("Speech engine failed to start; rebuilding listener…", ongoing = true)
            // Recreate the recognizer after a synchronous start failure; retrying the same
            // broken OEM instance can otherwise leave the listener permanently idle.
            scheduleRecognizerRecovery(900)
        }
    }

    private fun isCurrentSession(generation: Long): Boolean = !destroyed && generation == recognizerGeneration

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, delayMs)
    }

    private fun scheduleRecognizerRecovery(delayMs: Long) {
        main.removeCallbacks(restartRunnable)
        main.removeCallbacks(sessionWatchdog)
        listening = false
        recognizerReady = false
        recognizerGeneration++ // Old provider callbacks must not act during the recovery delay.
        runCatching { recognizer?.cancel(); recognizer?.destroy() }
        recognizer = null
        UltronWakeWordHealth.recovering(this, "Rebuilding recognizer after provider callback failure")
        main.postDelayed({
            if (destroyed) return@postDelayed
            startRecognizer()
        }, delayMs.coerceIn(250L, 30_000L))
    }

    private fun speechErrorName(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio input error"
        SpeechRecognizer.ERROR_CLIENT -> "Speech client error"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission denied"
        SpeechRecognizer.ERROR_NETWORK -> "Speech provider network error"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech provider network timeout"
        SpeechRecognizer.ERROR_NO_MATCH -> "No speech match (normal during standby)"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy"
        SpeechRecognizer.ERROR_SERVER -> "Speech provider server error"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected (normal during standby)"
        else -> "Speech provider error $code"
    }

    private fun showWakeNotification() {
        updateNotification("Wake word detected. Say your command; ULTRON will process it in the background.", ongoing = true)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "ULTRON wake word", NotificationManager.IMPORTANCE_LOW))
            }
            if (manager.getNotificationChannel(DETECTED_CHANNEL_ID) == null) {
                manager.createNotificationChannel(NotificationChannel(DETECTED_CHANNEL_ID, "ULTRON wake word detected", NotificationManager.IMPORTANCE_HIGH))
            }
            if (manager.getNotificationChannel(BOOT_CHANNEL_ID) == null) {
                manager.createNotificationChannel(NotificationChannel(BOOT_CHANNEL_ID, "ULTRON wake-word restart", NotificationManager.IMPORTANCE_DEFAULT))
            }
        }
    }

    private fun updateNotification(text: String, ongoing: Boolean) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        runCatching { manager.notify(NOTIFICATION_ID, buildNotification(text, ongoing)) }
    }

    private fun buildNotification(text: String, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 314, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 315, Intent(this, UltronWakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, if (ongoing) CHANNEL_ID else DETECTED_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (ongoing) "ULTRON · Wake word" else "ULTRON")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(ongoing)
            .addAction(android.R.drawable.ic_media_pause, "Stop listening", stop)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        main.removeCallbacks(restartRunnable)
        main.removeCallbacks(sessionWatchdog)
        destroyed = true
        runCatching { recognizer?.cancel(); recognizer?.destroy() }
        recognizer = null
        recognizerGeneration++
        listening = false
        recognizerReady = false
        val healthStatus = UltronWakeWordHealth.snapshot(this).status
        if (healthStatus != "STOPPED" && healthStatus != "ERROR · recovering" && healthStatus != "RECOVERING") {
            UltronWakeWordHealth.stopped(this, "Service stopped or restarted by Android")
        }
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.ultron.assistant.WAKE_WORD_START"
        const val ACTION_STOP = "com.ultron.assistant.WAKE_WORD_STOP"
        const val ACTION_RESTORE = "com.ultron.assistant.WAKE_WORD_RESTORE"
        const val EXTRA_WAKE_COMMAND = "com.ultron.assistant.EXTRA_WAKE_COMMAND"
        const val CHANNEL_ID = "ultron_wake_word"
        const val DETECTED_CHANNEL_ID = "ultron_wake_detected"
        const val BOOT_CHANNEL_ID = "ultron_wake_boot"
        const val NOTIFICATION_ID = 7310
        const val DETECTED_NOTIFICATION_ID = 7311
        private const val STARTUP_READY_TIMEOUT_MS = 12_000L
        private const val MAX_RECOGNIZER_SESSION_MS = 60_000L
    }
}
