package com.ultron.assistant

import android.content.Context
import android.net.Uri
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

enum class InferenceMode { LOCAL, ONLINE, HYBRID }

data class ChatMessage(val role: String, val content: String, val imageDataUrl: String? = null)
data class LlmSettings(
    val mode: InferenceMode,
    val baseUrl: String,
    val model: String,
    val apiKey: String,
    /** Must not exceed the context size configured by the remote model server. */
    val contextWindowTokens: Int = 4096,
    /** Explicit OpenAI-compatible max_tokens cap; avoids unbounded server-side generation. */
    val maxOutputTokens: Int = 256
)
data class InferenceResult(val text: String, val provider: String)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("ultron_inference", Context.MODE_PRIVATE)
    fun load(): LlmSettings {
        val encrypted = prefs.getString("apiKeyCipher", null)
        val key = if (encrypted != null) runCatching { ApiKeyVault.decrypt(encrypted) }.getOrDefault("") else migrateLegacyKey()
        return LlmSettings(
            mode = runCatching { InferenceMode.valueOf(prefs.getString("mode", "ONLINE")!!) }.getOrDefault(InferenceMode.ONLINE),
            baseUrl = prefs.getString("baseUrl", "") ?: "",
            model = prefs.getString("model", "your-model-id") ?: "",
            apiKey = key,
            contextWindowTokens = prefs.getInt("contextWindowTokens", 4096).coerceIn(2048, 32768),
            maxOutputTokens = prefs.getInt("maxOutputTokens", 256).coerceIn(64, 1024)
        )
    }
    fun save(s: LlmSettings) {
        val encryptedKey = if (s.apiKey.isBlank()) "" else ApiKeyVault.encrypt(s.apiKey)
        prefs.edit().putString("mode", s.mode.name).putString("baseUrl", s.baseUrl.trim().trimEnd('/'))
            .putString("model", s.model.trim()).putString("apiKeyCipher", encryptedKey)
            .putInt("contextWindowTokens", s.contextWindowTokens.coerceIn(2048, 32768))
            .putInt("maxOutputTokens", s.maxOutputTokens.coerceIn(64, 1024))
            .remove("apiKey").apply()
    }
    private fun migrateLegacyKey(): String {
        val legacy = prefs.getString("apiKey", "").orEmpty()
        if (legacy.isNotBlank()) runCatching {
            prefs.edit().putString("apiKeyCipher", ApiKeyVault.encrypt(legacy)).remove("apiKey").apply()
        }
        return legacy
    }
}

/** AES-GCM using an app-specific non-exportable Android Keystore key (API 23+). */
private object ApiKeyVault {
    private const val ALIAS = "ultron_api_key_aes_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return generator.generateKey()
    }

    fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    fun decrypt(value: String): String {
        val packed = Base64.decode(value, Base64.NO_WRAP)
        require(packed.size > 12) { "Saved API token has invalid encrypted data." }
        val iv = packed.copyOfRange(0, 12)
        val data = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(data), Charsets.UTF_8)
    }
}


data class AiEndpointProfile(
    val id: String,
    val name: String,
    val role: String,
    val baseUrl: String,
    val model: String,
    val apiKey: String,
    val enabled: Boolean = true,
    val contextWindowTokens: Int = 4096,
    val maxOutputTokens: Int = 256
) {
    fun asSettings() = LlmSettings(
        InferenceMode.ONLINE, baseUrl, model, apiKey,
        contextWindowTokens.coerceIn(2048, 32768), maxOutputTokens.coerceIn(64, 1024)
    )
}

/** Deterministic routing keeps each configured model in its intended specialist role. */
object UltronAiRoleRouting {
    fun normalize(role: String): String = when (role.trim().lowercase()) {
        "general", "planner", "assistant" -> "general"
        "vision", "visual", "image" -> "vision"
        "coding", "code", "developer" -> "coding"
        else -> role.trim().lowercase().ifBlank { "custom" }
    }

    fun profileForRole(profiles: List<AiEndpointProfile>, role: String): AiEndpointProfile? {
        val wanted = normalize(role)
        return profiles.firstOrNull { it.enabled && normalize(it.role) == wanted && it.baseUrl.isNotBlank() && it.model.isNotBlank() }
    }

    fun canAnalyzeLiveScreen(profile: AiEndpointProfile?, captureActive: Boolean, sharingEnabled: Boolean, imageAvailable: Boolean): Boolean =
        profile != null && normalize(profile.role) == "vision" && captureActive && sharingEnabled && imageAvailable

    fun isCodingRequest(text: String): Boolean = Regex(
        "(?i)\\b(write\\s+code|source\\s+code|code\\s+review|program|programming|debug|refactor|compile|build\\s+(?:an?\\s+)?(?:app|apk|project)|implement\\s+(?:a\\s+)?(?:feature|function|class|module)|kotlin|java|python|javascript|typescript|html|css|sql|gradle|stack\\s+trace|unit\\s+test|api\\s+endpoint|function|class|script)\\b"
    ).containsMatchIn(text)
}

/** User-defined OpenAI-compatible online endpoints. API keys are encrypted independently. */
class AiProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("ultron_ai_profiles", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun load(): List<AiEndpointProfile> = runCatching {
        val array = gson.fromJson(prefs.getString("profiles", "[]"), com.google.gson.JsonArray::class.java) ?: return emptyList()
        array.mapNotNull { element ->
            runCatching {
                val item = element.asJsonObject
                val encrypted = item.get("apiKeyCipher")?.asString.orEmpty()
                AiEndpointProfile(
                    id = item.get("id").asString,
                    name = item.get("name").asString,
                    role = item.get("role")?.asString ?: "general",
                    baseUrl = item.get("baseUrl").asString,
                    model = item.get("model").asString,
                    apiKey = if (encrypted.isBlank()) "" else ApiKeyVault.decrypt(encrypted),
                    enabled = item.get("enabled")?.asBoolean ?: true,
                    contextWindowTokens = item.get("contextWindowTokens")?.asInt?.coerceIn(2048, 32768) ?: 4096,
                    maxOutputTokens = item.get("maxOutputTokens")?.asInt?.coerceIn(64, 1024) ?: 256
                )
            }.getOrNull()
        }
    }.getOrDefault(emptyList())

    fun activeProfileId(): String = prefs.getString("active_profile_id", "default") ?: "default"

    fun setActiveProfileId(id: String) {
        prefs.edit().putString("active_profile_id", id.ifBlank { "default" }).apply()
    }

    fun save(profiles: List<AiEndpointProfile>) {
        val array = com.google.gson.JsonArray()
        profiles.forEach { profile ->
            val item = JsonObject().apply {
                addProperty("id", profile.id); addProperty("name", profile.name)
                addProperty("role", profile.role); addProperty("baseUrl", profile.baseUrl.trim().trimEnd('/'))
                addProperty("model", profile.model.trim())
                addProperty("apiKeyCipher", if (profile.apiKey.isBlank()) "" else ApiKeyVault.encrypt(profile.apiKey))
                addProperty("enabled", profile.enabled)
                addProperty("contextWindowTokens", profile.contextWindowTokens.coerceIn(2048, 32768))
                addProperty("maxOutputTokens", profile.maxOutputTokens.coerceIn(64, 1024))
            }
            array.add(item)
        }
        prefs.edit().putString("profiles", gson.toJson(array)).apply()
    }
}

interface InferenceProvider {
    suspend fun complete(messages: List<ChatMessage>, settings: LlmSettings): InferenceResult
}

/** Approximate token accounting for prompt budgeting. This is intentionally conservative and is not a tokenizer. */
object UltronTokenBudget {
    fun estimate(messages: List<ChatMessage>): Int = messages.sumOf { message ->
        // ASCII prose averages roughly four characters/token; non-ASCII scripts (including
        // Hindi/Devanagari) are budgeted more conservatively to reduce context overflow.
        val asciiChars = message.content.count { it.code < 128 }
        val nonAsciiChars = message.content.length - asciiChars
        val textTokens = ((asciiChars + 3) / 4) + ((nonAsciiChars + 1) / 2)
        val imageTokens = if (message.imageDataUrl.isNullOrBlank()) 0 else 768
        textTokens.coerceAtLeast(1) + imageTokens + 8
    }

    fun fit(messages: List<ChatMessage>, settings: LlmSettings): List<ChatMessage> {
        if (messages.isEmpty()) return messages
        val context = settings.contextWindowTokens.coerceIn(512, 32768)
        val output = settings.maxOutputTokens.coerceIn(64, 1024)
        val inputBudget = (context - output - 96).coerceIn(128, (context - 64).coerceAtLeast(128))
        val system = messages.filter { it.role == "system" }
        val dialogue = messages.filterNot { it.role == "system" }

        // Reserve a bounded portion for system instructions, but never let a long imported
        // document or memory excerpt consume the entire small-device context window.
        var systemRemaining = (inputBudget * 0.32).toInt().coerceIn(96, 900)
        val fittedSystem = system.mapNotNull { message ->
            if (systemRemaining <= 8) return@mapNotNull null
            val fullCost = estimate(listOf(message))
            if (fullCost <= systemRemaining) {
                systemRemaining -= fullCost
                message
            } else {
                val maxChars = ((systemRemaining - 8).coerceAtLeast(24) * 3).coerceAtMost(message.content.length)
                if (maxChars <= 0) null else {
                    systemRemaining = 0
                    message.copy(content = message.content.take(maxChars).trimEnd() + "\n[System context shortened to fit the local model window.]")
                }
            }
        }
        val usedSystem = estimate(fittedSystem)
        var remaining = (inputBudget - usedSystem).coerceAtLeast(64)
        if (dialogue.isEmpty()) return fittedSystem

        // The current user instruction always wins over stale conversation turns.
        val latestUserIndex = dialogue.indexOfLast { it.role == "user" }
        val selected = mutableMapOf<Int, ChatMessage>()
        if (latestUserIndex >= 0) {
            val latest = dialogue[latestUserIndex]
            val cost = estimate(listOf(latest))
            val fitted = if (cost <= remaining) latest else {
                val maxChars = ((remaining - 8).coerceAtLeast(32) * 3).coerceAtMost(latest.content.length)
                latest.copy(content = latest.content.take(maxChars).trimEnd() + "\n[Request shortened to fit the local model window.]")
            }
            selected[latestUserIndex] = fitted
            remaining = (remaining - estimate(listOf(fitted))).coerceAtLeast(0)
        }
        // Fill remaining budget from the newest prior turns, retaining original order later.
        for (index in dialogue.indices.reversed()) {
            if (index == latestUserIndex || remaining <= 0) continue
            val message = dialogue[index]
            val cost = estimate(listOf(message))
            if (cost <= remaining) {
                selected[index] = message
                remaining -= cost
            }
        }
        return fittedSystem + selected.toSortedMap().values
    }
}

/** Real HTTP client for OpenAI-compatible /v1/chat/completions endpoints. */
class OpenAICompatibleProvider : InferenceProvider {
    private val gson = Gson()
    override suspend fun complete(messages: List<ChatMessage>, settings: LlmSettings): InferenceResult = withContext(Dispatchers.IO) {
        val base = settings.baseUrl.trim().trimEnd('/')
        val uri = Uri.parse(base)
        val host = uri.host
        require(uri.scheme == "https" || (uri.scheme == "http" && host == "10.0.2.2")) {
            "Use an HTTPS endpoint for online inference (HTTP is allowed only for the Android emulator host)."
        }
        require(!host.isNullOrBlank()) {
            "Enter your InstaBox gateway URL in Settings (for example, https://your-gateway.example/v1)."
        }
        require(settings.model.isNotBlank() && settings.model != "your-model-id") { "Enter the exact model path/name exposed by your InstaBox gateway." }
        val boundedMessages = UltronTokenBudget.fit(messages, settings)
        val estimatedInputTokens = UltronTokenBudget.estimate(boundedMessages)
        val maxOutput = settings.maxOutputTokens.coerceIn(64, 1024)
        val requestMessages = com.google.gson.JsonArray()
        boundedMessages.forEach { message ->
            val item = JsonObject().apply {
                addProperty("role", message.role)
                val image = message.imageDataUrl
                if (!image.isNullOrBlank()) {
                    val content = com.google.gson.JsonArray()
                    content.add(JsonObject().apply { addProperty("type", "text"); addProperty("text", message.content) })
                    content.add(JsonObject().apply {
                        addProperty("type", "image_url")
                        add("image_url", JsonObject().apply { addProperty("url", image) })
                    })
                    add("content", content)
                } else addProperty("content", message.content)
            }
            requestMessages.add(item)
        }
        val body = JsonObject().apply {
            addProperty("model", settings.model)
            add("messages", requestMessages)
            addProperty("stream", false)
            addProperty("max_tokens", maxOutput)
        }
        val endpoint = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
        val payload = gson.toJson(body).toByteArray(Charsets.UTF_8)
        android.util.Log.i("ULTRONInference", "request host=${uri.host} model=${settings.model.take(120)} messages=${boundedMessages.size}/${messages.size} estimatedInputTokens=$estimatedInputTokens context=${settings.contextWindowTokens} maxTokens=$maxOutput payloadBytes=${payload.size}")
        var lastFailure: Exception? = null
        for (attempt in 0..2) {
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 90_000
                doInput = true
                doOutput = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
                if (settings.apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer ${settings.apiKey}")
            }
            try {
                conn.outputStream.use { it.write(payload) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code in 502..504 && attempt < 2) {
                    lastFailure = IllegalStateException("InstaBox gateway HTTP $code (model=${settings.model.take(100)}, estimatedInputTokens=$estimatedInputTokens, context=${settings.contextWindowTokens}, maxTokens=$maxOutput): ${raw.take(700)}")
                    delay(1_000L * (1L shl attempt))
                    continue
                }
                if (code !in 200..299) {
                    val detail = raw.take(900).ifBlank { conn.responseMessage ?: "No error body" }
                    val hint = if (code == 400 && detail.contains("context", true)) " Reduce the app context limit or increase the model server's n_ctx." else ""
                    throw IllegalStateException("InstaBox gateway HTTP $code (estimatedInputTokens=$estimatedInputTokens, context=${settings.contextWindowTokens}, maxTokens=$maxOutput): $detail$hint")
                }
                val json = gson.fromJson(raw, JsonObject::class.java)
                val answer = json.getAsJsonArray("choices")?.get(0)?.asJsonObject
                    ?.getAsJsonObject("message")?.get("content")?.asString
                if (answer.isNullOrBlank()) throw IllegalStateException("InstaBox returned no choices[0].message.content. Confirm the configured model supports OpenAI-compatible Chat Completions.")
                return@withContext InferenceResult(answer, "Online · InstaBox · ${uri.host} · ~${estimatedInputTokens} input tokens")
            } catch (e: Exception) {
                if (e is InterruptedException) Thread.currentThread().interrupt()
                lastFailure = e
                if (attempt == 2 || (e.message?.contains("HTTP 502") != true && e.message?.contains("HTTP 503") != true && e.message?.contains("HTTP 504") != true)) throw e
            } finally { conn.disconnect() }
        }
        throw IllegalStateException("InstaBox gateway remained unavailable after 3 attempts: ${lastFailure?.message ?: "unknown gateway error"}", lastFailure)
    }
}

class LocalInferenceProvider(private val context: Context) : InferenceProvider {
    override suspend fun complete(messages: List<ChatMessage>, settings: LlmSettings): InferenceResult = withContext(Dispatchers.IO) {
        require(messages.none { !it.imageDataUrl.isNullOrBlank() }) { "The selected local GGUF model path does not currently provide image input. Select a configured vision-capable online profile for image analysis." }
        val actualContext = NativeLlamaRuntime.recommendedContextTokens(context.applicationContext)
        val localSettings = settings.copy(
            contextWindowTokens = actualContext,
            maxOutputTokens = settings.maxOutputTokens.coerceIn(64, 512)
        )
        // Retain the system prompt and the latest user turn. Do not drop the system
        // instructions by taking the last N messages before formatting the chat template.
        val bounded = UltronTokenBudget.fit(messages, localSettings)
        val answer = NativeLlamaRuntime.generate(
            context.applicationContext,
            bounded,
            localSettings.maxOutputTokens
        )
        InferenceResult(answer.trim(), "Local · llama.cpp GGUF · native chat template · context $actualContext")
    }
}

class InferenceRepository(context: Context) {
    private val appContext = context.applicationContext
    private val online = OpenAICompatibleProvider()
    private val local = LocalInferenceProvider(appContext)

    suspend fun complete(messages: List<ChatMessage>, settings: LlmSettings): InferenceResult = when (settings.mode) {
        InferenceMode.ONLINE -> online.complete(messages, settings)
        InferenceMode.LOCAL -> local.complete(messages, settings)
        InferenceMode.HYBRID -> completeHybrid(messages, settings)
    }

    /** Online provider failover, followed by an optional local text-model fallback. */
    suspend fun completeHybrid(
        messages: List<ChatMessage>,
        settings: LlmSettings,
        primaryProfile: AiEndpointProfile? = null,
        fallbackProfiles: List<AiEndpointProfile> = emptyList()
    ): InferenceResult {
        val failures = mutableListOf<String>()
        val targetRole = primaryProfile?.let { UltronAiRoleRouting.normalize(it.role) } ?: "general"
        val attemptedIds = mutableSetOf<String>()
        if (primaryProfile != null) {
            attemptedIds += primaryProfile.id
            try {
                val result = completeProfile(messages, primaryProfile)
                return result.copy(provider = "Hybrid primary · ${result.provider}")
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { failures += "${primaryProfile.name}: ${e.message ?: e.javaClass.simpleName}" }
        } else {
            try {
                val result = online.complete(messages, settings.copy(mode = InferenceMode.ONLINE))
                return result.copy(provider = "Hybrid primary · ${result.provider}")
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { failures += "General endpoint: ${e.message ?: e.javaClass.simpleName}" }
        }

        val alternatives = fallbackProfiles.filter { profile ->
            profile.enabled && profile.id !in attemptedIds && profile.baseUrl.isNotBlank() && profile.model.isNotBlank() &&
                UltronAiRoleRouting.normalize(profile.role) == targetRole
        }.distinctBy { it.id }.take(4)
        for (profile in alternatives) {
            attemptedIds += profile.id
            try {
                val result = completeProfile(messages, profile)
                return result.copy(provider = "Hybrid failover · ${result.provider}")
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { failures += "${profile.name}: ${e.message ?: e.javaClass.simpleName}" }
        }

        if (messages.any { !it.imageDataUrl.isNullOrBlank() }) {
            throw IllegalStateException(
                "All matching online providers failed (${failures.joinToString("; ")}). The configured local GGUF path is text-only and cannot analyze this image.",
                null
            )
        }
        if (!NativeLlamaRuntime.isAvailable() || NativeLlamaRuntime.activeModelPath(appContext) == null) {
            throw IllegalStateException(
                "All matching online providers failed (${failures.joinToString("; ")}). Hybrid mode also needs a loaded local GGUF model for offline fallback.",
                null
            )
        }
        return try {
            val roleInstruction = primaryProfile?.let { profile ->
                when (UltronAiRoleRouting.normalize(profile.role)) {
                    "coding" -> "You are ULTRON's ${profile.name}, a coding specialist. Prefer correct, secure, tested code and explain assumptions."
                    "vision" -> "You are ULTRON's ${profile.name}, a visual-analysis specialist. The local fallback is text-only; do not claim to see images."
                    else -> "You are ULTRON's ${profile.name}, a ${profile.role} specialist. Follow the user's current request precisely."
                }
            }
            val localMessages = if (roleInstruction == null) messages else listOf(ChatMessage("system", roleInstruction)) + messages
            val result = local.complete(localMessages, settings.copy(mode = InferenceMode.LOCAL))
            result.copy(provider = "Hybrid local fallback · online providers unavailable (${failures.joinToString("; ").take(220)})")
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) {
            throw IllegalStateException(
                "Hybrid mode exhausted online providers (${failures.joinToString("; ")}) and local fallback failed: ${e.message ?: e.javaClass.simpleName}", e
            )
        }
    }

    suspend fun completeProfile(messages: List<ChatMessage>, profile: AiEndpointProfile): InferenceResult {
        val roleInstruction = when (UltronAiRoleRouting.normalize(profile.role)) {
            "coding" -> "You are ${profile.name}, ULTRON's senior software engineering specialist. Prioritize correct, secure, tested code and explain assumptions."
            "vision" -> "You are ${profile.name}, ULTRON's visual analysis specialist. Analyze visual information only when it is actually included in the request; never pretend an image was received."
            else -> "You are ${profile.name}, a specialist AI working as part of ULTRON."
        }
        return online.complete(listOf(ChatMessage("system", roleInstruction)) + messages, profile.asSettings())
    }

    /** Parallel first-pass answers, peer review, then a final synthesis from the General AI (or first healthy AI). */
    suspend fun completeAllInOne(messages: List<ChatMessage>, profiles: List<AiEndpointProfile>): InferenceResult = coroutineScope {
        val active = profiles.filter { it.enabled && it.baseUrl.isNotBlank() && it.model.isNotBlank() }
        require(active.size >= 2) { "All-in-One needs at least two enabled online AI profiles with URL and model configured." }
        val firstPass: List<Pair<AiEndpointProfile, Result<String>>> = active.map { profile ->
            async<Pair<AiEndpointProfile, Result<String>>> {
                profile to runCatching { completeProfile(messages, profile).text }
            }
        }.awaitAll()
        val successful: List<Pair<AiEndpointProfile, Result<String>>> = firstPass.filter { it.second.isSuccess }
        require(successful.size >= 2) {
            "All-in-One could not reach at least two AI providers. " + firstPass.joinToString("; ") { (p, r) -> "${p.name}: ${r.exceptionOrNull()?.message ?: "OK"}" }
        }
        val candidateText = successful.joinToString("\n\n") { (profile, result) -> "[${profile.name} / ${profile.role}]\n${result.getOrThrow().take(5000)}" }
        val reviewMessages = messages + ChatMessage("user", "Independently critique and cross-check these candidate answers against the original request. Identify factual disagreements, missing requirements, and errors. Do not simply agree.\n\n$candidateText")
        val reviews: List<Pair<AiEndpointProfile, Result<String>>> = successful.map { (profile, _) ->
            async<Pair<AiEndpointProfile, Result<String>>> {
                profile to runCatching { completeProfile(reviewMessages, profile).text }
            }
        }.awaitAll()
        val reviewText = reviews.joinToString("\n\n") { (profile, result) -> "[Review by ${profile.name}]\n${result.getOrElse { "Review failed: ${it.message}" }.take(3500)}" }
        val synthesizer: AiEndpointProfile = successful.firstOrNull { UltronAiRoleRouting.normalize(it.first.role) == "general" }?.first ?: successful.first().first
        val finalMessages = messages + ChatMessage("user", "You are the final ULTRON synthesis engine. Resolve disagreements, correct errors, and produce one best answer. Do not mention unsupported consensus.\n\nCANDIDATE ANSWERS:\n$candidateText\n\nPEER REVIEWS:\n$reviewText\n\nReturn only the best final answer to the original user request.")
        val final = completeProfile(finalMessages, synthesizer)
        InferenceResult(final.text, "All-in-One · ${successful.size} AIs debated & cross-checked · final: ${synthesizer.name}")
    }
}
