package com.ultron.assistant

import android.content.Context
import androidx.room.withTransaction
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Deletes archived transcripts exactly after their 72-hour retention; active chats are never age-pruned. */
class ChatCleanupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val database = UltronDatabase.get(applicationContext)
        val now = System.currentTimeMillis()
        val expired = database.chatDao().expiredArchiveIds(now)
        for (conversationId in expired) {
            database.withTransaction {
                database.chatDao().deleteConversation(conversationId)
                database.chatDao().deleteArchive(conversationId)
            }
        }
        // Rows from the pre-session database migration had no archive expiry row. Keep at most
        // the previous 72 hours of this legacy history, then remove it.
        database.chatDao().deleteExpiredLegacy(now - UltronConversationMemory.RETENTION_MS)
        Result.success()
    } catch (_: Exception) { Result.retry() }
}
