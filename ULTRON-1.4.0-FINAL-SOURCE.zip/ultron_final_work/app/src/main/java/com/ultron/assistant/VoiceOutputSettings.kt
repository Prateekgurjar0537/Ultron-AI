package com.ultron.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/** User-selected spoken reply language and preferred voice presentation. */
data class VoiceOutputPreference(val language: String = "en-IN", val gender: String = "female")

class VoiceOutputStore(context: Context) {
    private val prefs = context.getSharedPreferences("ultron_voice_output", Context.MODE_PRIVATE)

    fun load(): VoiceOutputPreference = VoiceOutputPreference(
        language = prefs.getString("language", "en-IN") ?: "en-IN",
        gender = prefs.getString("gender", "female") ?: "female"
    )

    fun save(value: VoiceOutputPreference) {
        prefs.edit().putString("language", value.language).putString("gender", value.gender).apply()
    }

    /** Applies the best installed engine voice matching the selected locale and gender hint. */
    fun apply(engine: TextToSpeech, value: VoiceOutputPreference): String {
        val locale = Locale.forLanguageTag(value.language)
        val languageResult = engine.setLanguage(locale)
        if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            return "${locale.displayName} voice data is unavailable. Install it in Android Text-to-Speech settings."
        }
        val candidates = engine.voices.orEmpty().filter { it.locale.language == locale.language }
        if (candidates.isEmpty()) return "${locale.displayName} voice is not installed. Android will use its configured default voice."
        val genderMatches = candidates.filter { voice ->
            val name = voice.name.lowercase(Locale.ROOT)
            val features = voice.features.orEmpty().joinToString(" ").lowercase(Locale.ROOT)
            val labelledFemale = name.contains("female") || features.contains("female")
            val labelledMale = (name.contains("male") || features.contains("male")) && !labelledFemale
            if (value.gender == "male") labelledMale else labelledFemale
        }
        val selected = genderMatches.maxByOrNull { it.quality } ?: candidates.maxByOrNull { it.quality }
        if (selected != null) engine.voice = selected
        return if (genderMatches.isNotEmpty()) {
            "${locale.displayName} · ${value.gender} voice selected (${selected?.name ?: "system voice"})."
        } else {
            "${locale.displayName} is available, but this speech engine does not label a ${value.gender} voice. Using its best installed voice; install another TTS voice for an exact match."
        }
    }
}
