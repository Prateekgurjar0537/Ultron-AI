# ULTRON 1.1.0 — Unified Multi-Agent Intelligence

## Central architecture

The previous General-model planner is retained as the central decision-maker and now receives a compact dispatch plan from `UltronMultiAgentCoordinator`. The coordinator selects logical specialists for each request and describes their responsibilities and collaboration phases. It does not create a wasteful swarm of independent model calls.

## Model roles retained

- General: coordinator, planning, target resolution, reasoning, navigation, recovery and verification.
- Vision: screenshot interpretation only when a Vision profile is configured, screen capture is active, a fresh frame exists and cloud screen sharing is enabled.
- Coding: code generation and development conversations.

## Specialist registry

28 logical roles are available: Intent, Planner, Coordinator, Context, Memory, Reasoning, Vision, OCR, Screen, Target, Navigation, UI Learning, Action, Verifier, Recovery, Safety, Communication, Notification, Browser, Productivity, Device, Files, Network, Coder, Debugger, Architect, Tester and Skill Developer.

Roles are selected on demand. The same configured model can serve several roles using different instructions. This is not 28 independent LLMs.

## Execution safety

Specialists cannot call Android APIs or dispatch taps. They return analysis to the central planner. `UltronAgentExecutor` remains the sole action authority and retains action allow-listing, permission checks, screen-generation refresh, confirmation policy, bounded recovery and execution reporting.

## Performance strategy

- Small deterministic device commands keep the existing local fast path.
- Focused tasks activate a small specialist set.
- Complex tasks activate more roles, with independent observations grouped before planning.
- One General-model plan is preferred over multiple redundant LLM calls.
- Vision is called only when a fresh authorized frame is available.
- Specialist output is compact and shares one task state.

## Known limitations

- Agent roles are logical orchestration roles, not separately hosted agents.
- The coordinator currently contributes selection and structured role directives to the central planner; full asynchronous delegation to separate agent runtimes is not implemented.
- App UI access, OCR, screen capture, and device actions remain subject to Android version, app restrictions, permissions and model quality.
- No Android build or physical-device test is claimed unless the corresponding build/test workflow has been run.
