# ULTRON 1.0.0 — Multimodal Adaptive Agent

## Central LLM-driven execution
- Multi-stage requests that continue beyond a simple open-and-search flow are routed to the LLM planner instead of being truncated by deterministic command parsers.
- The planner is always routed to the General role (the main General endpoint or an enabled profile explicitly marked `general`). Selecting Coding or Vision for chat cannot silently change the phone-action planner.
- The executor compares fresh semantic UI state after meaningful actions, detects same-app and cross-app changes, and replans up to eight times.
- If a screen changes and no safe continuation plan is returned, execution stops rather than reusing stale coordinates or controls.

## Vision-to-General pipeline
- Added user-authorized MediaProjection screen observation for Android 8.0+ (including Android 8.1 / API 27).
- Captures are resized and held briefly in memory as JPEG frames; they are not saved in chat history or shared storage. An ongoing foreground notification provides an explicit Stop control.
- Live screen upload is a separate opt-in, off by default. When enabled and a Vision-role model is configured, a fresh frame is sent only to that Vision endpoint.
- The Vision model returns a compact, untrusted visual observation. The General planner receives that text alongside the semantic Accessibility tree and determines the next action. The Coding profile remains separate and is automatically selected for coding-focused chat requests when configured.
- Local OCR can use the MediaProjection frame on Android 8.0+; Android 11+ Accessibility screenshot remains a fallback.
- Camera-image analysis also recognizes Vision role aliases (`vision`, `visual`, `image`).

## Safety and performance
- Screen capture requires the Android system consent dialog each capture session. Secure/DRM windows may be black or unavailable.
- Screen frames are sent to a remote Vision endpoint only after both the Android screen-capture permission and ULTRON's separate cloud-sharing opt-in are enabled.
- Vision output is treated as evidence, not instructions; identity is never inferred from an avatar alone.
- Reduced planner and Vision response budgets and shorter HTTP timeouts to reduce unnecessary waiting.

## Retained foundations
- Existing AI modes, encrypted endpoint credentials, local GGUF runtime, chat/memory, voice/wake-word, accessibility controls, notifications, plugin, file/routine, device-control and UI assets remain in the project.

## Verification status
- Added unit tests for role routing, screen-vision consent gates and extended-compound routing.
- Source archive integrity and static source checks are performed for this archive. Android Gradle tests, APK compilation and physical-device acceptance must still run through the included GitHub Actions workflow or Android Studio. This delivery is not represented as device-tested.

## 1.1.0 — Unified Multi-Agent Intelligence
- Added a central multi-agent coordinator with 28 on-demand specialist roles.
- Preserved General, Vision and Coding model profile roles.
- Added shared task-state metadata and phased specialist collaboration directives.
- Routed broader natural-language device requests into the central planner.
- Kept a single validated Android executor; specialists cannot independently tap or dispatch actions.
- Added coordinator smoke/unit test coverage and implementation notes.
