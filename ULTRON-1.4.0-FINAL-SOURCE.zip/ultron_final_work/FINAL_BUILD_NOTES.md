# ULTRON 0.9.1 — Final source handoff

- Version name: `0.9.1`
- Version code: `16`
- Base: the uploaded complete 0.8.0 source tree
- Upgrade source: changed/new implementation files from the uploaded 0.9.0 tree
- Source files: `79`
- GitHub Actions: `.github/workflows/android.yml`
- Build guide: `BUILDING_0.9.1.md`
- Source comparison and validation report: `FINAL_DELIVERY_AUDIT.md`

This is one consolidated Android project. It is not an archive of two other source ZIPs. All source paths from 0.8.0 were preserved; the 0.9.0 changes and additions were applied to the 0.8.0 project.

The GitHub workflow is configured to run the unit-test task and produce an installable debug APK artifact. This authoring environment does not have Gradle, Android SDK, NDK or an emulator, so it has not produced or verified the APK. A successful GitHub Actions run and physical-device tests are still required.
