# ULTRON 0.4.9

- Fix All-in-One multi-provider Kotlin type inference by explicitly typing parallel AI result and review collections as `AiEndpointProfile` pairs.
- Replace the static placeholder voice visualizer with an animated ULTRON core GIF based on the included metallic red-eyed ULTRON artwork.
- Add a lightweight Android `Movie`-based GIF view and integrate it into the Voice Command screen with crimson, orange and purple HUD rings.
- Bump Android versionCode/versionName to 8 / 0.4.9.

Build status: source-level fix applied; Android Gradle build must be verified by GitHub Actions.
