# Building ULTRON 1.0.0

Requirements: JDK 17, Gradle 8.9, Android SDK platform/build-tools 35, NDK 27.2.12479018 and CMake 3.22.1.

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

The CI workflow is `.github/workflows/android.yml`. It runs JVM unit tests, builds the debug APK, and uploads test reports plus `ULTRON-1.0.0-debug-apk`.

## Configure General / Vision / Coding models
1. In ULTRON Settings, configure the main InstaBox URL, model ID and token as the General AI endpoint, or add a profile with role `general`.
2. Add a profile with role `vision`. Its OpenAI-compatible `/chat/completions` endpoint must accept image input using `image_url` content.
3. Add a profile with role `coding` for coding conversations. Coding-focused chat prompts are automatically routed to it when configured. The phone task planner uses General AI in Online/Hybrid mode; Local mode intentionally uses the local text model.
4. In Settings, enable `Share live screen frames with Vision AI` only when you consent to sending current screens to that endpoint.
5. Tap `START SCREEN AWARENESS` and approve Android's MediaProjection prompt. An ongoing notification appears; use its Stop action or ULTRON Settings to end capture.
6. Enable ULTRON Accessibility in Android Settings. The app needs it to inspect and interact with the semantic UI tree.

## Android 8.1 / API 27 notes
- MediaProjection-based capture allows local OCR and optional online Vision analysis on API 27 after the user grants the OS capture prompt.
- Android can block secure/DRM windows; some apps may intentionally hide UI or accessibility content. These cases cannot be bypassed.
- ColorOS/Oppo background limits, battery optimization and accessibility-service policy can interrupt long-running services.
- The screen frame is cached in memory only and discarded when capture stops. The app never writes captured frames to the document database.
- With cloud sharing enabled, the JPEG frame goes to the Vision profile; its visual description plus the semantic Accessibility snapshot go to the General planner. The raw JPEG is not sent to General or Coding.
- Online Vision runs once for each planning pass and adds network delay/cost. Disable cloud sharing to keep live-screen text/image information out of cloud planning requests.

## Acceptance tests on device
1. Start screen awareness, switch among Instagram, Chrome, Settings and an unfamiliar app, and confirm the screen frame refreshes after page transitions.
2. Test `Open Instagram, find Rahul, open his profile, check our latest conversation, and prepare a reply ...` with cloud Vision enabled and a correct Vision profile. Test duplicate Rahul results; ULTRON should ask instead of guessing.
3. Test with sharing disabled; screen text and images should not be included in cloud planner requests.
4. Test secure-window handling, stop notification, rotation, screen lock, wake word, alarm, real volume readback and confirmation gates.
5. Verify that a failed replan stops instead of executing stale coordinates.

No APK/device test is claimed until the workflow and the above acceptance tests complete successfully.
