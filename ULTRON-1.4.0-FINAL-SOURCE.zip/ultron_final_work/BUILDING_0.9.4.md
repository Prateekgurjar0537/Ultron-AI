# Building ULTRON 0.9.4

The GitHub Actions workflow `.github/workflows/android.yml` runs JVM unit tests and assembles the debug APK with JDK 17, Gradle 8.9, Android SDK 35, NDK 27.2.12479018 and CMake 3.22.1.

To build locally, install the same toolchain and run:

```bash
gradle --no-daemon --stacktrace --max-workers=2 :app:testDebugUnitTest
 gradle --no-daemon --stacktrace --max-workers=2 :app:assembleDebug
```

The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

A successful source archive check is not a substitute for the Android build. A successful CI build is not a substitute for installing the APK and testing wake-word stability, app navigation, confirmations, volume and screen actions on the OPPO CPH1803 / Android 8.1.
