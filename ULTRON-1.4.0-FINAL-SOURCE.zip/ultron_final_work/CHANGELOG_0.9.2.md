# ULTRON 0.9.2 — Visual asset refresh

## What changed
- Replaced the dashboard hero image with the stronger red-eyed armored ULTRON artwork from the 0.8.0 source asset set. It is resampled 2× (1800×1280) for sharper presentation on high-density screens; composition, colors and existing Compose crop behavior are retained.
- Replaced the voice animation with the dedicated microphone/waveform animation already used by 0.9.1, upscaled 2× to 720×720 while retaining its 32-frame loop and frame timing.
- Kept the Android resource names `ultron_hero` and `ultron_voice_core` unchanged, so existing Kotlin resource references and the startup/voice animation call sites remain intact.
- Updated app version to 0.9.2 (versionCode 17) and CI artifact labels.

## Explicit scope
This is an asset/version refresh only. No Kotlin command execution, accessibility, wake-word, AI, networking, storage, or permission logic was changed. The three supplied 1536×1024 promotional reference images were used to guide the red/black villain aesthetic; their multi-panel text layouts were not placed into the app as dashboard backgrounds.

## Verification boundary
Image dimensions, GIF frame count/loop timing, resource paths, archive integrity and source references were checked locally. The Android Gradle build and on-device rendering were not run in this workspace; use the included GitHub Actions workflow to compile and test the APK. Upscaling increases pixel dimensions but does not create new source detail.
