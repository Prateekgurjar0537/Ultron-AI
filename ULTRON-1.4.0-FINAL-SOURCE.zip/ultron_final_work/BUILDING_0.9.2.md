# Build ULTRON 0.9.2

This source package is built by the included GitHub Actions workflow.

1. Create a GitHub repository and upload the **contents** of this folder (the `.github` folder must be at repository root).
2. Push to `main`/`master`, open a pull request, or run **Actions → ULTRON Android CI → Run workflow**.
3. Wait for the `Unit tests and debug APK` job to finish.
4. Download the `ULTRON-0.9.2-debug-apk` artifact. It contains `app-debug.apk` and its SHA-256 checksum.

The workflow provisions JDK 17, Android SDK 35, NDK 27.2.12479018, CMake 3.22.1 and Gradle 8.9. It runs `:app:testDebugUnitTest` followed by `:app:assembleDebug`.

The APK is a debug build, not a Play Store release-signed APK. Install and test on the intended Android device before relying on background wake-word or Accessibility behavior. Android/ColorOS battery, microphone, background-start and Accessibility restrictions still apply.

No claim is made that this package has already passed a full Gradle build: that requires the GitHub Actions run. The 0.9.2 change is limited to artwork, animation assets, version metadata and CI artifact labels; app feature logic is unchanged from 0.9.1.
