# ULTRON 0.5.2 — User integrations and OAuth

## Added
- Plugin Armory now supports user-created HTTPS website shortcuts and configurable REST API integrations.
- REST methods: GET, POST, PUT, PATCH and DELETE.
- Authentication options: none, Bearer token, API key header, API key query parameter and HTTP Basic.
- Configurable JSON request-body templates using `{query}` / `{input}` placeholders.
- API credentials, Basic password and OAuth client secret are encrypted at rest using the existing Android Keystore AES-GCM vault.
- Chat command `run plugin <name> with <request>` invokes a saved REST integration and returns its HTTP status/body.
- Generic OAuth 2.0 Authorization Code flow with PKCE (S256), state validation, custom `ultron://oauth/callback` deep link and token exchange.
- OAuth access and refresh tokens are stored encrypted; the access token is used as a Bearer token for the plugin endpoint.
- Android manifest now declares the OAuth callback deep link.
- Android minSdk remains 26 (Android 8.0); targetSdk 35. Android 8–16 compatibility is intended but requires device testing.

## Important limitations
- OAuth providers differ. Some require a registered HTTPS redirect, provider-specific authorization parameters, client authentication styles, tenant IDs, consent configuration or a backend. Those providers may need additional per-provider configuration or code.
- Refresh-token renewal is not yet automatic; expired access tokens must be re-authorized.
- A generic REST plugin can call configured endpoints, but it does not automatically discover arbitrary APIs or infer their schemas. Configure the correct endpoint, method, headers/auth and JSON body.
- Existing accessibility commands remain explicit and limited. This release does not claim universal multi-app autonomous control, silent WhatsApp sending, or fully hands-free AI task execution.
- Camera currently opens Android's camera capture flow; a complete live camera/vision model pipeline is not included.
- Wake-word service remains dependent on Android speech-recognition provider and OEM background/battery policy. Android 8–16 real-device testing is required.
- Hindi/English TTS uses installed Android engine voices; voice assets are not bundled in this archive.

## Validation
- Source archive and XML/manifest syntax checked.
- Gradle/Android SDK build and device tests were not available in the build workspace; this release is not build-verified.
