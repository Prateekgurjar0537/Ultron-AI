# ULTRON 1.3.0 — Scheduled Routines + Local Knowledge Retrieval

## Implemented in this source update

- Connected the routine library to WorkManager with one-shot and repeating schedules.
- Added routine run-now and pause/cancel controls in the Advanced Intelligence screen.
- Routed scheduled routines through the existing serialized background planner/executor with stable per-occurrence IDs and bounded completion markers to reduce duplicate dispatch on WorkManager retries. Sensitive actions still create the normal YES/NO approval flow; routines do not silently approve sending, calls, purchases, deletion, publishing or other commitments.
- Added a 15-minute minimum for repeating routines because that is WorkManager's periodic-work floor. One-time and periodic schedules are best-effort and may be delayed by Android Doze, battery saver, OEM background restrictions or force-stop.
- Routine names and command text are now encrypted at rest with the existing Android Keystore vault; legacy plaintext rows remain readable and are encrypted on next save.
- Replaced simple document keyword counting with local BM25-style lexical ranking, title boosts, phrase matching and paragraph-level excerpt selection across up to 40 imported documents.
- Added focused retrieval tests for ranking, empty queries and excerpt bounds.
- Version updated to 1.3.0 / versionCode 27.

## Important boundaries

- WorkManager is not an exact-time alarm clock and cannot guarantee a run while the app is force-stopped. Doze and OEM power management can defer work.
- Scheduled work hands the command to the existing AI planner. Actual automation still requires the necessary Accessibility permission, a configured model or supported local route, and accessible app UI. If a routine requires a sensitive commitment, ULTRON asks for approval rather than proceeding automatically.
- Document retrieval is lexical BM25-style search, not embedding-based vector search. Imported text remains user-selected and is stored encrypted by the existing database path; excerpts may be included in configured model requests as the existing chat pipeline permits.
- This update does not turn the app builder into an on-device compiler, add an unrestricted local multimodal model, or provide remote MCP/A2A transports. Those remain future integrations requiring additional runtime/model/server infrastructure.

## Verification

- Standalone Kotlin smoke test for document retrieval passed: the relevant Android Accessibility document ranked above unrelated gardening text; stopword-only query returned no result.
- Added JUnit tests for retrieval ranking, empty queries and excerpt bounds; these tests are included in the project but the Gradle test task was not run here.
- Source-level review completed for WorkManager schedule wiring and routine encryption migration.
- Full Android Gradle/Compose/KSP/NDK build and device tests were not run because this workspace has no Gradle executable or Android SDK installation.
