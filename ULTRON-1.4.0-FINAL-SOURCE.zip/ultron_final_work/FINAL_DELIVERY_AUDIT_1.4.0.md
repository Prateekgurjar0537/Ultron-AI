# ULTRON 1.4.0 source delivery audit (superseded by 1.4.1)

## Source lineage

This package is the edited 1.3.0 work tree from the current conversation. That tree retained the requested 1.1.0 lineage and the 1.2.0/1.3.0 upgrades. Existing Compose UI, original project media/GIF assets, native llama.cpp bridge, model profile/settings foundations, browser, memory, skills/plugins, routines and other project files remain in the archive.

## Changes in this delivery

- Stable screen fingerprints ignore volatile Accessibility event-generation and IME metadata.
- Accessibility click targeting refuses equally ranked duplicate visible labels rather than choosing an arbitrary control.
- On-device Latin/Devanagari OCR can locate a single unique `click_text` target when Accessibility does not expose a clickable node; it checks the current screen again before tapping. Android 8.1 requires an active, user-approved Screen Awareness capture session for this fallback.
- `wait_for_text` has bounded Accessibility polling and a single bounded OCR fallback.
- Screen text and world-state memory redact common sensitive patterns, including bare six-digit codes; password, OTP, recovery-code and payment-card fields are not auto-filled.
- Sensitive commitment label detection catches Send/Delete/Pay/Buy/Order/Transfer/Publish/Share and account/security-change verbs; ordinary navigation and search labels do not trigger this confirmation rule.
- Wake service uses provider readiness/audio callback diagnostics, recognizer generation IDs, stale callback suppression, startup/session watchdogs and bounded recovery backoff.
- Existing central coordinator, 28 logical specialist roles, General/Vision/Coding model profiles, world model, feedback scoring, persistent task state and other existing 1.3 modules are retained.

## Verification

- `kotlinc` compiled the pure Kotlin screen fingerprint, world-model, action-simulation and wake-phrase core sources.
- Offline JUnit-compatible harness: 22 selected pure Kotlin test methods passed, 0 failed.
- Standalone core smoke checks passed for wake phrase token matching, rejection of substring false positives, screen fingerprint stability and real visible transition detection.
- XML parsing passed for all 5 project XML files.
- Kotlin source scan found 92 top-level class declarations and no duplicate fully qualified class names.
- ZIP integrity is checked after packaging; archive SHA-256 is supplied alongside the ZIP.

## Not verified / not promised

- No full Gradle/Android/Compose/KSP/NDK build or APK assembly was performed because Gradle and Android SDK are not installed/configured in this environment.
- No emulator or OPPO CPH1803 Android 8.1 physical-device tests were performed. ColorOS background microphone survival, SpeechRecognizer accuracy, Accessibility behavior in specific apps and gesture calibration must be tested on the device.
- SpeechRecognizer is not a dedicated acoustic hotword model. Flawless wake-word detection or universal control of every app/page cannot be guaranteed. Secure/DRM/custom-rendered surfaces and protected system UI may remain inaccessible.
- The 28 agents are logical specialist roles sharing three configured model profiles, not 28 independent LLM instances. MCP/A2A external transports, full vector RAG, online reinforcement learning, a full APK app-builder compiler, signed plugin marketplace and complete notification/file automation are not fully implemented.

See `IMPLEMENTATION_STATUS.md`, `CHANGELOG_1.4.0.md` and `BUILDING_1.4.0.md` for details.


Superseded for build configuration by `BUILD_FIX_1.4.1.md` and `FINAL_DELIVERY_AUDIT_1.4.1.md`.
