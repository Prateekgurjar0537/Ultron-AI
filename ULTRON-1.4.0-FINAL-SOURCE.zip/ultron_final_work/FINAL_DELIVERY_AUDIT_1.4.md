# ULTRON 1.4 — Source delivery and verification audit

## Current source package

This package is based on the supplied ULTRON 1.4 source archive and preserves the existing app tree. The app `versionName` is `1.4` and `versionCode` is `29`. It includes the earlier sensitive-action classification fix: read-only purchase/order/payment history labels do not require confirmation, while actual send/pay/buy/order/delete/publish commit actions remain protected. The executor and preflight simulator share the same classifier.

## Latest GitHub build check (run #36)

- Repository: `gurjarprateek0537/Ultron-AI`
- Run: https://github.com/gurjarprateek0537/Ultron-AI/actions/runs/45817233182
- Source extraction: passed.
- Unit test task: failed before tests started because Gradle could not resolve transitive artifacts; Maven Central returned HTTP 429 Too Many Requests.
- APK build: skipped because the test step did not complete.
- The repository's uploaded ZIP size matches this local source archive, and its Git blob SHA matches the repository's current `ULTRON-1.4.0-FINAL-SOURCE.zip` object.

This run does not show a failing Kotlin assertion. It also does not prove the test suite passes, because the tests did not start.

## Changes in this delivery

1. Retains the sensitive-action approval fix described above.
2. Adds the Google-hosted Maven Central mirror ahead of Maven Central for plugin and app dependency resolution, with Maven Central retained as fallback.
3. Adds `BUILD_RESILIENCE_1.4.md` explaining the observed 429 failure and verification limits.
4. Supplies a replacement root GitHub Actions workflow separately. It retries Gradle test and APK build commands up to three times with increasing delays.

## Checks performed in this environment

- Original archive ZIP integrity: passed; 155 entries.
- The submitted archive was byte-for-byte identified against the GitHub repository object using its Git blob SHA.
- Project source inventory: 39 app Kotlin source files, 14 unit-test source files, 78 `@Test` annotations, and 2 native C++/CMake files.
- Final ZIP integrity check passed (133 file entries; no corrupt members). All packaged Android XML files parsed successfully.
- Extracted the exact `UltronAgentSafetyPolicy` object and compiled it with `kotlinc`; a standalone smoke harness passed 11 sensitive labels, 15 ordinary/history labels, call/type handling, and GET-vs-POST plugin checks. This is targeted JVM validation, not the Android JUnit suite.
- Source configuration inspected: AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, compile/target SDK 35, minSdk 26, NDK 27.2.12479018, CMake 3.22.1, Room 2.6.1 via KAPT.

## Not verified

- The complete Gradle unit-test suite has not completed successfully in GitHub Actions.
- `:app:assembleDebug` has not completed; no APK is supplied.
- The Maven mirror and retry workflow have not yet been exercised by a successful CI run.
- No OPPO CPH1803 / Android 8.1 / ColorOS device test was performed.
- Wake-word reliability, all-app automation, notification workflows, volume readback, lock/power behaviour and OEM background survival remain runtime/device dependent.

## Feature completeness

The source contains substantial implementations and foundations, but some previously requested capabilities remain partial: SpeechRecognizer is not a dedicated acoustic wake-word engine; universal UI automation is constrained by Accessibility and protected screens; the 28 specialist roles share three model profiles rather than running as 28 separate LLMs; there is no production MCP/A2A peer mesh, isolated third-party plugin sandbox, complete notification digest, full duplicate-file cleanup system, or on-device APK build/sign/install pipeline. See `IMPLEMENTATION_STATUS.md` for the detailed feature-by-feature boundaries.

**Release status:** patched source archive with dependency-resolution resilience changes; not yet CI-build-verified and not device-certified.
