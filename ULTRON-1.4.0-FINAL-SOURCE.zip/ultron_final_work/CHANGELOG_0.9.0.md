# Changelog — 0.9.0

- Persisted explicit wake-word opt-in and boot/package-replacement restoration path.
- Added Android 14+ post-reboot resume notification to comply with microphone foreground-service restrictions.
- Added resilient SpeechRecognizer restarts, offline preference, partial-result wake detection and duplicate suppression.
- Added volume percentage/up/down/mute, active media play/pause/next/previous, brightness special access and flashlight controls.
- Added power menu, lock screen, quick settings, notification shade, recent-apps, screenshot and settings-panel actions within Android's supported APIs.
- Added semantic long-press, horizontal/vertical scrolling, drag and double-tap execution plus local screen OCR on Android 11+.
- Expanded deterministic command parsing, including Hindi/Hinglish controls and song search/open requests.
- Added startup voice animation and replaced dashboard/voice artwork with distinct styles.
- Added unit tests for device commands, reboot policy, safety/recovery and execution-status reporting.
- Added a recognizer-session watchdog, on-device recognizer fallback and recognizer recreation after synchronous start failures.
- Expanded punctuation-tolerant deterministic parsing for directional swipes and repeated gestures.
- Removed an unsupported torch-state getter and report flashlight/volume step actions as dispatched unless their final state can be read back.
