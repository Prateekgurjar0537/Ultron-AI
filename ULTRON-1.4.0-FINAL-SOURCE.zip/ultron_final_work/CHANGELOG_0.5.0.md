# ULTRON 0.5.0 — Memory Vault & Voice Reliability Pass

- Replaced the placeholder Memory screen with live on-device counts and listings for saved facts, notes and imported documents.
- Added refresh and saved-facts deletion controls; chat history remains separate.
- Rebuilt the Voice screen's ULTRON centerpiece as a 36-frame, high-resolution animated HUD GIF with layered crimson/orange/purple rings, moving scan beam and rotating ticks.
- Improved SpeechRecognizer recovery with recognizer recreation, exponential retry delay, clearer notification diagnostics and online recognizer fallback preference.
- Kept the existing InstaBox online profiles, All-in-One mode, local GGUF model manager, browser, plugin URL templates and accessibility helper.

## Important limitations

- Android SpeechRecognizer is not a privileged always-on hotword engine. Continuous wake-word detection depends on the installed speech provider, microphone access, foreground-service rules, battery management and OEM firmware. No APK can guarantee identical operation on every Android 8–16 device.
- This release does not yet implement unrestricted AI-planned multi-step automation, universal OAuth integrations, or guaranteed background execution of arbitrary commands. Existing accessibility actions remain limited to implemented actions and Android-exposed UI controls.
- Build and device testing are required. This archive has not been compiled or tested on physical Android devices in this environment.
