# ULTRON feature status — source archive

This status is intentionally explicit. A permission declaration, settings button, or roadmap entry is not counted as a completed feature unless the behavior has code behind it.

## Working source paths present

| Area | Status in this archive | Important caveat |
|---|---|---|
| Crimson/charcoal Compose chat | Implemented | UI is functional but does not yet include the full animated-avatar/floating-widget design. |
| Online LLM client | Implemented for OpenAI-compatible Chat Completions | Requires a real HTTPS endpoint/model/token; Oracle OCI IAM signing and other API schemas need a separate adapter. Not verified against the user's server yet. |
| API-token storage | Implemented with AES-GCM + Android Keystore | Should still use a server-side proxy for a public/distributed app. |
| Persistent chat/notes/memory/documents | Implemented using Room | Chat transcript rows older than three days are removed; approved facts, notes, and documents persist until deleted. |
| User-selected text/image/PDF import | Implemented | OCR runs on-device; PDFs are capped at 20 pages and imported text at 100,000 characters. |
| Latin + Devanagari OCR | Integrated via bundled ML Kit dependencies | Has not been compiled/tested on a physical device in this environment. |
| Basic lexical retrieval over approved memories/documents | Implemented | This is simple retrieval, not a vector database or advanced RAG pipeline. |
| Relative reminders | Implemented | Exact timing depends on Android alarm access; falls back to inexact alarms. |
| Common Android settings/app shortcuts | Implemented for listed routes | Some settings screens vary by manufacturer/version. Restricted toggles open system UI rather than silently changing protected settings. |
| Generic open-app-by-visible-name | Implemented using launcher intent queries | App label matching may be ambiguous when apps have similar names. |
| Call/SMS intents | Implemented | Opens dialer/message composer; user confirms call or send. No direct call/text is placed automatically. |
| Flashlight and media volume | Implemented with local Android APIs | Flashlight requires compatible hardware and permission. |
| Permission center | Implemented for runtime/special-access status and settings routes | Does not grant permissions automatically; Android prompts remain user-controlled. |
| Accessibility helper | Implemented for explicit read-screen, click-label and scroll commands | Must be explicitly enabled; cannot operate reliably in every app; always verify important actions. |
| Notification listener | Implemented for live notification count only | Does not store notification text or execute remote commands. |
| Visible on-device wake-word service | Implemented as opt-in prototype | Requires Android 12+ on-device recognizer, active microphone permission and endurance/false-trigger testing. “Ultron” detection raises a notification; it does not yet turn the following speech into a full hands-free conversation. |
| Biometric/device-credential app lock | Implemented | Locks the ULTRON UI on leaving foreground; does not replace Android's device lock screen. Older Android versions may require biometrics. |
| Three-day chat cleanup | Implemented with WorkManager and startup cleanup | Cleanup timing is subject to Android WorkManager scheduling. |
| Model RAM policy | Implemented and covered by a unit test | Chooses model profile only; it does not load or run the models. |
| GitHub Actions build workflow | Configured | Not yet verified by a successful CI run. |

## Not complete yet

- Automated model downloader and measured peak-memory management. Native llama.cpp/GGUF JNI bridge and import/load/generation code are now included, but native compilation, model-template behavior, and real-device memory fit are not yet verified; supported architecture depends on the upstream llama.cpp revision and selected GGUF.
- Live camera pipeline, object detection, image segmentation, broad local vision-language model, camera burst/video capture, and screen recording.
- Dedicated acoustic wake-word model, speaker verification/three voice profiles, and full hands-free voice-command loop.
- Generalized multi-app agent, robust 250+ Android actions, robust 20+ accessibility automation primitives with verification/undo, floating overlay, avatar/GIF animation, and 1,200 curated Easter eggs.
- Geofenced reminders, contact/call-log search, WhatsApp/Telegram-specific workflows, live weather/news/finance APIs, scam detection, and background proactive suggestions.
- Remote commands and remote device access. No covert camera/microphone capture, hidden upload, or secret remote surveillance is included.
- Full automated compile, emulator tests, physical-device permission-flow tests, API integration tests, and final APK signing/build validation.

## Validation performed for this archive

- Added a native JNI bridge to upstream `llama.cpp`, CMake FetchContent wiring, an arm64-v8a build target, GGUF magic validation, app-private model import, and local-provider routing. The bridge uses conservative 1024/1536/2048 context sizes based on reported physical RAM and does not automatically substitute a different model. This source has not yet passed an Android NDK compile in this environment.

- Parsed Android XML resource/manifest files.
- Parsed the GitHub Actions workflow as YAML.
- Added unit coverage for the RAM model-tier policy.
- Kotlin-only syntax scan was attempted, but full compilation is blocked here because this environment lacks Android SDK/Gradle dependencies and cannot download them. The source and CI workflow should be treated as **not build-verified** until a GitHub Actions run succeeds.
