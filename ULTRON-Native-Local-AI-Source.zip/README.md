# ULTRON — Android Assistant Source

**Design:** crimson red + charcoal/black, restrained orange and minimal purple. Kotlin + Jetpack Compose, min SDK 26, compile/target SDK 35, Java 17.

This is an implementation-focused personal-use Android project. It includes real features in the source, but it is **not yet the fully completed assistant**: see the “Known missing work” section before treating the APK as finished.

## Implemented in this source

- **Compose chat UI** with Royal-dark ULTRON colours, online/local provider setting, speech-recognition launcher, Android TextToSpeech, import action, and Permission Center.
- **Online inference adapter** for `POST {baseUrl}/chat/completions` using the OpenAI-compatible `model`, `messages`, and `stream: false` request format. HTTP errors are surfaced to the user; no fabricated answer is returned. Oracle endpoints that use OCI IAM signing or another route/schema still need a matching adapter.
- **API token at rest:** new saves are AES-GCM encrypted with a non-exportable Android Keystore key. A legacy plain token from an earlier build is migrated where the keystore operation succeeds. For public apps, a restricted backend proxy is still the recommended architecture.
- **Private app database (Room):** persistent chat records, user-approved memories, notes, and extracted-document text. Chat transcript records older than three days are pruned on app start and by a periodic WorkManager job; saved facts, notes, and documents persist until deleted by the user.
- **On-device document extraction:** file picker supports text/Markdown/JSON/XML, images and PDFs. ML Kit extracts Latin and Devanagari text; PDFs are rendered and OCRed locally up to 20 pages. Imported material is stored in the private app database, and lexical matching adds small relevant excerpts to subsequent LLM prompts. Unsupported formats produce an error.
- **Explicit command routing:** `remember that …`, `what do you remember?`, `forget all memory`, `note: …`, `show notes`, `show documents`, `remind me in 10 minutes to …`, time/date/battery queries, flashlight on/off (camera permission and hardware required), media volume up/down/mute, web search, common app/site shortcuts, Wi-Fi/Bluetooth/location/display/notification/accessibility/alarms settings pages, and notification-count query.
- **Opt-in accessibility helper:** after the user explicitly enables the Accessibility Service, commands `read screen`, `click <visible label>`, and `scroll up/down` attempt supported actions. This service does not record content in the background. Check the active app to verify every action.
- **Biometric/device-credential app lock:** optional app gate backed by AndroidX BiometricPrompt. Android 11+ accepts strong biometrics or device credential; older releases require an enrolled biometric. The app re-locks after it leaves the foreground. This is an app screen lock, not a replacement for Android's lock screen.
- **More device actions:** `call <number>` opens the system dialer without placing a call; `sms <number>: <message>` opens the system SMS composer without sending; `open <app name>` attempts to find and launch an installed launcher app by its visible name.
- **Opt-in wake-word service:** foreground notification and on-device-only speech recognition for “Ultron”, if the device's Android on-device recognizer is available. It keeps the microphone active while enabled; the notification has a Stop action. No cloud speech fallback is used. Wake-word detection prompts a notification to open ULTRON; it does not secretly open the app or capture camera images.
- **Permission center:** live status checks and links to Android permission/special access pages for camera, microphone, location, contacts, calls, notifications, accessibility, notification-listener access, legacy device admin, overlay, battery optimization, DND access, exact alarms, and app permissions.
- **Reminder receiver:** posts a reminder notification when permitted and schedules exact alarms only when Android grants exact-alarm access; otherwise it uses Android's inexact alarm API.
- **Model RAM policy:** shows the requested model profile based on device RAM: LFM2.5-1.2B Q4_K_M for the 4 GB class, Gemma 4 E2B for 6 GB, and Gemma 4 E4B for 8 GB+. The policy does **not** downgrade E4B to E2B automatically.
- **CI workflow:** GitHub Actions installs Gradle 8.9 and Android SDK platform 35, runs unit tests, attempts a debug APK build, and uploads the APK artifact only if that build succeeds.

## What is still not implemented (important)

- **Native local GGUF inference:** `LocalInferenceProvider` intentionally reports an error. The model RAM policy and model pages do not mean a model is downloaded or runnable. The upstream llama.cpp Android example exists, but its current module targets newer Android/SDK requirements; the correct version must be adapted and tested against the chosen GGUF models before local mode can be called working. Official starting point: https://github.com/ggml-org/llama.cpp/tree/master/examples/llama.android and https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
- The app does not automatically download GGUF model files or validate compatibility/peak memory yet.
- The current OCR runs on user-selected images/PDF pages. It is not a live camera vision detector, object detector, full-screen VLM, or image segmentation system.
- Wake-word support depends on device/Android on-device speech services and needs real-device endurance, battery, and false-trigger testing. It is not an acoustic dedicated wake-word model or speaker identification.
- Notification access only reports a count and does not read or save message contents. Remote messaging commands, camera/microphone/location capture from remote requests, speaker profiles, and hidden background upload are not implemented.
- No generalized automation agent, arbitrary 250+ command catalog, 1,200 Easter-egg database, custom animated avatar, draggable floating overlay widget, live camera object detector/VLM, background geofence reminders, scam detector, call-log reader, WhatsApp/Telegram-specific composer, live weather/news/stocks integrations, camera burst/recording, screen recording, speaker identification, or complete UI-agent verification pipeline is included yet.
- Device admin activation is a legacy Android interface and has no wipe/password policy configured. It does not grant root or unrestricted system control.

## Oracle-hosted online API setup

In ULTRON, open Settings and select Online LLM. Enter:

1. **Base URL**, for example `https://your-domain.example/v1` (do not append `/chat/completions`; the app appends it).
2. **Model ID** exactly as expected by your server.
3. **API token**, if required.

The app sends a JSON request to `${baseUrl}/chat/completions` with `model`, `messages`, and `stream: false`, and sends `Authorization: Bearer …` when a token is configured. Use HTTPS. Do not expose a privileged inference endpoint without authentication. This adapter will not work unchanged for OCI signed requests or an incompatible API schema.

## Native local model setup (new, needs CI/device verification)

1. In Settings choose Local LLM and open the profile page chosen by the RAM policy.
2. Download a `.gguf` asset that is explicitly compatible with the current upstream `llama.cpp` architecture support. A repository page alone is not enough: check its exact quantization, architecture, split-file instructions, license, and context/memory requirements.
3. Tap **Import GGUF model** and choose the file. ULTRON validates the `GGUF` magic header and copies the model into app-private storage. Ensure enough free storage exists for an additional copy.
4. Select Local LLM and send a prompt. The first request loads the model into native memory. If it fails, check the CI native build log, model architecture compatibility, and available RAM. ULTRON does not silently replace the chosen model.

The JNI bridge is under `app/src/main/cpp/` and uses CMake `FetchContent` to fetch `ggml-org/llama.cpp` during the GitHub Actions build. This requires GitHub Actions network access and may be affected by upstream API changes because the dependency is currently pinned to `master`. A successful Actions run and a physical-device inference test are still required before calling this production-ready. Model selection by RAM tier is a policy, not a guarantee that the model fits under a strict memory cap. Gemma-family community GGUF variants must be tested against the exact upstream runtime; compatibility is not assumed.

## Build from a phone using GitHub Actions

1. Create a GitHub repository and upload these project files to the repository root (keep `.github/workflows/android.yml`).
2. Open the repository's **Actions** tab. Run **Build ULTRON debug APK** using **Run workflow**, or push a commit to `main`.
3. Wait for the workflow to finish. Open the successful run and download the `ultron-debug-apk` artifact. GitHub gives you a ZIP containing `app-debug.apk`.
4. Install the APK on your own device and test each feature. Android may show the usual side-load warning; only install builds from your own repository that you trust.

This archive contains source files, not a compiled APK. The current environment could not build it locally because Gradle and Android SDK components were unavailable and outbound package downloads were blocked. Therefore the CI workflow is configured but not yet proven successful.

## Useful user commands

- `remember that I prefer short Hinglish answers`
- `what do you remember?`
- `forget all memory`
- `note: revise plant anatomy at 7 pm`
- `show notes`
- `remind me in 25 minutes to take a break`
- `show documents`
- `search web for NEET 2027 official syllabus`
- `open Wi-Fi settings`
- `open Bluetooth settings`
- `turn on flashlight`
- `volume down`
- `read screen`
- `click Continue`
- `scroll down`
- `how many notifications`

`set alarm` opens the Android Clock app; it does not create an alarm automatically. For notifications/reminders, grant notification permission. For precise timing, optionally enable Android's Alarms & reminders access.

## Privacy and Android behavior

The document import is user-selected. OCR and document storage happen on device. Relevant stored excerpts may be sent to your configured cloud AI when you use Online LLM; avoid importing sensitive documents if you don't want them transmitted in context. Chat history cleanup does not delete saved memories, notes, or documents. Accessibility can see text in other apps only after you enable it and is used here only after explicit commands. The wake-word service uses the device's on-device recognition service and shows an ongoing notification while microphone listening is active.
