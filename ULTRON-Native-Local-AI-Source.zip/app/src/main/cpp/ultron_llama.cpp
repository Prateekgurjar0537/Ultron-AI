#include <jni.h>
#include <android/log.h>
#include <llama.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "ULTRON_LLAMA", __VA_ARGS__)

struct Engine {
    llama_model* model = nullptr;
    llama_context* ctx = nullptr;
    llama_sampler* sampler = nullptr;
    std::mutex lock;
    ~Engine() {
        if (sampler) llama_sampler_free(sampler);
        if (ctx) llama_free(ctx);
        if (model) llama_model_free(model);
    }
};
static jlong ptr(Engine* e) { return reinterpret_cast<jlong>(e); }
static Engine* engine(jlong p) { return reinterpret_cast<Engine*>(p); }

extern "C" JNIEXPORT jlong JNICALL
Java_com_ultron_assistant_NativeLlamaRuntime_nativeLoad(JNIEnv* env, jobject, jstring jpath, jint contextSize, jint threads) {
    const char* pathChars = env->GetStringUTFChars(jpath, nullptr);
    std::string path(pathChars ? pathChars : "");
    if (pathChars) env->ReleaseStringUTFChars(jpath, pathChars);
    if (path.empty()) return 0;

    llama_backend_init();
    auto* e = new Engine();
    llama_model_params mp = llama_model_default_params();
    mp.load_mode = LLAMA_LOAD_MODE_MMAP;
    e->model = llama_model_load_from_file(path.c_str(), mp);
    if (!e->model) { delete e; LOGE("Could not load model: %s", path.c_str()); return 0; }
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(std::max(512, std::min(4096, (int)contextSize)));
    cp.n_batch = 256;
    cp.n_threads = std::max(1, std::min(8, (int)threads));
    cp.n_threads_batch = cp.n_threads;
    e->ctx = llama_init_from_model(e->model, cp);
    if (!e->ctx) { delete e; LOGE("Could not create context"); return 0; }
    e->sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(e->sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(e->sampler, llama_sampler_init_top_p(0.90f, 1));
    llama_sampler_chain_add(e->sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(e->sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    return ptr(e);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ultron_assistant_NativeLlamaRuntime_nativeGenerate(JNIEnv* env, jobject, jlong handle, jstring jprompt, jint maxTokens) {
    Engine* e = engine(handle);
    if (!e || !e->model || !e->ctx || !e->sampler) return env->NewStringUTF("Local runtime is not loaded.");
    const char* promptChars = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(promptChars ? promptChars : "");
    if (promptChars) env->ReleaseStringUTFChars(jprompt, promptChars);
    std::lock_guard<std::mutex> guard(e->lock);

    const llama_vocab* vocab = llama_model_get_vocab(e->model);
    std::vector<llama_token> tokens(std::max<size_t>(prompt.size() + 256, 512));
    int32_t count = llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), tokens.data(), (int32_t)tokens.size(), true, true);
    if (count < 0) {
        tokens.resize((size_t)(-count) + 8);
        count = llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), tokens.data(), (int32_t)tokens.size(), true, true);
    }
    if (count <= 0 || count > (int32_t)tokens.size()) return env->NewStringUTF("Could not tokenize prompt. Check that this GGUF is compatible with llama.cpp.");
    tokens.resize((size_t)count);
    llama_memory_clear(llama_get_memory(e->ctx), true);
    llama_sampler_reset(e->sampler);

    const int n_ctx = (int) llama_n_ctx(e->ctx);
    if ((int)tokens.size() > n_ctx - 16) {
        tokens.erase(tokens.begin(), tokens.end() - (n_ctx - 16));
    }
    int decoded = 0;
    const int chunkSize = std::max(1, std::min(256, (int) llama_n_batch(e->ctx)));
    for (int offset = 0; offset < (int)tokens.size(); offset += chunkSize) {
        const int amount = std::min(chunkSize, (int)tokens.size() - offset);
        llama_batch batch = llama_batch_init(amount, 0, 1);
        for (int i = 0; i < amount; ++i) {
            const int index = offset + i;
            batch.token[i] = tokens[index];
            batch.pos[i] = index;
            batch.n_seq_id[i] = 1;
            batch.seq_id[i][0] = 0;
            batch.logits[i] = (index == (int)tokens.size() - 1);
        }
        batch.n_tokens = amount;
        decoded = llama_decode(e->ctx, batch);
        llama_batch_free(batch);
        if (decoded != 0) break;
    }
    if (decoded != 0) return env->NewStringUTF("Local inference failed during prompt evaluation. Try a smaller context or compatible model.");

    std::string output;
    std::vector<char> piece(8192);
    int pos = (int)tokens.size();
    int limit = std::max(1, std::min(1024, (int)maxTokens));
    for (int n = 0; n < limit; ++n) {
        if (pos >= (int)llama_n_ctx(e->ctx)) break;
        llama_token token = llama_sampler_sample(e->sampler, e->ctx, -1);
        if (llama_vocab_is_eog(vocab, token)) break;
        int pieceLen = llama_token_to_piece(vocab, token, piece.data(), (int)piece.size(), 0, true);
        if (pieceLen > 0) output.append(piece.data(), (size_t)pieceLen);
        llama_batch next = llama_batch_init(1, 0, 1);
        next.token[0] = token;
        next.pos[0] = pos++;
        next.n_seq_id[0] = 1;
        next.seq_id[0][0] = 0;
        next.logits[0] = true;
        next.n_tokens = 1;
        int result = llama_decode(e->ctx, next);
        llama_batch_free(next);
        if (result != 0) break;
    }
    return env->NewStringUTF(output.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_ultron_assistant_NativeLlamaRuntime_nativeFree(JNIEnv*, jobject, jlong handle) {
    Engine* e = engine(handle);
    delete e;
}
