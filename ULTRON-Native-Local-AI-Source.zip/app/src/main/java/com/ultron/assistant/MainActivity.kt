package com.ultron.assistant

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Night = Color(0xFF090A0D)
private val Panel = Color(0xFF11141A)
private val Crimson = Color(0xFFFF343D)
private val Orange = Color(0xFFFF9A52)
private val Purple = Color(0xFF9D83D8)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var settingsStore: SettingsStore
    private lateinit var database: UltronDatabase
    private val appLockEnabled = mutableStateOf(false)
    private val appUnlocked = mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsStore = SettingsStore(this)
        database = UltronDatabase.get(this)
        appLockEnabled.value = AppLockStore.isEnabled(this)
        appUnlocked.value = !appLockEnabled.value
        tts = TextToSpeech(this, this)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "ultron-chat-cleanup",
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ChatCleanupWorker>(24, TimeUnit.HOURS).build()
        )
        lifecycleScope.launch { runCatching { database.chatDao().deleteOlderThan(System.currentTimeMillis() - 3L * 24 * 60 * 60 * 1000) } }
        setContent {
            if (appLockEnabled.value && !appUnlocked.value) {
                AppLockScreen(onUnlock = { authenticateAppUnlock() })
            } else UltronScreen(
                initialSettings = settingsStore.load(),
                database = database,
                onSaveSettings = { settingsStore.save(it) },
                onSpeak = { if (ttsReady) tts?.speak(it.take(4_000), TextToSpeech.QUEUE_FLUSH, null, "ultron-reply") },
                onAction = { action -> runAction(action) },
                onOpenSpecialSetting = { AndroidAccess.openSpecialSetting(this, it) },
                onSetAppLock = { enabled -> setAppLock(enabled) }
            )
        }
    }

    private fun setAppLock(enabled: Boolean): Boolean {
        if (!enabled) {
            AppLockStore.setEnabled(this, false)
            appLockEnabled.value = false
            appUnlocked.value = true
            return true
        }
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else BiometricManager.Authenticators.BIOMETRIC_WEAK
        val availability = BiometricManager.from(this).canAuthenticate(authenticators)
        if (availability != BiometricManager.BIOMETRIC_SUCCESS) return false
        AppLockStore.setEnabled(this, true)
        appLockEnabled.value = true
        appUnlocked.value = true
        return true
    }

    private fun authenticateAppUnlock() {
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else BiometricManager.Authenticators.BIOMETRIC_WEAK
        val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock ULTRON")
            .setSubtitle("Authenticate to open your private assistant")
            .setAllowedAuthenticators(authenticators)
        if (Build.VERSION.SDK_INT < 30) promptInfoBuilder.setNegativeButtonText("Cancel")
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                appUnlocked.value = true
            }
        })
        runCatching { prompt.authenticate(promptInfoBuilder.build()) }
    }

    override fun onPause() {
        if (appLockEnabled.value) appUnlocked.value = false
        super.onPause()
    }

    private fun runAction(action: String) {
        val intent = when (action) {
            "Browser" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
            "Settings" -> Intent(Settings.ACTION_SETTINGS)
            "Camera" -> Intent("android.media.action.IMAGE_CAPTURE")
            "Dialer" -> Intent(Intent.ACTION_DIAL)
            "Maps" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=nearby places"))
            else -> if (action.startsWith("URL:")) Intent(Intent.ACTION_VIEW, Uri.parse(action.removePrefix("URL:"))) else null
        }
        if (intent != null) runCatching { startActivity(intent) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) { tts?.language = Locale.getDefault(); tts?.setPitch(.88f); tts?.setSpeechRate(.94f) }
    }

    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun UltronScreen(
    initialSettings: LlmSettings,
    database: UltronDatabase,
    onSaveSettings: (LlmSettings) -> Unit,
    onSpeak: (String) -> Unit,
    onAction: (String) -> Unit,
    onOpenSpecialSetting: (String) -> Unit,
    onSetAppLock: (Boolean) -> Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(initialSettings) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var voiceReply by remember { mutableStateOf(true) }
    var appLockOn by remember { mutableStateOf(AppLockStore.isEnabled(context)) }
    var showSettings by remember { mutableStateOf(false) }
    var showAccess by remember { mutableStateOf(false) }
    var accessRefresh by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Ready · configure your Oracle endpoint in Settings") }
    val lines = remember { mutableStateListOf(ChatMessage("assistant", "I am ULTRON. Online AI uses the endpoint you configure. Local AI will report clearly until a compatible native model runtime is installed.")) }
    val repository = remember(context) { InferenceRepository(context.applicationContext) }
    val router = remember(database) { UltronCommandRouter(context.applicationContext, database) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = spoken
    }
    val runtimePermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val granted = result.filterValues { it }.keys
        accessRefresh++
        status = if (granted.isNotEmpty()) "Permission result received · ${granted.size} granted" else "No new permissions granted"
    }
    val documentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Importing and extracting text locally…"
                try {
                    val record = DocumentIngestor.import(context, uri)
                    val id = withContext(Dispatchers.IO) { database.documentDao().insert(record.copy(title = PrivateTextVault.encrypt(record.title), extractedText = PrivateTextVault.encrypt(record.extractedText))) }
                    lines.add(ChatMessage("assistant", "Imported ‘${record.title}’ and extracted ${record.extractedText.length} characters locally (document #$id). Ask me a question about it; relevant excerpts are added to the next AI request."))
                    withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(lines.last().content))) }
                    status = "Document imported · on-device OCR/text extraction"
                } catch (e: Exception) {
                    val error = "Document import failed: ${e.message ?: "unsupported file or extraction error"}"
                    lines.add(ChatMessage("assistant", error))
                    status = "Import failed"
                } finally { busy = false }
            }
        }
    }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Copying GGUF model into private storage…"
                try {
                    val file = withContext(Dispatchers.IO) { NativeLlamaRuntime.importModel(context, uri.toString()) }
                    status = "GGUF model imported · ${file.length() / 1_000_000} MB · ready to load on first local prompt"
                    lines.add(ChatMessage("assistant", "Imported local GGUF model: ${NativeLlamaRuntime.activeModelName(context)}. Choose Local LLM and send a prompt to load it. Model loading may fail if the model format or memory requirements are incompatible; ULTRON will report the failure without switching models."))
                } catch (e: Exception) {
                    status = "Model import failed"
                    lines.add(ChatMessage("assistant", "Model import failed: ${e.message ?: "unknown error"}"))
                } finally { busy = false }
            }
        }
    }

    LaunchedEffect(Unit) {
        runCatching {
            val stored = withContext(Dispatchers.IO) { database.chatDao().latest(150).reversed().map { it.copy(content = PrivateTextVault.decrypt(it.content)) } }
            if (stored.isNotEmpty()) {
                lines.clear()
                stored.forEach { lines.add(ChatMessage(it.role, it.content)) }
                status = "Restored ${stored.size} recent chat messages"
            }
        }
    }

    fun send() {
        val prompt = draft.trim()
        if (prompt.isEmpty() || busy) return
        lines.add(ChatMessage("user", prompt))
        draft = ""
        busy = true
        status = "ULTRON is working…"
        scope.launch {
            try {
                withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "user", content = PrivateTextVault.encrypt(prompt))) }
                val localAction = router.handle(prompt)
                val response = if (localAction != null) {
                    status = "On-device command"
                    InferenceResult(localAction, "On-device · ULTRON actions")
                } else {
                    val prepared = router.buildMessages(lines.toList())
                    repository.complete(prepared, settings)
                }
                lines.add(ChatMessage("assistant", response.text))
                withContext(Dispatchers.IO) { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(response.text))) }
                status = response.provider
                if (voiceReply) onSpeak(response.text)
            } catch (e: Exception) {
                val message = e.message ?: "Unknown inference error"
                val friendly = "ULTRON couldn't complete that request: $message"
                lines.add(ChatMessage("assistant", friendly))
                withContext(Dispatchers.IO) { runCatching { database.chatDao().insert(ChatRecord(role = "assistant", content = PrivateTextVault.encrypt(friendly))) } }
                status = "Action / inference failed"
            } finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Crimson, secondary = Orange, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Row(Modifier.fillMaxSize().background(Night)) {
            Column(Modifier.width(62.dp).fillMaxHeight().background(Brush.verticalGradient(listOf(Color(0xFF1D0D11), Night))).padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Text("◉", color = Crimson, fontSize = 29.sp, fontWeight = FontWeight.Black)
                NavItem(Icons.Default.Chat, "Chat", true)
                NavItem(Icons.Default.Mic, "Voice") { runCatching { speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ULTRON")) }.onFailure { status = "Speech recognizer unavailable" } }
                NavItem(Icons.Default.Language, "Web") { onAction("Browser") }
                NavItem(Icons.Default.CameraAlt, "Camera") { onAction("Camera") }
                NavItem(Icons.Default.Map, "Maps") { onAction("Maps") }
                NavItem(Icons.Default.FolderOpen, "Import") { documentPicker.launch(arrayOf("text/*", "application/pdf", "application/json", "application/xml", "image/*")) }
                NavItem(Icons.Default.Security, "Access") { accessRefresh++; showAccess = true }
                NavItem(Icons.Default.Settings, "Settings") { showSettings = true }
            }
            Column(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 10.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ULTRON", color = Crimson, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                        Text("${settings.mode} · $status", color = if (busy) Orange else Color(0xFF9AD6A5), fontSize = 9.sp, maxLines = 2)
                    }
                    IconButton(onClick = { documentPicker.launch(arrayOf("text/*", "application/pdf", "application/json", "application/xml", "image/*")) }) { Icon(Icons.Default.FolderOpen, "Import document or image", tint = Orange) }
                    IconButton(onClick = { accessRefresh++; showAccess = true }) { Icon(Icons.Default.Security, "Permission center", tint = Crimson) }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Tune, "Inference settings", tint = Orange) }
                }
                HorizontalDivider(color = Crimson.copy(alpha = .4f))
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(lines) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.role == "user") Arrangement.End else Arrangement.Start) {
                            Surface(color = if (line.role == "user") Color(0xFF35161C) else Panel, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, if (line.role == "user") Crimson.copy(alpha = .7f) else Color(0xFF343944)), modifier = Modifier.widthIn(max = 380.dp)) {
                                Text(line.content, Modifier.padding(14.dp), color = Color(0xFFF2F0F5), fontSize = 14.sp, lineHeight = 20.sp)
                            }
                        }
                    }
                    if (busy) item { Text("ULTRON is thinking…", color = Orange, fontSize = 12.sp) }
                }
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(26.dp)).padding(horizontal = 5.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ULTRON")
                        }
                        try { speechLauncher.launch(intent) } catch (_: Exception) { status = "Speech recognizer unavailable" }
                    }) { Icon(Icons.Default.Mic, "Speech input", tint = Crimson) }
                    Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        if (draft.isEmpty()) Text("Message ULTRON…", color = Color.Gray, fontSize = 13.sp)
                        BasicTextField(value = draft, onValueChange = { draft = it }, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), modifier = Modifier.fillMaxWidth(), maxLines = 5)
                    }
                    IconButton(onClick = { send() }, enabled = !busy) { Icon(Icons.Default.Send, "Send", tint = if (busy) Color.Gray else Orange) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Voice replies", color = Color.LightGray, fontSize = 10.sp)
                    Switch(checked = voiceReply, onCheckedChange = { voiceReply = it })
                    Spacer(Modifier.weight(1f))
                    Text("Chat auto-clears after 3 days", color = Purple, fontSize = 9.sp)
                }
            }
        }

        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("ULTRON · Inference settings", color = Crimson) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Choose AI provider", color = Orange, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = settings.mode == InferenceMode.LOCAL, onClick = { settings = settings.copy(mode = InferenceMode.LOCAL) })
                        Text("Local LLM", color = Color.White)
                        Spacer(Modifier.width(8.dp))
                        RadioButton(selected = settings.mode == InferenceMode.ONLINE, onClick = { settings = settings.copy(mode = InferenceMode.ONLINE) })
                        Text("Online LLM", color = Color.White)
                    }
                    OutlinedTextField(value = settings.baseUrl, onValueChange = { settings = settings.copy(baseUrl = it) }, label = { Text("Oracle API base URL") }, singleLine = true)
                    OutlinedTextField(value = settings.model, onValueChange = { settings = settings.copy(model = it) }, label = { Text("Model ID") }, singleLine = true)
                    OutlinedTextField(value = settings.apiKey, onValueChange = { settings = settings.copy(apiKey = it) }, label = { Text("API token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                    Text("Expected route: POST {base URL}/chat/completions. Use HTTPS. Current source encrypts API tokens with Android Keystore before storage.", color = Color.LightGray, fontSize = 11.sp)
                    if (settings.mode == InferenceMode.LOCAL) {
                        Text("LOCAL MODEL PROFILE", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(LocalModelPolicy.describe(context), color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                        TextButton(onClick = { onAction("URL:" + LocalModelPolicy.choose((context.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager).let { am -> android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.totalMem }).modelPage); status = "Opened the selected model profile page. Check license, quantization, file size, and compatibility before downloading." }) { Text("Open selected model page", color = Orange) }
                        Text(LocalModelStore(context).status(), color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                        Button(onClick = { modelPicker.launch(arrayOf("application/octet-stream", "application/x-gguf", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Import GGUF model") }
                        Text("Import a GGUF file already downloaded to your phone. ULTRON copies it into private app storage and loads it only when Local LLM is selected. Keep enough free storage for a full extra copy.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                    }
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Biometric / device-credential app lock", color = Color.White)
                            Text("Locks ULTRON when it leaves the foreground. Android 11+ can use strong biometrics or your device credential; older Android versions require enrolled biometrics.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                        }
                        Switch(checked = appLockOn, onCheckedChange = { requested ->
                            if (onSetAppLock(requested)) appLockOn = requested
                            else status = "App lock not changed: set up a supported biometric/device credential in Android settings first."
                        })
                    }
                    HorizontalDivider(color = Crimson.copy(alpha = .35f))
                    Text("VOICE WAKE WORD", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Optional, visible foreground listener. Uses Android on-device recognition only when the device supports it; microphone stays active until stopped.", color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = {
                            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                runtimePermissions.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
                                status = "Grant microphone permission, then tap Start wake word again"
                            } else {
                                runCatching {
                                    val wake = Intent(context, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_START)
                                    if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(wake) else context.startService(wake)
                                    status = "Wake-word listener requested · check its ongoing notification"
                                }.onFailure { status = "Could not start wake-word listener: ${it.message}" }
                            }
                        }, modifier = Modifier.weight(1f)) { Text("Start listening", fontSize = 11.sp) }
                        OutlinedButton(onClick = {
                            context.stopService(Intent(context, UltronWakeWordService::class.java))
                            context.startService(Intent(context, UltronWakeWordService::class.java).setAction(UltronWakeWordService.ACTION_STOP))
                            status = "Wake-word stop requested"
                        }, modifier = Modifier.weight(1f)) { Text("Stop", fontSize = 11.sp) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Speak replies", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = voiceReply, onCheckedChange = { voiceReply = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    settings = settings.copy(baseUrl = settings.baseUrl.trim().trimEnd('/'), model = settings.model.trim())
                    runCatching { onSaveSettings(settings) }
                        .onSuccess { status = "Saved ${settings.mode} settings"; showSettings = false }
                        .onFailure { status = "Could not securely save token: ${it.message}" }
                }) { Text("Save settings") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } },
            containerColor = Panel
        )

        if (showAccess) {
            val itemsNow = remember(accessRefresh, context) { AndroidAccess.items(context) }
            androidx.compose.ui.window.Dialog(onDismissRequest = { showAccess = false }) {
                Surface(modifier = Modifier.fillMaxWidth().heightIn(max = 660.dp), color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .5f))) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ULTRON · Permission center", color = Crimson, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Enable only the access you want to use.", color = Color.LightGray, fontSize = 11.sp)
                            }
                            IconButton(onClick = { accessRefresh++ }) { Icon(Icons.Default.Refresh, "Refresh permission statuses", tint = Orange) }
                        }
                        HorizontalDivider(color = Crimson.copy(alpha = .35f))
                        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(itemsNow) { item ->
                                Surface(color = Color(0xFF171B22), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text(item.description, color = Color.LightGray, fontSize = 10.sp, lineHeight = 13.sp)
                                            Text(if (item.granted) "ENABLED" else "NOT ENABLED", color = if (item.granted) Color(0xFF9AD6A5) else Orange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                        if (item.action.startsWith("runtime:")) {
                                            TextButton(onClick = {
                                                val permission = item.action.removePrefix("runtime:")
                                                if (item.granted) onOpenSpecialSetting("app_permissions")
                                                else if (permission == android.Manifest.permission.POST_NOTIFICATIONS && Build.VERSION.SDK_INT < 33) {
                                                    status = "Notification runtime permission is not required on this Android version"
                                                } else runtimePermissions.launch(arrayOf(permission))
                                            }) { Text(if (item.granted) "Review" else "Grant", color = Orange) }
                                        } else TextButton(onClick = { onOpenSpecialSetting(item.action.removePrefix("settings:")); accessRefresh++ }) { Text(if (item.granted) "Open" else "Enable", color = Orange) }
                                    }
                                }
                            }
                        }
                        Text("Accessibility and notification access are powerful. ULTRON reads screen text only when you command it and does not save notification message contents. Device admin does not provide root access.", color = Purple, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 8.dp))
                        TextButton(onClick = { accessRefresh++; showAccess = false }) { Text("Done", color = Crimson) }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppLockScreen(onUnlock: () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Crimson, secondary = Orange, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF24080D), Night))), contentAlignment = Alignment.Center) {
            Surface(color = Panel, shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, Crimson.copy(alpha = .7f)), modifier = Modifier.padding(24.dp)) {
                Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("◉", color = Crimson, fontSize = 54.sp, fontWeight = FontWeight.Black)
                    Text("ULTRON LOCKED", color = Crimson, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Authenticate to access your assistant and locally stored private data.", color = Color.LightGray, fontSize = 13.sp)
                    Button(onClick = onUnlock, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Fingerprint, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Unlock ULTRON") }
                }
            }
        }
    }
}

@Composable
private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean = false, onClick: (() -> Unit)? = null) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = { onClick?.invoke() }) { Icon(icon, contentDescription = label, tint = if (active) Crimson else Color(0xFFB7B5C0), modifier = Modifier.size(22.dp)) }
        Text(label, color = Color(0xFFB7B5C0), fontSize = 8.sp)
    }
}
