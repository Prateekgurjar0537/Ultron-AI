package com.ultron.assistant

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Removes chat transcripts older than three days; approved memories, notes, and imported documents persist. */
class ChatCleanupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        UltronDatabase.get(applicationContext).chatDao().deleteOlderThan(System.currentTimeMillis() - 3L * 24 * 60 * 60 * 1000)
        Result.success()
    } catch (_: Exception) { Result.retry() }
}
