package com.ultron.assistant

import android.content.Context
import android.os.Build
import android.app.ActivityManager
import java.io.File
import java.io.FileOutputStream

/** JNI bridge to upstream llama.cpp. Model files remain in the app-private files directory. */
object NativeLlamaRuntime {
    private var libraryLoaded = false
    private var loadedPath: String? = null
    private var handle: Long = 0L
    private val lock = Any()

    init { libraryLoaded = runCatching { System.loadLibrary("ultron_llama"); true }.getOrDefault(false) }

    external fun nativeLoad(path: String, contextSize: Int, threads: Int): Long
    external fun nativeGenerate(handle: Long, prompt: String, maxTokens: Int): String
    external fun nativeFree(handle: Long)

    fun isAvailable(): Boolean = libraryLoaded

    fun importModel(context: Context, uriString: String): File {
        val uri = android.net.Uri.parse(uriString)
        val resolver = context.contentResolver
        val name = resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }?.takeIf { it.endsWith(".gguf", ignoreCase = true) } ?: "selected-model.gguf"
        val dir = File(context.filesDir, "models").apply { mkdirs() }
        val target = File(dir, "active-model.gguf")
        val temp = File(dir, "active-model.part")
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Android could not open the selected model file." }
            FileOutputStream(temp).use { output -> input.copyTo(output) }
        }
        require(temp.length() > 1024 * 1024) { "The selected file is too small to be a GGUF model." }
        // Basic magic validation prevents accidentally loading a renamed PDF or ZIP.
        val magic = ByteArray(4)
        temp.inputStream().use { require(it.read(magic) == 4 && magic.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46))) { "This file does not have the GGUF file signature." } }
        synchronized(lock) {
            if (handle != 0L) { runCatching { nativeFree(handle) }; handle = 0L; loadedPath = null }
            if (target.exists()) target.delete()
            check(temp.renameTo(target)) { "Could not move model into app-private storage." }
            context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE).edit()
                .putString("model_path", target.absolutePath).putString("model_original_name", name).apply()
        }
        return target
    }

    fun activeModelPath(context: Context): String? = context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE)
        .getString("model_path", null)?.takeIf { File(it).isFile }

    fun activeModelName(context: Context): String = context.getSharedPreferences("ultron_local_model", Context.MODE_PRIVATE)
        .getString("model_original_name", "No model selected") ?: "No model selected"

    fun generate(context: Context, prompt: String, maxTokens: Int = 512): String = synchronized(lock) {
        check(libraryLoaded) { "The native llama.cpp library did not load. Check the GitHub Actions native build log and install an arm64-v8a build." }
        val path = activeModelPath(context) ?: throw IllegalStateException("No GGUF model selected. Open Settings → Local LLM → Import GGUF model first.")
        if (handle == 0L || loadedPath != path) {
            if (handle != 0L) runCatching { nativeFree(handle) }
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            val ramGb = info.totalMem / 1_000_000_000.0
            // Conservative context sizes: context/KV cache can be the difference between fitting and OOM.
            val contextSize = when { ramGb >= 8.0 -> 2048; ramGb >= 6.0 -> 1536; else -> 1024 }
            val threads = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(2, 6)
            handle = nativeLoad(path, contextSize, threads)
            check(handle != 0L) { "llama.cpp could not load this GGUF. It may be incompatible or exceed available memory. ULTRON will not silently switch models." }
            loadedPath = path
        }
        nativeGenerate(handle, prompt, maxTokens).also {
            check(it.isNotBlank()) { "The local model returned an empty response." }
        }
    }
}

class LocalModelStore(private val context: Context) {
    fun status(): String = buildString {
        append("Native llama.cpp: ").append(if (NativeLlamaRuntime.isAvailable()) "library loaded" else "library unavailable / build failed").append('\n')
        append("Selected model: ").append(NativeLlamaRuntime.activeModelName(context)).append('\n')
        append("Path: ").append(NativeLlamaRuntime.activeModelPath(context) ?: "none").append('\n')
        append("Model file is stored in app-private storage. Download the exact GGUF asset from the model repository you choose, then import it.")
    }
}
