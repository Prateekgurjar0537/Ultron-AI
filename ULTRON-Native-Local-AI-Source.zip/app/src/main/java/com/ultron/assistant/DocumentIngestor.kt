package com.ultron.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/** Imports user-selected files only. Image and PDF text is extracted on-device with ML Kit OCR. */
object DocumentIngestor {
    private const val MAX_TEXT_CHARS = 100_000
    private const val MAX_PDF_PAGES = 20

    suspend fun import(context: Context, uri: Uri): DocumentRecord = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: "Imported document"
        val text = when {
            mime.startsWith("text/") || mime in setOf("application/json", "application/xml") ||
                name.endsWith(".md", true) || name.endsWith(".txt", true) || name.endsWith(".json", true) -> {
                resolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(MAX_TEXT_CHARS) }
                    ?: error("Android could not open this file.")
            }
            mime == "application/pdf" || name.endsWith(".pdf", true) -> readPdfViaOcr(context, uri)
            mime.startsWith("image/") -> recognizeImage(context, uri)
            else -> error("Unsupported file type: $mime. Choose a text file, Markdown, JSON, PDF, or image.")
        }.trim()
        require(text.isNotBlank()) { "No text was extracted. The file may be empty, unsupported, or too blurry." }
        DocumentRecord(title = name, mimeType = mime, extractedText = text.take(MAX_TEXT_CHARS))
    }

    private suspend fun recognizeImage(context: Context, uri: Uri): String {
        val image = InputImage.fromFilePath(context, uri)
        val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val devanagari = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        return try {
            val first = latin.process(image).await().text
            // Run the script-specific recognizer too, useful for Hindi/Devanagari photos.
            val second = devanagari.process(image).await().text
            listOf(first, second).maxByOrNull { it.length }.orEmpty()
        } finally { latin.close(); devanagari.close() }
    }

    private suspend fun readPdfViaOcr(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: error("Could not open PDF.")
        descriptor.use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val devanagari = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
                try {
                    val output = StringBuilder()
                    val pages = minOf(renderer.pageCount, MAX_PDF_PAGES)
                    for (index in 0 until pages) {
                        renderer.openPage(index).use { page ->
                            val scale = minOf(2.0, 1600.0 / maxOf(page.width, page.height))
                            val bitmap = Bitmap.createBitmap(
                                (page.width * scale).toInt().coerceAtLeast(1),
                                (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888
                            )
                            bitmap.eraseColor(Color.WHITE)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            try {
                                output.append("\n\n[Page ${index + 1}]\n")
                                val image = InputImage.fromBitmap(bitmap, 0)
                                val latinText = recognizer.process(image).await().text
                                val devText = devanagari.process(image).await().text
                                output.append(if (devText.length > latinText.length) devText else latinText)
                            } finally { bitmap.recycle() }
                        }
                        if (output.length >= MAX_TEXT_CHARS) break
                    }
                    if (renderer.pageCount > MAX_PDF_PAGES) output.append("\n[Only the first $MAX_PDF_PAGES pages were processed.]\n")
                    output.toString().take(MAX_TEXT_CHARS)
                } finally { recognizer.close(); devanagari.close() }
            }
        }
    }
}
