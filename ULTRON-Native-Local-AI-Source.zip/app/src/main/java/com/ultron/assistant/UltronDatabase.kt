package com.ultron.assistant

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

@Entity(tableName = "chat_messages", indices = [Index("createdAt")])
data class ChatRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "memories", indices = [Index(value = ["key"], unique = true)])
data class MemoryRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val value: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes", indices = [Index("createdAt")])
data class NoteRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "documents", indices = [Index("createdAt")])
data class DocumentRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val mimeType: String,
    val extractedText: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ChatDao {
    @Insert suspend fun insert(record: ChatRecord): Long
    @Query("SELECT * FROM chat_messages ORDER BY createdAt DESC, id DESC LIMIT :limit") suspend fun latest(limit: Int): List<ChatRecord>
    @Query("DELETE FROM chat_messages WHERE createdAt < :cutoff") suspend fun deleteOlderThan(cutoff: Long): Int
    @Query("DELETE FROM chat_messages") suspend fun clear()
}

@Dao
interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(record: MemoryRecord)
    @Query("SELECT * FROM memories ORDER BY createdAt DESC") suspend fun all(): List<MemoryRecord>
    @Query("SELECT * FROM memories WHERE `key` LIKE '%' || :query || '%' OR `value` LIKE '%' || :query || '%' ORDER BY createdAt DESC LIMIT 12") suspend fun search(query: String): List<MemoryRecord>
    @Query("DELETE FROM memories") suspend fun clear()
    @Query("DELETE FROM memories WHERE `key` = :key") suspend fun deleteByKey(key: String): Int
}

@Dao
interface NoteDao {
    @Insert suspend fun insert(record: NoteRecord): Long
    @Query("SELECT * FROM notes ORDER BY createdAt DESC LIMIT :limit") suspend fun latest(limit: Int): List<NoteRecord>
    @Query("DELETE FROM notes WHERE id = :id") suspend fun delete(id: Long): Int
}

@Dao
interface DocumentDao {
    @Insert suspend fun insert(record: DocumentRecord): Long
    @Query("SELECT * FROM documents ORDER BY createdAt DESC LIMIT :limit") suspend fun latest(limit: Int): List<DocumentRecord>
    @Query("DELETE FROM documents WHERE id = :id") suspend fun delete(id: Long): Int
    @Query("DELETE FROM documents") suspend fun clear()
}

@Database(
    entities = [ChatRecord::class, MemoryRecord::class, NoteRecord::class, DocumentRecord::class],
    version = 1,
    exportSchema = false
)
abstract class UltronDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
    abstract fun noteDao(): NoteDao
    abstract fun documentDao(): DocumentDao

    companion object {
        @Volatile private var INSTANCE: UltronDatabase? = null
        fun get(context: Context): UltronDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, UltronDatabase::class.java, "ultron-private.db")
                .fallbackToDestructiveMigration()
                .build().also { INSTANCE = it }
        }
    }
}
