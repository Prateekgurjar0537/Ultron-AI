package com.ultron.assistant

import android.app.admin.DeviceAdminReceiver

/** Legacy Android device-admin receiver. No wipe, lock, or password policies are requested by this app. */
class UltronDeviceAdminReceiver : DeviceAdminReceiver()
