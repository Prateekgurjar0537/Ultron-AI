package com.ultron.assistant

import android.content.Context

object AppLockStore {
    private const val PREFS = "ultron_security"
    private const val KEY_LOCK_ENABLED = "biometric_lock_enabled"
    fun isEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_LOCK_ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_LOCK_ENABLED, enabled).apply()
    }
}
