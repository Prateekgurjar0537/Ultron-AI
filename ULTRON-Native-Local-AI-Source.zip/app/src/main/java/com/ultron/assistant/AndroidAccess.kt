package com.ultron.assistant

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager

object AndroidAccess {
    data class Item(val title: String, val description: String, val granted: Boolean, val action: String)

    fun items(context: Context): List<Item> {
        val packageName = context.packageName
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val runtime = listOf(
            Triple("Camera", "Torch and direct camera features", android.Manifest.permission.CAMERA),
            Triple("Microphone", "Speech features that record audio", android.Manifest.permission.RECORD_AUDIO),
            Triple("Location", "Location-based reminders and user-requested location", android.Manifest.permission.ACCESS_FINE_LOCATION),
            Triple("Contacts", "Contact search when explicitly requested", android.Manifest.permission.READ_CONTACTS),
            Triple("Phone calls", "Direct calling; dialer works without this", android.Manifest.permission.CALL_PHONE)
        ).map { (title, description, permission) ->
            val granted = if (title == "Location") {
                ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            } else ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
            Item(title, description, granted, "runtime:$permission")
        }
        val special = listOf(
            Item("Notifications", "ULTRON reminder notifications", Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED, "runtime:${android.Manifest.permission.POST_NOTIFICATIONS}"),
            Item("Accessibility service", "Explicitly enabled, user-directed screen reading and actions", isAccessibilityEnabled(context), "settings:accessibility"),
            Item("Notification access", "Detect notification count only; message contents are not saved by this build", isNotificationListenerEnabled(context), "settings:notification_listener"),
            Item("Device admin", "Legacy admin activation; does not grant root or unrestricted system control", dpm.isAdminActive(ComponentName(context, UltronDeviceAdminReceiver::class.java)), "settings:device_admin"),
            Item("Display over other apps", "Reserved for a future optional floating assistant", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context), "settings:overlay"),
            Item("Ignore battery optimizations", "Optional; Android may still limit some background behavior", power.isIgnoringBatteryOptimizations(packageName), "settings:battery"),
            Item("Do Not Disturb access", "Needed only for explicit DND control", if (Build.VERSION.SDK_INT >= 23) (context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).isNotificationPolicyAccessGranted else true, "settings:dnd"),
            Item("Exact alarms", "Precise reminder timing; otherwise an inexact fallback is used", Build.VERSION.SDK_INT < 31 || (context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager).canScheduleExactAlarms(), "settings:alarms"),
            Item("App permissions", "Review all Android permissions for ULTRON", true, "settings:app_permissions")
        )
        return runtime + special
    }

    fun isAccessibilityEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals("${context.packageName}/${UltronAccessibilityService::class.java.name}", ignoreCase = true) }
    }

    fun isNotificationListenerEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(':').any { it.contains(context.packageName) && it.contains(UltronNotificationListener::class.java.name) }
    }

    fun openSpecialSetting(activity: Activity, action: String) {
        val intent = when (action) {
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "notification_listener" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            "device_admin" -> Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(
                DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(activity, UltronDeviceAdminReceiver::class.java)
            ).putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "ULTRON uses this legacy admin activation only for user-configured administrative features.")
            "overlay" -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}"))
            "battery" -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            "dnd" -> Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            "alarms" -> if (Build.VERSION.SDK_INT >= 31) Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${activity.packageName}")) else Intent(Settings.ACTION_SETTINGS)
            "app_permissions" -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${activity.packageName}"))
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        runCatching { activity.startActivity(intent) }
            .onFailure { runCatching { activity.startActivity(Intent(Settings.ACTION_SETTINGS)) } }
    }
}
