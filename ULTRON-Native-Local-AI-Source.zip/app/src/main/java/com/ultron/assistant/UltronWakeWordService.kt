package com.ultron.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import java.util.Locale

/** Opt-in wake-word service. Uses Android on-device recognition only; no online recognizer fallback. */
class UltronWakeWordService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private val restartRunnable = Runnable { if (!destroyed && recognizer != null) startListening() }
    private var destroyed = false
    private var lastDetectedAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Starting on-device wake-word listener…", ongoing = true))
        if (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            updateNotification("On-device speech recognition unavailable. Listener stopped; no cloud fallback used.", ongoing = false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (recognizer == null) startRecognizer()
        return START_STICKY
    }

    private fun startRecognizer() {
        if (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) return
        recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).also { speech ->
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {
                    updateNotification("Listening for ‘Ultron’ on-device. Tap to open ULTRON.", ongoing = true)
                }
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onError(error: Int) {
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        updateNotification("Microphone permission missing. Open ULTRON to review permissions.", ongoing = false)
                        stopSelf()
                    } else scheduleRestart(700)
                }
                override fun onResults(results: android.os.Bundle?) {
                    val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    val detected = phrases.any { phrase ->
                        phrase.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]"), " ").contains("ultron")
                    }
                    if (detected && System.currentTimeMillis() - lastDetectedAt > 8_000L) {
                        lastDetectedAt = System.currentTimeMillis()
                        showWakeNotification()
                    }
                    scheduleRestart(350)
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {
                    val phrases = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    if (phrases.any { it.contains("ultron", ignoreCase = true) } && System.currentTimeMillis() - lastDetectedAt > 8_000L) {
                        lastDetectedAt = System.currentTimeMillis()
                        showWakeNotification()
                    }
                }
                override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
            })
        }
        startListening()
    }

    private fun startListening() {
        val speech = recognizer ?: return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        runCatching { speech.startListening(intent) }.onFailure { scheduleRestart(1_200) }
    }

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, delayMs)
    }

    private fun showWakeNotification() {
        updateNotification("Wake word detected. Tap here to open ULTRON and give a command.", ongoing = true)
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        runCatching { manager.notify(DETECTED_NOTIFICATION_ID, buildNotification("I heard ‘Ultron’", ongoing = false)) }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "ULTRON wake word", NotificationManager.IMPORTANCE_LOW))
            }
            if (manager.getNotificationChannel(DETECTED_CHANNEL_ID) == null) {
                manager.createNotificationChannel(NotificationChannel(DETECTED_CHANNEL_ID, "ULTRON wake word detected", NotificationManager.IMPORTANCE_HIGH))
            }
        }
    }

    private fun updateNotification(text: String, ongoing: Boolean) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        runCatching { manager.notify(NOTIFICATION_ID, buildNotification(text, ongoing)) }
    }

    private fun buildNotification(text: String, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 314, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 315, Intent(this, UltronWakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, if (ongoing) CHANNEL_ID else DETECTED_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (ongoing) "ULTRON · Wake word" else "ULTRON")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(ongoing)
            .addAction(android.R.drawable.ic_media_pause, "Stop listening", stop)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        main.removeCallbacks(restartRunnable)
        destroyed = true
        runCatching { recognizer?.cancel(); recognizer?.destroy() }
        recognizer = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.ultron.assistant.WAKE_WORD_START"
        const val ACTION_STOP = "com.ultron.assistant.WAKE_WORD_STOP"
        const val CHANNEL_ID = "ultron_wake_word"
        const val DETECTED_CHANNEL_ID = "ultron_wake_detected"
        const val NOTIFICATION_ID = 7310
        const val DETECTED_NOTIFICATION_ID = 7311
    }
}
