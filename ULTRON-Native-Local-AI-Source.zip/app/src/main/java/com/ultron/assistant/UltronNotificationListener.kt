package com.ultron.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.atomic.AtomicInteger

/** Opt-in notification listener. This implementation exposes only a live count and never persists notification text. */
class UltronNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() { refreshCount() }
    override fun onNotificationPosted(sbn: StatusBarNotification) { refreshCount() }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { refreshCount() }
    override fun onListenerDisconnected() { liveCount.set(0) }
    private fun refreshCount() { runCatching { liveCount.set(activeNotifications?.size ?: 0) } }

    companion object { private val liveCount = AtomicInteger(0); fun notificationCount(): Int = liveCount.get() }
}
