package com.ultron.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** User-enabled helper. It only reads or acts after a user command; it does not send screen contents to a server. */
class UltronAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected(); active = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Observe no content by default. */ }
    override fun onInterrupt() = Unit
    override fun onDestroy() { if (active === this) active = null; super.onDestroy() }

    fun findVisibleText(text: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val matches = try { root.findAccessibilityNodeInfosByText(text) } finally { root.recycle() }
        val match = matches.firstOrNull { it.isVisibleToUser }
        matches.filter { it !== match }.forEach { it.recycle() }
        return match
    }

    fun clickText(text: String): Boolean {
        var current: AccessibilityNodeInfo? = findVisibleText(text) ?: return false
        while (current != null) {
            val clicked = current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            val parent = current.parent
            current.recycle()
            if (clicked) {
                parent?.recycle()
                return true
            }
            current = parent
        }
        return false
    }

    fun readVisibleText(limit: Int = 5_000): String {
        val root = rootInActiveWindow ?: return "No active app window is available."
        val result = StringBuilder()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || result.length >= limit || depth > 30) return
            if (node.isVisibleToUser) {
                val label = node.text?.toString()?.trim().orEmpty().ifBlank { node.contentDescription?.toString()?.trim().orEmpty() }
                if (label.isNotBlank()) result.append(label).append('\n')
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                try { walk(child, depth + 1) } finally { child?.recycle() }
            }
        }
        try { walk(root, 0) } finally { root.recycle() }
        return result.toString().take(limit).ifBlank { "No readable text was exposed by the active app." }
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            if (node.isVisibleToUser && node.isScrollable) return AccessibilityNodeInfo.obtain(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                val found = try { findScrollable(child) } finally { child?.recycle() }
                if (found != null) return found
            }
            return null
        }
        return try {
            val target = findScrollable(root) ?: root
            val ok = target.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
            if (target !== root) target.recycle()
            ok
        } finally { root.recycle() }
    }

    fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }

    companion object {
        @Volatile private var active: UltronAccessibilityService? = null
        fun instance(): UltronAccessibilityService? = active
    }
}
