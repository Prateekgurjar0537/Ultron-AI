package com.ultron.assistant

import android.content.Context
import android.net.Uri
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

enum class InferenceMode { LOCAL, ONLINE }

data class ChatMessage(val role: String, val content: String)
data class LlmSettings(val mode: InferenceMode, val baseUrl: String, val model: String, val apiKey: String)
data class InferenceResult(val text: String, val provider: String)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("ultron_inference", Context.MODE_PRIVATE)
    fun load(): LlmSettings {
        val encrypted = prefs.getString("apiKeyCipher", null)
        val key = if (encrypted != null) runCatching { ApiKeyVault.decrypt(encrypted) }.getOrDefault("") else migrateLegacyKey()
        return LlmSettings(
            mode = runCatching { InferenceMode.valueOf(prefs.getString("mode", "ONLINE")!!) }.getOrDefault(InferenceMode.ONLINE),
            baseUrl = prefs.getString("baseUrl", "https://your-oracle-host.example/v1") ?: "",
            model = prefs.getString("model", "your-model-id") ?: "",
            apiKey = key
        )
    }
    fun save(s: LlmSettings) {
        val encryptedKey = if (s.apiKey.isBlank()) "" else ApiKeyVault.encrypt(s.apiKey)
        prefs.edit().putString("mode", s.mode.name).putString("baseUrl", s.baseUrl.trim().trimEnd('/'))
            .putString("model", s.model.trim()).putString("apiKeyCipher", encryptedKey).remove("apiKey").apply()
    }
    private fun migrateLegacyKey(): String {
        val legacy = prefs.getString("apiKey", "").orEmpty()
        if (legacy.isNotBlank()) runCatching {
            prefs.edit().putString("apiKeyCipher", ApiKeyVault.encrypt(legacy)).remove("apiKey").apply()
        }
        return legacy
    }
}

/** AES-GCM using an app-specific non-exportable Android Keystore key (API 23+). */
private object ApiKeyVault {
    private const val ALIAS = "ultron_api_key_aes_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return generator.generateKey()
    }

    fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    fun decrypt(value: String): String {
        val packed = Base64.decode(value, Base64.NO_WRAP)
        require(packed.size > 12) { "Saved API token has invalid encrypted data." }
        val iv = packed.copyOfRange(0, 12)
        val data = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(data), Charsets.UTF_8)
    }
}

interface InferenceProvider {
    suspend fun complete(messages: List<ChatMessage>, settings: LlmSettings): InferenceResult
}

/** Real HTTP client for OpenAI-compatible /v1/chat/completions endpoints. */
class OpenAICompatibleProvider : InferenceProvider {
    private val gson = Gson()
    override suspend fun complete(messages: List<ChatMessage>, settings: LlmSettings): InferenceResult = withContext(Dispatchers.IO) {
        val base = settings.baseUrl.trim().trimEnd('/')
        val uri = Uri.parse(base)
        val host = uri.host
        require(uri.scheme == "https" || (uri.scheme == "http" && host == "10.0.2.2")) {
            "Use an HTTPS endpoint for online inference (HTTP is allowed only for the Android emulator host)."
        }
        require(!host.isNullOrBlank() && !host.contains("your-oracle-host", ignoreCase = true)) {
            "Enter your real Oracle-hosted API URL in Settings."
        }
        require(settings.model.isNotBlank() && settings.model != "your-model-id") { "Enter the model ID your host expects." }
        val body = JsonObject().apply {
            addProperty("model", settings.model)
            add("messages", gson.toJsonTree(messages))
            addProperty("stream", false)
        }
        val conn = (URL("$base/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 120000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (settings.apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer ${settings.apiKey}")
        }
        try {
            conn.outputStream.use { it.write(gson.toJson(body).toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = runCatching { gson.fromJson(raw, JsonObject::class.java).toString() }.getOrDefault(raw.take(500))
                throw IllegalStateException("Oracle LLM HTTP $code: $message")
            }
            val json = gson.fromJson(raw, JsonObject::class.java)
            val answer = json.getAsJsonArray("choices")?.get(0)?.asJsonObject
                ?.getAsJsonObject("message")?.get("content")?.asString
            if (answer.isNullOrBlank()) throw IllegalStateException("The host returned no choices[0].message.content. Check API compatibility.")
            InferenceResult(answer, "Online · ${uri.host}")
        } finally { conn.disconnect() }
    }
}

class LocalInferenceProvider(private val context: Context) : InferenceProvider {
    override suspend fun complete(messages: List<ChatMessage>, settings: LlmSettings): InferenceResult = withContext(Dispatchers.IO) {
        val recent = messages.takeLast(10)
        val prompt = buildString {
            append("You are ULTRON, a helpful private Android assistant. Answer in the user's language, including Hinglish when appropriate.\n")
            recent.forEach { message ->
                append(if (message.role == "assistant") "Assistant: " else if (message.role == "system") "System: " else "User: ")
                append(message.content.trim()).append("\n")
            }
            append("Assistant:")
        }
        val answer = NativeLlamaRuntime.generate(context.applicationContext, prompt, 512)
        InferenceResult(answer.trim(), "Local · llama.cpp GGUF")
    }
}

class InferenceRepository(context: Context) {
    private val online = OpenAICompatibleProvider()
    private val local = LocalInferenceProvider(context.applicationContext)
    suspend fun complete(messages: List<ChatMessage>, settings: LlmSettings): InferenceResult =
        when (settings.mode) {
            InferenceMode.ONLINE -> online.complete(messages, settings)
            InferenceMode.LOCAL -> local.complete(messages, settings)
        }
}
