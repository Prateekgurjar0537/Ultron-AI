package com.ultron.assistant

import org.junit.Assert.assertEquals
import org.junit.Test

class InferenceModeTest {
    @Test fun hasSeparateOnlineAndLocalModes() {
        assertEquals(InferenceMode.ONLINE, InferenceMode.valueOf("ONLINE"))
        assertEquals(InferenceMode.LOCAL, InferenceMode.valueOf("LOCAL"))
    }

    @Test fun choosesRequestedRamModelTiersWithoutE4bDowngrade() {
        assertEquals(LocalModelPolicy.LFM_1_2B, LocalModelPolicy.choose(4_000_000_000L))
        assertEquals(LocalModelPolicy.GEMMA_E2B, LocalModelPolicy.choose(6_000_000_000L))
        assertEquals(LocalModelPolicy.GEMMA_E4B, LocalModelPolicy.choose(8_000_000_000L))
    }
}
